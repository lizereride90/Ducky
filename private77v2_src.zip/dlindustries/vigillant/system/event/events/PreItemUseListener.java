package dlindustries.vigillant.system.event.events;

import dlindustries.vigillant.system.event.CancellableEvent;
import dlindustries.vigillant.system.event.Listener;
import java.util.ArrayList;

public interface PreItemUseListener extends Listener {
   void onPreItemUse(PreItemUseListener.PreItemUseEvent var1);

   public static class PreItemUseEvent extends CancellableEvent<PreItemUseListener> {
      public void fire(ArrayList<PreItemUseListener> listeners) {
         listeners.forEach((l) -> {
            l.onPreItemUse(this);
         });
      }

      public Class<PreItemUseListener> getListenerType() {
         return PreItemUseListener.class;
      }
   }
}
