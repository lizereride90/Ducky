package dlindustries.vigillant.system.event.events;

import dlindustries.vigillant.system.event.Event;
import dlindustries.vigillant.system.event.Listener;
import java.util.ArrayList;
import net.minecraft.class_332;

public interface HudListener extends Listener {
   void onRenderHud(HudListener.HudEvent var1);

   public static class HudEvent extends Event<HudListener> {
      public class_332 context;
      public float delta;

      public HudEvent(class_332 context, float delta) {
         this.context = context;
         this.delta = delta;
      }

      public void fire(ArrayList<HudListener> listeners) {
         listeners.forEach((e) -> {
            e.onRenderHud(this);
         });
      }

      public Class<HudListener> getListenerType() {
         return HudListener.class;
      }
   }
}
