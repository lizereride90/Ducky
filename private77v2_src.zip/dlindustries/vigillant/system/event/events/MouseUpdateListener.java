package dlindustries.vigillant.system.event.events;

import dlindustries.vigillant.system.event.Event;
import dlindustries.vigillant.system.event.Listener;
import java.util.ArrayList;

public interface MouseUpdateListener extends Listener {
   void onMouseUpdate();

   public static class MouseUpdateEvent extends Event<MouseUpdateListener> {
      public void fire(ArrayList<MouseUpdateListener> listeners) {
         listeners.forEach(MouseUpdateListener::onMouseUpdate);
      }

      public Class<MouseUpdateListener> getListenerType() {
         return MouseUpdateListener.class;
      }
   }
}
