package dlindustries.vigillant.system.event.events;

import dlindustries.vigillant.system.event.CancellableEvent;
import dlindustries.vigillant.system.event.Listener;
import java.util.ArrayList;
import net.minecraft.class_2596;

public interface PacketSendListener extends Listener {
   void onPacketSend(PacketSendListener.PacketSendEvent var1);

   public static class PacketSendEvent extends CancellableEvent<PacketSendListener> {
      public class_2596 packet;

      public PacketSendEvent(class_2596 packet) {
         this.packet = packet;
      }

      public void fire(ArrayList<PacketSendListener> listeners) {
         listeners.forEach((e) -> {
            e.onPacketSend(this);
         });
      }

      public Class<PacketSendListener> getListenerType() {
         return PacketSendListener.class;
      }
   }
}
