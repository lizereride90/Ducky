package dlindustries.vigillant.system.event.events;

import dlindustries.vigillant.system.event.CancellableEvent;
import dlindustries.vigillant.system.event.Listener;
import java.util.ArrayList;

public interface ItemUseListener extends Listener {
   void onItemUse(ItemUseListener.ItemUseEvent var1);

   public static class ItemUseEvent extends CancellableEvent<ItemUseListener> {
      public void fire(ArrayList<ItemUseListener> listeners) {
         listeners.forEach((e) -> {
            e.onItemUse(this);
         });
      }

      public Class<ItemUseListener> getListenerType() {
         return ItemUseListener.class;
      }
   }
}
