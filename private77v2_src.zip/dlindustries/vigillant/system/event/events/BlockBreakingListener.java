package dlindustries.vigillant.system.event.events;

import dlindustries.vigillant.system.event.CancellableEvent;
import dlindustries.vigillant.system.event.Listener;
import java.util.ArrayList;

public interface BlockBreakingListener extends Listener {
   void onBlockBreaking(BlockBreakingListener.BlockBreakingEvent var1);

   public static class BlockBreakingEvent extends CancellableEvent<BlockBreakingListener> {
      public void fire(ArrayList<BlockBreakingListener> listeners) {
         listeners.forEach((e) -> {
            e.onBlockBreaking(this);
         });
      }

      public Class<BlockBreakingListener> getListenerType() {
         return BlockBreakingListener.class;
      }
   }
}
