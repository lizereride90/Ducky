package dlindustries.vigillant.system.event.events;

import dlindustries.vigillant.system.event.CancellableEvent;
import dlindustries.vigillant.system.event.Listener;
import java.util.ArrayList;
import java.util.Iterator;

public interface PostItemUseListener extends Listener {
   void onPostItemUse(PostItemUseListener.PostItemUseEvent var1);

   public static class PostItemUseEvent extends CancellableEvent {
      public void fire(ArrayList listeners) {
         Iterator var2 = listeners.iterator();

         while(var2.hasNext()) {
            Object obj = var2.next();
            ((PostItemUseListener)obj).onPostItemUse(this);
         }

      }

      public Class<? extends Listener> getListenerType() {
         return PostItemUseListener.class;
      }
   }
}
