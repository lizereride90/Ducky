package dlindustries.vigillant.system.event.events;

import dlindustries.vigillant.system.event.Event;
import dlindustries.vigillant.system.event.Listener;
import java.util.ArrayList;

public interface MovementPacketListener extends Listener {
   void onSendMovementPackets();

   public static class MovementPacketEvent extends Event<MovementPacketListener> {
      public void fire(ArrayList<MovementPacketListener> listeners) {
         listeners.forEach(MovementPacketListener::onSendMovementPackets);
      }

      public Class<MovementPacketListener> getListenerType() {
         return MovementPacketListener.class;
      }
   }
}
