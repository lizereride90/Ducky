package dlindustries.vigillant.system.event.events;

import dlindustries.vigillant.system.event.Event;
import dlindustries.vigillant.system.event.Listener;
import java.util.ArrayList;
import net.minecraft.class_4587;

public interface GameRenderListener extends Listener {
   void onGameRender(GameRenderListener.GameRenderEvent var1);

   public static class GameRenderEvent extends Event<GameRenderListener> {
      public class_4587 matrices;
      public float delta;

      public GameRenderEvent(class_4587 matrices, float delta) {
         this.matrices = matrices;
         this.delta = delta;
      }

      public void fire(ArrayList<GameRenderListener> listeners) {
         listeners.forEach((e) -> {
            e.onGameRender(this);
         });
      }

      public Class<GameRenderListener> getListenerType() {
         return GameRenderListener.class;
      }
   }
}
