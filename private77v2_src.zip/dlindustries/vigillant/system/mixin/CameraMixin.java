package dlindustries.vigillant.system.mixin;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.event.EventManager;
import dlindustries.vigillant.system.event.events.CameraUpdateListener;
import dlindustries.vigillant.system.module.modules.optimizer.CameraOptimizer;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({class_4184.class})
public abstract class CameraMixin {
   @ModifyArgs(
      method = {"update"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/Camera;setPos(DDD)V"
)
   )
   private void update(Args args) {
      CameraUpdateListener.CameraUpdateEvent event = new CameraUpdateListener.CameraUpdateEvent((Double)args.get(0), (Double)args.get(1), (Double)args.get(2));
      EventManager.fire(event);
      args.set(0, event.getX());
      args.set(1, event.getY());
      args.set(2, event.getZ());
   }

   @Inject(
      at = {@At("HEAD")},
      method = {"clipToSpace(F)F"},
      cancellable = true
   )
   private void onClipToSpace(float desiredCameraDistance, CallbackInfoReturnable<Float> cir) {
      CameraOptimizer optimizer = (CameraOptimizer)system.INSTANCE.getModuleManager().getModule(CameraOptimizer.class);
      if (optimizer != null && optimizer.isNoClipEnabled()) {
         cir.setReturnValue(desiredCameraDistance);
      }

   }

   @Inject(
      at = {@At("HEAD")},
      method = {"getSubmersionType()Lnet/minecraft/block/enums/CameraSubmersionType;"},
      cancellable = true
   )
   private void onGetSubmersionType(CallbackInfoReturnable<class_5636> cir) {
      CameraOptimizer optimizer = (CameraOptimizer)system.INSTANCE.getModuleManager().getModule(CameraOptimizer.class);
      if (optimizer != null && optimizer.isNoOverlayEnabled()) {
         cir.setReturnValue(class_5636.field_27888);
      }

   }
}
