package dlindustries.vigillant.system.mixin;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.module.modules.crystal.DhandMod;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_490;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_310.class})
public class InventorySwitchMixin {
   @Inject(
      method = {"handleInputEvents"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onInventoryKeyPress(CallbackInfo ci) {
      class_310 client = class_310.method_1551();
      class_304 inventoryKey = client.field_1690.field_1822;
      if (inventoryKey.method_1436() && client.field_1755 == null) {
         DhandMod module = (DhandMod)system.INSTANCE.getModuleManager().getModule(DhandMod.class);
         if (module != null && module.isEnabled()) {
            DhandMod.handleInventoryKey();
            inventoryKey.method_23481(false);
            ci.cancel();
         } else {
            client.method_1507(new class_490(client.field_1724));
         }

      }
   }
}
