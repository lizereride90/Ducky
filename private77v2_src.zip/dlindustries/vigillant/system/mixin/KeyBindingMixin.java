package dlindustries.vigillant.system.mixin;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.imixin.IKeyBinding;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_3675.class_306;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({class_304.class})
public abstract class KeyBindingMixin implements IKeyBinding {
   @Shadow
   private class_306 field_1655;

   public boolean isActuallyPressed() {
      long handle = system.mc.method_22683().method_4490();
      int code = this.field_1655.method_1444();
      return class_3675.method_15987(handle, code);
   }

   public void resetPressed() {
      this.method_23481(this.isActuallyPressed());
   }

   @Shadow
   public abstract void method_23481(boolean var1);
}
