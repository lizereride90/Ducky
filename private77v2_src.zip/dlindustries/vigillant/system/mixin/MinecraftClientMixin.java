package dlindustries.vigillant.system.mixin;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.event.EventManager;
import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.BlockBreakingListener;
import dlindustries.vigillant.system.event.events.ItemUseListener;
import dlindustries.vigillant.system.event.events.ResolutionListener;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.modules.optimizer.PlacementOptimizer;
import net.minecraft.class_1041;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_310.class})
public class MinecraftClientMixin {
   @Shadow
   @Nullable
   public class_638 field_1687;
   @Shadow
   @Final
   private class_1041 field_1704;
   @Shadow
   public class_746 field_1724;
   @Shadow
   private int field_1752;

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void onTick(CallbackInfo ci) {
      if (this.field_1687 != null) {
         TickListener.TickEvent event = new TickListener.TickEvent();
         EventManager.fire(event);
         PlacementOptimizer optimizer = (PlacementOptimizer)system.INSTANCE.getModuleManager().getModule(PlacementOptimizer.class);
         if (optimizer != null && optimizer.isEnabled()) {
            class_1792 held = this.field_1724.method_6047().method_7909();
            boolean excludeAnchors = optimizer.shouldExcludeAnchors();
            if (excludeAnchors && (held == class_1802.field_23141 || held == class_1802.field_8801)) {
               return;
            }

            int desiredDelay = -1;
            if (held instanceof class_1747) {
               desiredDelay = optimizer.getBlockDelay();
            } else if (held == class_1802.field_8301) {
               desiredDelay = optimizer.getCrystalDelay();
            }

            if (desiredDelay >= 0) {
               if (desiredDelay == 0) {
                  this.field_1752 = 0;
               } else if (this.field_1752 > desiredDelay) {
                  this.field_1752 = desiredDelay - 1;
               }
            }
         }
      }

   }

   @Inject(
      method = {"onResolutionChanged"},
      at = {@At("HEAD")}
   )
   private void onResolutionChanged(CallbackInfo ci) {
      EventManager.fire(new ResolutionListener.ResolutionEvent(this.field_1704));
   }

   @Inject(
      method = {"doItemUse"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onItemUse(CallbackInfo ci) {
      ItemUseListener.ItemUseEvent event = new ItemUseListener.ItemUseEvent();
      EventManager.fire(event);
      if (event.isCancelled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"doAttack"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onAttack(CallbackInfoReturnable<Boolean> cir) {
      AttackListener.AttackEvent event = new AttackListener.AttackEvent();
      EventManager.fire(event);
      if (event.isCancelled()) {
         cir.setReturnValue(false);
      }

   }

   @Inject(
      method = {"handleBlockBreaking"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onBlockBreaking(boolean breaking, CallbackInfo ci) {
      BlockBreakingListener.BlockBreakingEvent event = new BlockBreakingListener.BlockBreakingEvent();
      EventManager.fire(event);
      if (event.isCancelled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"stop"},
      at = {@At("HEAD")}
   )
   private void onClose(CallbackInfo ci) {
      system.INSTANCE.getProfileManager().saveProfile();
   }
}
