package dlindustries.vigillant.system.mixin;

import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_312.class})
public interface MouseHandlerAccessor {
   @Invoker("onMouseButton")
   void press(long var1, int var3, int var4, int var5);
}
