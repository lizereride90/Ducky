package dlindustries.vigillant.system.module.modules.client;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.gui.ClickGui;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.module.setting.StringSetting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.Utils;
import java.util.Iterator;

public final class SelfDestruct extends Module {
   public static boolean destruct = false;
   private final BooleanSetting replaceMod = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Replace Mod"), true)).setDescription(EncryptedString.of("Replaces the mod with the original JAR file"));
   private final BooleanSetting saveLastModified = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Save Last Modified"), true)).setDescription(EncryptedString.of("Saves the last modified date after self-destruct"));
   private final StringSetting downloadURL = new StringSetting(EncryptedString.of("Replace URL"), "https://cdn.modrinth.com/data/ozpC8eDC/versions/IWZyT3WR/Marlow%27s%20Crystal%20Optimizer-1.21.X-1.0.3.jar");

   public SelfDestruct() {
      super(EncryptedString.of("Self Destruct"), EncryptedString.of("Kills the system and destroys all traces of using this client. The client mod will be replaced as Marlow's crystal optimizer"), -1, Category.CLIENT);
      this.addSettings(new Setting[]{this.replaceMod, this.saveLastModified, this.downloadURL});
   }

   public void onEnable() {
      if (!this.mc.field_1724.method_5715()) {
         this.setEnabled(false);
      } else {
         destruct = true;
         ((ClickGUI)system.INSTANCE.getModuleManager().getModule(ClickGUI.class)).setEnabled(false);
         this.setEnabled(false);
         system.INSTANCE.getProfileManager().saveProfile();
         if (this.mc.field_1755 instanceof ClickGui) {
            system.INSTANCE.guiInitialized = false;
            this.mc.field_1755.method_25419();
         }

         if (this.replaceMod.getValue()) {
            try {
               Utils.replaceModFile(this.downloadURL.getValue(), Utils.getCurrentJarPath());
            } catch (Exception var6) {
            }
         }

         Iterator var1 = system.INSTANCE.getModuleManager().getModules().iterator();

         while(var1.hasNext()) {
            Module module = (Module)var1.next();
            module.setEnabled(false);
            module.setName((CharSequence)null);
            module.setDescription((CharSequence)null);
            Iterator var3 = module.getSettings().iterator();

            while(var3.hasNext()) {
               Setting<?> setting = (Setting)var3.next();
               setting.setName((CharSequence)null);
               setting.setDescription((CharSequence)null);
               if (setting instanceof StringSetting) {
                  StringSetting set = (StringSetting)setting;
                  set.setValue((String)null);
               }
            }

            module.getSettings().clear();
         }

         if (this.saveLastModified.getValue()) {
            system.INSTANCE.resetModifiedDate();
         }

         Runtime.getRuntime().gc();
      }
   }
}
