package dlindustries.vigillant.system.module.modules.client;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.KeybindSetting;
import dlindustries.vigillant.system.module.setting.StringSetting;
import dlindustries.vigillant.system.module.setting.MinMaxSetting;
import dlindustries.vigillant.system.utils.EncryptedString;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * ResetConfig – wipes the saved profile (a.json) and resets all
 * module settings back to their defaults in the current session.
 *
 * Toggle it once → it resets, then disables itself immediately.
 *
 * HOW CONFIG WORKS:
 *   Config is saved as JSON at:
 *     Windows : %TEMP%\UJHfsGGjbPfVZ\a.json
 *     Mac/Linux: ~/UJHfsGGjbPfVZ/a.json
 *   It stores each module's enabled state and every setting value,
 *   keyed by the module's index in the ModuleManager list.
 *   Profile is loaded on startup and saved on GUI close / Self Destruct.
 *
 * TO RESET AFTER SELF DESTRUCT:
 *   Delete the file above, or enable this module before Self Destructing.
 *   On next launch the client will start with all defaults.
 */
public final class ResetConfig extends Module {

    public ResetConfig() {
        super(
            EncryptedString.of("Reset Config"),
            EncryptedString.of("Wipes saved config and resets all settings to defaults"),
            -1, Category.CLIENT
        );
        // No settings – just a one-shot toggle
    }

    @Override
    public void onEnable() {
        // 1. Delete the saved profile file
        try {
            String os   = System.getProperty("os.name").toLowerCase();
            String base = os.contains("win")
                ? System.getProperty("java.io.tmpdir")
                : System.getProperty("user.home");
            Path profilePath = Paths.get(base, "UJHfsGGjbPfVZ", "a.json");
            Files.deleteIfExists(profilePath);
        } catch (Exception ignored) {}

        // 2. Reset every module in the current session
        for (Module module : system.INSTANCE.getModuleManager().getModules()) {
            // Disable
            module.setEnabledStatus(false);
            module.onDisable();

            // Reset all settings to their original values
            for (Setting<?> setting : module.getSettings()) {
                if (setting instanceof BooleanSetting) {
                    ((BooleanSetting) setting).setValue(((BooleanSetting) setting).getOriginalValue());
                } else if (setting instanceof NumberSetting) {
                    ((NumberSetting) setting).setValue(((NumberSetting) setting).getOriginalValue());
                } else if (setting instanceof ModeSetting) {
                    ((ModeSetting<?>) setting).setModeIndex(0);
                } else if (setting instanceof KeybindSetting) {
                    KeybindSetting ks = (KeybindSetting) setting;
                    ks.setKey(-1);
                } else if (setting instanceof StringSetting) {
                    StringSetting ss = (StringSetting) setting;
                    ss.setValue("");
                }
                // MinMaxSetting: leave as-is (no getOriginalValue API on it)
            }
        }

        // 3. Disable self immediately (one-shot)
        this.setEnabledStatus(false);
        super.onEnable();
        this.setEnabledStatus(false);
    }
}
