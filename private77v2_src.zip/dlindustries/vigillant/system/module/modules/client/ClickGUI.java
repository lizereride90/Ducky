package dlindustries.vigillant.system.module.modules.client;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.event.events.PacketReceiveListener;
import dlindustries.vigillant.system.gui.ClickGui;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import net.minecraft.class_3944;
import net.minecraft.class_490;

public final class ClickGUI extends Module implements PacketReceiveListener {
    // Color accent settings
    public static final NumberSetting red   = new NumberSetting(EncryptedString.of("Red"),   0.0, 255.0, 10.0,  1.0);
    public static final NumberSetting green = new NumberSetting(EncryptedString.of("Green"), 0.0, 255.0, 10.0,  1.0);
    public static final NumberSetting blue  = new NumberSetting(EncryptedString.of("Blue"),  0.0, 255.0, 50.0,  1.0);

    // Window settings
    public static final NumberSetting alphaWindow = new NumberSetting(EncryptedString.of("Window Alpha"), 0.0, 255.0, 180.0, 1.0);
    public static final NumberSetting roundQuads  = new NumberSetting(EncryptedString.of("Roundness"),    1.0,  10.0,   5.0,  1.0);

    // GUI scale: controlled by Ctrl+Scroll in-GUI, also exposed as a setting
    // Range 0.5x – 2.0x stored as 50–200
    public static final NumberSetting guiScale = new NumberSetting(EncryptedString.of("GUI Scale"), 50.0, 200.0, 100.0, 5.0);

    // Toggles
    public static final BooleanSetting breathing      = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Breathing"),       true )).setDescription(EncryptedString.of("Breathing color theme"));
    public static final BooleanSetting background     = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Background"),      true )).setDescription(EncryptedString.of("Dark overlay behind GUI"));
    public static final BooleanSetting backgroundImage= (BooleanSetting)(new BooleanSetting(EncryptedString.of("Background Image"),false)).setDescription(EncryptedString.of("Show background image in ClickGUI"));
    public static final BooleanSetting customFont     = new BooleanSetting(EncryptedString.of("Custom Font"), true);
    public static final BooleanSetting antiAliasing   = (BooleanSetting)(new BooleanSetting(EncryptedString.of("MSAA"), true)).setDescription(EncryptedString.of("Anti-Aliasing – smoother UI edges"));

    private final BooleanSetting preventClose = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Prevent Close"), true)).setDescription(EncryptedString.of("For servers with freeze plugins"));

    // Animation mode
    public static final ModeSetting<ClickGUI.AnimationMode> animationMode =
        new ModeSetting<>(EncryptedString.of("Animations"), ClickGUI.AnimationMode.Normal, ClickGUI.AnimationMode.class);

    public ClickGUI() {
        // Key 344 = Right Shift  (original keybind preserved)
        super(EncryptedString.of("private77v2"), EncryptedString.of("Client developed by DL-industries"), 344, Category.CLIENT);
        red.setValue(10.0);
        green.setValue(10.0);
        blue.setValue(50.0);
        this.addSettings(new Setting[]{
            alphaWindow, roundQuads, guiScale,
            breathing, background, backgroundImage,
            this.preventClose, animationMode, antiAliasing, customFont
        });
    }

    public void onEnable() {
        this.eventManager.add(PacketReceiveListener.class, this);
        system.INSTANCE.previousScreen = this.mc.field_1755;
        if (system.INSTANCE.clickGui != null) {
            this.mc.method_29970(system.INSTANCE.clickGui);
        } else if (this.mc.field_1755 instanceof class_490) {
            system.INSTANCE.guiInitialized = true;
        }
        super.onEnable();
    }

    public void onDisable() {
        this.eventManager.remove(PacketReceiveListener.class, this);
        if (this.mc.field_1755 instanceof ClickGui) {
            system.INSTANCE.clickGui.method_25419();
            this.mc.method_29970(system.INSTANCE.previousScreen);
            system.INSTANCE.clickGui.onGuiClose();
        } else if (this.mc.field_1755 instanceof class_490) {
            system.INSTANCE.guiInitialized = false;
        }
        super.onDisable();
    }

    public void onPacketReceive(PacketReceiveListener.PacketReceiveEvent event) {
        if (system.INSTANCE.guiInitialized && event.packet instanceof class_3944 && this.preventClose.getValue()) {
            event.cancel();
        }
    }

    public enum AnimationMode {
        Normal, Positive, Off;
        private static ClickGUI.AnimationMode[] $values() {
            return new ClickGUI.AnimationMode[]{Normal, Positive, Off};
        }
    }
}
