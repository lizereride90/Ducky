package dlindustries.vigillant.system.module.modules.crystal;

import dlindustries.vigillant.system.event.events.ItemUseListener;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.MathUtils;
import dlindustries.vigillant.system.utils.MouseSimulation;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import org.lwjgl.glfw.GLFW;

public final class AutoXP extends Module implements TickListener, ItemUseListener {
   private final NumberSetting delay = new NumberSetting(EncryptedString.of("Delay"), 0.0D, 20.0D, 1.0D, 1.0D);
   private final NumberSetting chance = (NumberSetting)(new NumberSetting(EncryptedString.of("Chance"), 0.0D, 100.0D, 100.0D, 1.0D)).setDescription(EncryptedString.of("Randomization"));
   private final BooleanSetting clickSimulation = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Click Simulation"), true)).setDescription(EncryptedString.of("Makes the CPS hud think you're legit"));
   int clock;

   public AutoXP() {
      super(EncryptedString.of("Faster XP"), EncryptedString.of("Automatically throws XP bottles for you"), -1, Category.CRYSTAL);
      this.addSettings(new Setting[]{this.delay, this.chance, this.clickSimulation});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.eventManager.add(ItemUseListener.class, this);
      this.clock = 0;
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      this.eventManager.remove(ItemUseListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      if (this.mc.field_1755 == null) {
         boolean dontThrow = this.clock != 0;
         int randomInt = MathUtils.randomInt(1, 100);
         if (this.mc.field_1724.method_6047().method_7909() == class_1802.field_8287) {
            if (GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 1) == 1) {
               if (dontThrow) {
                  --this.clock;
               }

               if (!dontThrow && randomInt <= this.chance.getValueInt()) {
                  if (this.clickSimulation.getValue()) {
                     MouseSimulation.mouseClick(1);
                  }

                  class_1269 result = this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
                  if (result.method_23665() && result.method_23666()) {
                     this.mc.field_1724.method_6104(class_1268.field_5808);
                  }

                  this.clock = this.delay.getValueInt();
               }

            }
         }
      }
   }

   public void onItemUse(ItemUseListener.ItemUseEvent event) {
      if (this.mc.field_1724.method_6047().method_7909() == class_1802.field_8287) {
         event.cancel();
      }

   }
}
