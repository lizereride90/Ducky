package dlindustries.vigillant.system.module.modules.crystal;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.mixin.HandledScreenMixin;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1802;
import net.minecraft.class_437;
import net.minecraft.class_490;

public final class HoverTotem extends Module implements TickListener {
   private final NumberSetting delay = new NumberSetting(EncryptedString.of("Delay"), 0.0D, 20.0D, 1.0D, 1.0D);
   private final BooleanSetting hotbar = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Hotbar"), true)).setDescription(EncryptedString.of("Puts a totem in your hotbar as well"));
   private final NumberSetting slot = (NumberSetting)(new NumberSetting(EncryptedString.of("Totem Slot"), 1.0D, 9.0D, 9.0D, 1.0D)).setDescription(EncryptedString.of("Your preferred hotbar slot for totems"));
   private final BooleanSetting dynamicDelay = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Dynamic Delay"), true)).setDescription(EncryptedString.of("Adds random timing variations to avoid detection"));
   private int clock;
   private boolean safeMode;

   public HoverTotem() {
      super(EncryptedString.of("Autototem - legit"), EncryptedString.of("Equips totems when hovered - optimized and perfected with DhandMod module"), -1, Category.CRYSTAL);
      this.addSettings(new Setting[]{this.delay, this.hotbar, this.slot, this.dynamicDelay});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.clock = 0;
      this.safeMode = false;
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      class_437 var2 = this.mc.field_1755;
      if (!(var2 instanceof class_490)) {
         this.clock = this.delay.getValueInt();
         this.safeMode = false;
      } else {
         class_490 inv = (class_490)var2;
         boolean offhandTotem = this.mc.field_1724.method_6079().method_31574(class_1802.field_8288);
         int hotbarSlotIndex = this.slot.getValueInt() - 1;
         boolean hotbarTotem = this.mc.field_1724.method_31548().method_5438(hotbarSlotIndex).method_31574(class_1802.field_8288);
         this.safeMode = offhandTotem && hotbarTotem;
         class_1735 hoveredSlot = ((HandledScreenMixin)inv).getFocusedSlot();
         if (hoveredSlot != null && hoveredSlot.method_34266() <= 35) {
            if (hoveredSlot.method_7677().method_7909() == class_1802.field_8288) {
               if (this.clock > 0) {
                  --this.clock;
                  return;
               }

               this.executeTotemSwap(inv, hoveredSlot);
               this.clock = this.getDynamicDelay();
            }

         }
      }
   }

   private int getDynamicDelay() {
      int base = this.delay.getValueInt();
      if (this.safeMode) {
         ++base;
      }

      return this.dynamicDelay.getValue() ? Math.max(0, base + ThreadLocalRandom.current().nextInt(-2, 3)) : Math.max(0, base);
   }

   private void performSwap(class_490 inv, int from, int to) {
      this.mc.field_1761.method_2906(((class_1723)inv.method_17577()).field_7763, from, to, class_1713.field_7791, this.mc.field_1724);
   }

   private void executeTotemSwap(class_490 inv, class_1735 hoveredSlot) {
      int hotbarSlot = this.slot.getValueInt() - 1;
      if (!this.mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
         this.performSwap(inv, hoveredSlot.method_34266(), 40);
      } else if (this.hotbar.getValue() && this.mc.field_1724.method_31548().method_5438(hotbarSlot).method_7909() != class_1802.field_8288) {
         this.performSwap(inv, hoveredSlot.method_34266(), hotbarSlot);
      }

   }
}
