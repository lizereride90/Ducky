package dlindustries.vigillant.system.module.modules.crystal;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.InventoryUtils;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_640;
import net.minecraft.class_2846.class_2847;

public final class TotemOffhand extends Module implements TickListener {
   private final NumberSetting minSlotDelay = new NumberSetting("Min Slot Delay", 50.0D, 200.0D, 80.0D, 1.0D);
   private final NumberSetting maxSlotDelay = new NumberSetting("Max Slot Delay", 100.0D, 300.0D, 150.0D, 1.0D);
   private final NumberSetting offhandDelay = new NumberSetting("Offhand Delay", 20.0D, 60.0D, 35.0D, 1.0D);
   private final BooleanSetting dynamicJitter = new BooleanSetting("Dynamic Jitter", true);
   private final BooleanSetting switchBack = new BooleanSetting("Switch Back", true);
   private int ticksToNextAction;
   private int previousSlot = -1;
   private boolean sentSwapPacket = false;
   private boolean isActive = false;
   private long lastTotemTime = 0L;
   private final Deque<Long> recentDelays = new ArrayDeque();
   private double currentJitterFactor = 1.0D;

   public TotemOffhand() {
      super("Auto offhand", "Basically undetectable autototem - pair with legit autototem", -1, Category.CRYSTAL);
      this.addSettings(new Setting[]{this.minSlotDelay, this.maxSlotDelay, this.offhandDelay, this.dynamicJitter, this.switchBack});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.reset();
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      if (this.shouldPause()) {
         this.reset();
      } else {
         if (this.needsTotem()) {
            this.isActive = true;
            long currentTime = System.currentTimeMillis();
            if (currentTime - this.lastTotemTime < this.getPingAdjustedThreshold()) {
               return;
            }

            this.executeStealthProtocol();
         }

      }
   }

   private boolean shouldPause() {
      return this.mc.field_1755 != null || !this.mc.field_1724.method_5805() || this.mc.field_1724.method_6079().method_7909() == class_1802.field_8288;
   }

   private boolean needsTotem() {
      return this.mc.field_1724.method_6079().method_7909() != class_1802.field_8288 && InventoryUtils.hasItem(class_1802.field_8288);
   }

   private int getPing() {
      if (this.mc.method_1562() == null) {
         return 0;
      } else {
         class_640 entry = this.mc.method_1562().method_2871(this.mc.field_1724.method_5667());
         return entry != null ? entry.method_2959() : 0;
      }
   }

   private void executeStealthProtocol() {
      if (this.ticksToNextAction > 0) {
         --this.ticksToNextAction;
      } else if (this.sentSwapPacket && this.switchBack.getValue()) {
         if (this.previousSlot != -1) {
            this.mc.field_1724.method_31548().field_7545 = this.previousSlot;
         }

         this.reset();
      } else if (this.previousSlot == -1) {
         this.initializeSlotChange();
      } else if (!this.sentSwapPacket) {
         this.performDeceptiveSwap();
      } else {
         this.finalizeSwap();
      }
   }

   private void initializeSlotChange() {
      this.previousSlot = this.mc.field_1724.method_31548().field_7545;
      int baseDelay = ThreadLocalRandom.current().nextInt(this.minSlotDelay.getValueInt(), this.maxSlotDelay.getValueInt() + 1);
      if (this.dynamicJitter.getValue()) {
         this.currentJitterFactor = 0.8D + ThreadLocalRandom.current().nextDouble() * 0.4D;
         baseDelay = (int)((double)baseDelay * this.currentJitterFactor);
      }

      this.ticksToNextAction = this.msToTicks(baseDelay);
   }

   private void performDeceptiveSwap() {
      if (InventoryUtils.selectItemFromHotbar(class_1802.field_8288)) {
         double gaussian = ThreadLocalRandom.current().nextGaussian() * 5.0D;
         int uniformJitter = ThreadLocalRandom.current().nextInt(-10, 10);
         int finalDelay = (int)((double)this.offhandDelay.getValueInt() + gaussian + (double)uniformJitter);
         finalDelay = Math.max(25, Math.min(60, finalDelay));
         this.ticksToNextAction = this.msToTicks(finalDelay);
         this.sentSwapPacket = true;
      } else {
         this.reset();
      }

   }

   private void finalizeSwap() {
      if (this.mc.method_1562() != null) {
         this.mc.method_1562().method_52787(new class_2846(class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
         if (this.switchBack.getValue()) {
            this.ticksToNextAction = this.msToTicks(ThreadLocalRandom.current().nextInt(15, 25));
            this.sentSwapPacket = true;
         } else {
            this.reset();
         }

         this.lastTotemTime = System.currentTimeMillis();
      }
   }

   private int msToTicks(int milliseconds) {
      return (int)Math.ceil((double)milliseconds / 50.0D);
   }

   private long getPingAdjustedThreshold() {
      return (long)Math.max(50, this.getPing() + 20);
   }

   private void reset() {
      this.ticksToNextAction = 0;
      this.previousSlot = -1;
      this.sentSwapPacket = false;
      this.isActive = false;
   }
}
