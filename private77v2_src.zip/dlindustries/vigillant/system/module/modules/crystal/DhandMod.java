package dlindustries.vigillant.system.module.modules.crystal;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import net.minecraft.class_310;
import net.minecraft.class_490;

public final class DhandMod extends Module implements TickListener {
   private final NumberSetting slotSetting = new NumberSetting(EncryptedString.of("Totem Slot"), 1.0D, 9.0D, 9.0D, 1.0D);
   private final NumberSetting delaySetting = new NumberSetting(EncryptedString.of("Open Delay"), 1.0D, 100.0D, 25.0D, 1.0D);
   private boolean shouldOpenInventory = false;
   private int delayTicksRemaining = 0;

   public DhandMod() {
      super(EncryptedString.of("D Hand Mod"), EncryptedString.of("Advanced version of D-hand-Mod - pair with autototem legit and general use."), -1, Category.CRYSTAL);
      this.addSettings(new Setting[]{this.slotSetting, this.delaySetting});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
   }

   public void onTick() {
      if (this.shouldOpenInventory && --this.delayTicksRemaining <= 0) {
         class_310.method_1551().method_1507(new class_490(class_310.method_1551().field_1724));
         this.shouldOpenInventory = false;
      }

   }

   public static void handleInventoryKey() {
      DhandMod module = (DhandMod)system.INSTANCE.getModuleManager().getModule(DhandMod.class);
      if (module != null && module.isEnabled()) {
         class_310 client = class_310.method_1551();
         if (client.field_1724 != null && client.field_1755 == null) {
            int totemSlot = module.slotSetting.getValueInt() - 1;
            if (client.field_1724.method_31548().field_7545 == totemSlot) {
               client.method_1507(new class_490(client.field_1724));
            } else {
               client.field_1724.method_31548().field_7545 = totemSlot;
               module.shouldOpenInventory = true;
               module.delayTicksRemaining = (int)Math.ceil(module.delaySetting.getValue() / 50.0D);
            }

         }
      }
   }
}
