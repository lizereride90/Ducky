package dlindustries.vigillant.system.module.modules.sword;

import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.MinMaxSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.MouseSimulation;
import dlindustries.vigillant.system.utils.TimerUtils;
import dlindustries.vigillant.system.utils.WorldUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_1829;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import net.minecraft.class_9334;
import net.minecraft.class_9362;
import net.minecraft.class_239.class_240;
import org.lwjgl.glfw.GLFW;

public final class TriggerBot extends Module implements TickListener, AttackListener {
   private final ModeSetting<TriggerBot.Mode> mode;
   private final BooleanSetting inScreen;
   private final BooleanSetting whileUse;
   private final BooleanSetting onLeftClick;
   private final MinMaxSetting swordDelay;
   private final MinMaxSetting axeDelay;
   private final BooleanSetting checkShield;
   private final BooleanSetting onlyCritSword;
   private final BooleanSetting onlyCritAxe;
   private final BooleanSetting swing;
   private final BooleanSetting whileAscend;
   private final BooleanSetting clickSimulation;
   private final BooleanSetting strayBypass;
   private final BooleanSetting allEntities;
   private final BooleanSetting useShield;
   private final NumberSetting shieldTime;
   private final BooleanSetting sticky;
   private final TimerUtils timer;
   private int currentSwordDelay;
   private int currentAxeDelay;
   private boolean isMaceAttack;

   public TriggerBot() {
      super(EncryptedString.of("Trigger Bot"), EncryptedString.of("Automatically hits players for you"), -1, Category.sword);
      this.mode = new ModeSetting(EncryptedString.of("Mode"), TriggerBot.Mode.WEAPONS, TriggerBot.Mode.class);
      this.inScreen = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Work In Screen"), false)).setDescription(EncryptedString.of("Will trigger even if youre inside a screen"));
      this.whileUse = (BooleanSetting)(new BooleanSetting(EncryptedString.of("While Use"), false)).setDescription(EncryptedString.of("Will hit the player no matter if you're eating or blocking with a shield"));
      this.onLeftClick = (BooleanSetting)(new BooleanSetting(EncryptedString.of("On Left Click"), false)).setDescription(EncryptedString.of("Only gets triggered if holding down left click"));
      this.swordDelay = (MinMaxSetting)(new MinMaxSetting(EncryptedString.of("Sword Delay"), 0.0D, 1000.0D, 1.0D, 540.0D, 550.0D)).setDescription(EncryptedString.of("Delay for swords"));
      this.axeDelay = (MinMaxSetting)(new MinMaxSetting(EncryptedString.of("Axe Delay"), 0.0D, 1000.0D, 1.0D, 780.0D, 800.0D)).setDescription(EncryptedString.of("Delay for axes"));
      this.checkShield = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Check Shield"), false)).setDescription(EncryptedString.of("Checks if the player is blocking your hits with a shield (Recommended with Shield Disabler)"));
      this.onlyCritSword = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Only Crit Sword"), false)).setDescription(EncryptedString.of("Only does critical hits with a sword"));
      this.onlyCritAxe = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Only Crit Axe"), false)).setDescription(EncryptedString.of("Only does critical hits with an axe"));
      this.swing = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Swing Hand"), true)).setDescription(EncryptedString.of("Whether to swing the hand or not"));
      this.whileAscend = (BooleanSetting)(new BooleanSetting(EncryptedString.of("While Ascending"), false)).setDescription(EncryptedString.of("Wont hit if you're ascending from a jump, only if on ground or falling"));
      this.clickSimulation = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Click Simulation"), true)).setDescription(EncryptedString.of("Makes the CPS hud think you're legit"));
      this.strayBypass = (BooleanSetting)(new BooleanSetting(EncryptedString.of("bypass mode"), true)).setDescription(EncryptedString.of("Bypasses stray's Anti-TriggerBot and other strict anticheats"));
      this.allEntities = (BooleanSetting)(new BooleanSetting(EncryptedString.of("All Entities"), false)).setDescription(EncryptedString.of("Will attack all entities"));
      this.useShield = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Use Shield"), false)).setDescription(EncryptedString.of("Uses shield if it's in your offhand"));
      this.shieldTime = new NumberSetting(EncryptedString.of("Shield Time"), 100.0D, 1000.0D, 350.0D, 1.0D);
      this.sticky = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Same Player"), false)).setDescription(EncryptedString.of("Hits the player that was recently attacked, good for FFA"));
      this.timer = new TimerUtils();
      this.isMaceAttack = false;
      this.addSettings(new Setting[]{this.mode, this.inScreen, this.whileUse, this.onLeftClick, this.swordDelay, this.axeDelay, this.checkShield, this.whileAscend, this.sticky, this.onlyCritSword, this.onlyCritAxe, this.swing, this.clickSimulation, this.strayBypass, this.allEntities, this.useShield, this.shieldTime});
   }

   public void onEnable() {
      this.currentSwordDelay = this.swordDelay.getRandomValueInt();
      this.currentAxeDelay = this.axeDelay.getRandomValueInt();
      this.eventManager.add(TickListener.class, this);
      this.eventManager.add(AttackListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      this.eventManager.remove(AttackListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      try {
         if (!this.inScreen.getValue() && this.mc.field_1755 != null) {
            return;
         }

         class_1792 item = this.mc.field_1724.method_6047().method_7909();
         if (!this.isItemAllowed(item)) {
            return;
         }

         if (this.onLeftClick.getValue() && GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 0) != 1) {
            return;
         }

         if ((this.mc.field_1724.method_6079().method_7909().method_57347().method_57832(class_9334.field_50075) || this.mc.field_1724.method_6079().method_7909() instanceof class_1819) && GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 1) == 1 && !this.whileUse.getValue()) {
            return;
         }

         if (!this.whileAscend.getValue() && (!this.mc.field_1724.method_24828() && this.mc.field_1724.method_18798().field_1351 > 0.0D || !this.mc.field_1724.method_24828() && this.mc.field_1724.field_6017 <= 0.0F)) {
            return;
         }

         if (item instanceof class_9362) {
            this.handleMaceMode();
         } else if (item instanceof class_1829) {
            this.handleSwordMode();
         } else if (item instanceof class_1743) {
            this.handleAxeMode();
         } else {
            this.handleAllItemsMode();
         }
      } catch (Exception var2) {
      }

   }

   private boolean isItemAllowed(class_1792 item) {
      TriggerBot.Mode currentMode = (TriggerBot.Mode)this.mode.getMode();
      if (currentMode == TriggerBot.Mode.MACE) {
         return item instanceof class_9362;
      } else if (currentMode == TriggerBot.Mode.WEAPONS) {
         return item instanceof class_1829 || item instanceof class_1743;
      } else if (currentMode != TriggerBot.Mode.MACE_AND_WEAPONS) {
         return true;
      } else {
         return item instanceof class_9362 || item instanceof class_1829 || item instanceof class_1743;
      }
   }

   private void handleMaceMode() {
      class_239 var2 = this.mc.field_1765;
      if (var2 instanceof class_3966) {
         class_3966 hit = (class_3966)var2;
         class_1297 entity = hit.method_17782();
         if (!this.isValidEntity(entity)) {
            return;
         }

         if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            if (this.checkShield.getValue() && player.method_6039() && !WorldUtils.isShieldFacingAway(player)) {
               return;
            }
         }

         if (this.onlyCritSword.getValue() && this.mc.field_1724.field_6017 <= 0.0F) {
            return;
         }

         this.isMaceAttack = true;
         if (this.useShield.getValue() && this.mc.field_1724.method_6079().method_7909() == class_1802.field_8255 && this.mc.field_1724.method_6039()) {
            MouseSimulation.mouseRelease(1);
         }

         WorldUtils.hitEntity(entity, this.swing.getValue());
         if (this.clickSimulation.getValue()) {
            MouseSimulation.mouseClick(0);
         }

         this.isMaceAttack = false;
      }

   }

   private void handleSwordMode() {
      class_239 var2 = this.mc.field_1765;
      if (var2 instanceof class_3966) {
         class_3966 hit = (class_3966)var2;
         class_1297 entity = hit.method_17782();

         assert this.mc.field_1724.method_6052() != null;

         if (this.sticky.getValue() && entity != this.mc.field_1724.method_6052()) {
            return;
         }

         if (entity instanceof class_1657 || this.strayBypass.getValue() && entity instanceof class_1642 || this.allEntities.getValue() && entity != null) {
            if (entity instanceof class_1657) {
               class_1657 player = (class_1657)entity;
               if (this.checkShield.getValue() && player.method_6039() && !WorldUtils.isShieldFacingAway(player)) {
                  return;
               }
            }

            if (this.onlyCritSword.getValue() && this.mc.field_1724.field_6017 <= 0.0F) {
               return;
            }

            if (this.timer.delay((float)this.currentSwordDelay)) {
               if (this.useShield.getValue() && this.mc.field_1724.method_6079().method_7909() == class_1802.field_8255 && this.mc.field_1724.method_6039()) {
                  MouseSimulation.mouseRelease(1);
               }

               WorldUtils.hitEntity(entity, this.swing.getValue());
               if (this.clickSimulation.getValue()) {
                  MouseSimulation.mouseClick(0);
               }

               this.currentSwordDelay = this.swordDelay.getRandomValueInt();
               this.timer.reset();
            } else if (this.useShield.getValue() && this.mc.field_1724.method_6079().method_7909() == class_1802.field_8255) {
               int useFor = this.shieldTime.getValueInt();
               MouseSimulation.mouseClick(1, useFor);
            }
         }
      }

   }

   private void handleAxeMode() {
      class_239 var2 = this.mc.field_1765;
      if (var2 instanceof class_3966) {
         class_3966 hit = (class_3966)var2;
         class_1297 entity = hit.method_17782();
         if (entity instanceof class_1657 || this.strayBypass.getValue() && entity instanceof class_1642 || this.allEntities.getValue() && entity != null) {
            if (entity instanceof class_1657) {
               class_1657 player = (class_1657)entity;
               if (this.checkShield.getValue() && player.method_6039() && !WorldUtils.isShieldFacingAway(player)) {
                  return;
               }
            }

            if (this.onlyCritAxe.getValue() && this.mc.field_1724.field_6017 <= 0.0F) {
               return;
            }

            if (this.timer.delay((float)this.currentAxeDelay)) {
               WorldUtils.hitEntity(entity, this.swing.getValue());
               if (this.clickSimulation.getValue()) {
                  MouseSimulation.mouseClick(0);
               }

               this.currentAxeDelay = this.axeDelay.getRandomValueInt();
               this.timer.reset();
            } else if (this.useShield.getValue() && this.mc.field_1724.method_6079().method_7909() == class_1802.field_8255) {
               int useFor = this.shieldTime.getValueInt();
               MouseSimulation.mouseClick(1, useFor);
            }
         }
      }

   }

   private void handleAllItemsMode() {
      class_239 var2 = this.mc.field_1765;
      if (var2 instanceof class_3966) {
         class_3966 entityHit = (class_3966)var2;
         if (this.mc.field_1765.method_17783() == class_240.field_1331) {
            class_1297 entity = entityHit.method_17782();

            assert this.mc.field_1724.method_6052() != null;

            if (this.sticky.getValue() && entity != this.mc.field_1724.method_6052()) {
               return;
            }

            if (entity instanceof class_1657 || this.strayBypass.getValue() && entity instanceof class_1642 || this.allEntities.getValue() && entity != null) {
               if (entity instanceof class_1657) {
                  class_1657 player = (class_1657)entity;
                  if (this.checkShield.getValue() && player.method_6039() && !WorldUtils.isShieldFacingAway(player)) {
                     return;
                  }
               }

               if (this.onlyCritSword.getValue() && this.mc.field_1724.field_6017 <= 0.0F) {
                  return;
               }

               if (this.timer.delay((float)this.currentSwordDelay)) {
                  WorldUtils.hitEntity(entity, this.swing.getValue());
                  if (this.clickSimulation.getValue()) {
                     MouseSimulation.mouseClick(0);
                  }

                  this.currentSwordDelay = this.swordDelay.getRandomValueInt();
                  this.timer.reset();
               } else if (this.useShield.getValue() && this.mc.field_1724.method_6079().method_7909() == class_1802.field_8255) {
                  int useFor = this.shieldTime.getValueInt();
                  MouseSimulation.mouseClick(1, useFor);
               }
            }
         }
      }

   }

   private boolean isValidEntity(class_1297 entity) {
      return entity instanceof class_1657 || this.strayBypass.getValue() && entity instanceof class_1642 || this.allEntities.getValue() && entity != null;
   }

   public void onAttack(AttackListener.AttackEvent event) {
      if (GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 0) != 1) {
         event.cancel();
      }

   }

   public boolean isMaceAttackActive() {
      return this.isMaceAttack;
   }

   public static enum Mode {
      MACE("Mace"),
      WEAPONS("Weapons"),
      MACE_AND_WEAPONS("Mace and Weapons"),
      ALL_ITEMS("All Items");

      private final String name;

      private Mode(String name) {
         this.name = name;
      }

      public String toString() {
         return this.name;
      }

      // $FF: synthetic method
      private static TriggerBot.Mode[] $values() {
         return new TriggerBot.Mode[]{MACE, WEAPONS, MACE_AND_WEAPONS, ALL_ITEMS};
      }
   }
}
