package dlindustries.vigillant.system.module.modules.sword;

import dlindustries.vigillant.system.event.events.HudListener;
import dlindustries.vigillant.system.event.events.PacketSendListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.MinMaxSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.TimerUtils;
import net.minecraft.class_1268;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2824.class_5908;
import org.lwjgl.glfw.GLFW;

public final class AutoWTap extends Module implements PacketSendListener, HudListener {
   private final MinMaxSetting delay = new MinMaxSetting(EncryptedString.of("Delay"), 0.0D, 1000.0D, 1.0D, 230.0D, 270.0D);
   private final BooleanSetting inAir = (BooleanSetting)(new BooleanSetting(EncryptedString.of("In Air"), false)).setDescription(EncryptedString.of("Whether it should W tap in air"));
   private final TimerUtils sprintTimer = new TimerUtils();
   private final TimerUtils tapTimer = new TimerUtils();
   private boolean holdingForward;
   private boolean sprinting;
   private int currentDelay;
   private boolean jumpedWhileHitting;

   public AutoWTap() {
      super(EncryptedString.of("Auto WTap"), EncryptedString.of("Automatically W Taps for you so the opponent takes more knockback"), -1, Category.sword);
      this.addSettings(new Setting[]{this.delay, this.inAir});
   }

   public void onEnable() {
      this.eventManager.add(PacketSendListener.class, this);
      this.eventManager.add(HudListener.class, this);
      this.currentDelay = this.delay.getRandomValueInt();
      this.jumpedWhileHitting = false;
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(PacketSendListener.class, this);
      this.eventManager.remove(HudListener.class, this);
      super.onDisable();
   }

   public void onRenderHud(HudListener.HudEvent event) {
      if (GLFW.glfwGetKey(this.mc.method_22683().method_4490(), 87) != 1) {
         this.sprinting = false;
         this.holdingForward = false;
      } else if (this.inAir.getValue() || this.mc.field_1724.method_24828()) {
         if (this.mc.field_1724.method_24828()) {
            this.jumpedWhileHitting = false;
         }

         if (GLFW.glfwGetKey(this.mc.method_22683().method_4490(), 32) != 1 || this.inAir.getValue() || !this.holdingForward && !this.sprinting) {
            if (this.holdingForward && this.tapTimer.delay(1.0F)) {
               this.mc.field_1690.field_1894.method_23481(false);
               this.sprintTimer.reset();
               this.sprinting = true;
               this.holdingForward = false;
            }

            if (this.sprinting && this.sprintTimer.delay((float)this.currentDelay)) {
               this.mc.field_1690.field_1894.method_23481(true);
               this.sprinting = false;
               this.currentDelay = this.delay.getRandomValueInt();
            }

         } else {
            this.mc.field_1690.field_1894.method_23481(true);
            this.holdingForward = false;
            this.sprinting = false;
         }
      }
   }

   public void onPacketSend(PacketSendListener.PacketSendEvent event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof class_2824) {
         class_2824 packet = (class_2824)var3;
         packet.method_34209(new class_5908() {
            public void method_34219(class_1268 hand) {
            }

            public void method_34220(class_1268 hand, class_243 pos) {
            }

            public void method_34218() {
               if (GLFW.glfwGetKey(AutoWTap.this.mc.method_22683().method_4490(), 32) == 1 && !AutoWTap.this.inAir.getValue()) {
                  AutoWTap.this.jumpedWhileHitting = true;
               }

               if (AutoWTap.this.inAir.getValue() || AutoWTap.this.mc.field_1724.method_24828()) {
                  if (!AutoWTap.this.jumpedWhileHitting && AutoWTap.this.mc.field_1690.field_1894.method_1434() && AutoWTap.this.mc.field_1724.method_5624()) {
                     AutoWTap.this.sprintTimer.reset();
                     AutoWTap.this.holdingForward = true;
                  }

               }
            }
         });
      }
   }
}
