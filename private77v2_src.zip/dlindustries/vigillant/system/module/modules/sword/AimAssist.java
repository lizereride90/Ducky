package dlindustries.vigillant.system.module.modules.sword;

import dlindustries.vigillant.system.event.events.HudListener;
import dlindustries.vigillant.system.event.events.MouseMoveListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.MinMaxSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.MathUtils;
import dlindustries.vigillant.system.utils.RotationUtils;
import dlindustries.vigillant.system.utils.TimerUtils;
import dlindustries.vigillant.system.utils.WorldUtils;
import dlindustries.vigillant.system.utils.rotation.Rotation;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1829;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_9362;
import net.minecraft.class_9779;
import org.lwjgl.glfw.GLFW;

public final class AimAssist extends Module implements HudListener, MouseMoveListener {
   private final BooleanSetting stickyAim = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Sticky Aim"), false)).setDescription(EncryptedString.of("Aims at the last attacked player"));
   private final BooleanSetting onlyWeapon = new BooleanSetting(EncryptedString.of("Only Weapon"), true);
   private final BooleanSetting mace = new BooleanSetting(EncryptedString.of("Only mace"), true);
   private final BooleanSetting onLeftClick = (BooleanSetting)(new BooleanSetting(EncryptedString.of("On Left Click"), false)).setDescription(EncryptedString.of("Only gets triggered if holding down left click"));
   private final ModeSetting<AimAssist.AimMode> aimAt;
   private final BooleanSetting stopAtTargetVertical;
   private final BooleanSetting stopAtTargetHorizontal;
   private final NumberSetting radius;
   private final BooleanSetting seeOnly;
   private final BooleanSetting lookAtNearest;
   private final NumberSetting fov;
   private final MinMaxSetting pitchSpeed;
   private final MinMaxSetting yawSpeed;
   private final NumberSetting speedChange;
   private final NumberSetting randomization;
   private final BooleanSetting yawAssist;
   private final BooleanSetting pitchAssist;
   private final NumberSetting waitFor;
   private final ModeSetting<AimAssist.LerpMode> lerp;
   private final ModeSetting<AimAssist.PosMode> posMode;
   private final TimerUtils timer;
   private final TimerUtils resetSpeed;
   private boolean move;
   private float pitch;
   private float yaw;

   public AimAssist() {
      super(EncryptedString.of("Aim Assist"), EncryptedString.of("Automatically aims at players for you"), -1, Category.sword);
      this.aimAt = new ModeSetting(EncryptedString.of("Aim At"), AimAssist.AimMode.Head, AimAssist.AimMode.class);
      this.stopAtTargetVertical = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Stop at Target Vert"), true)).setDescription(EncryptedString.of("Stops vertically assisting if already aiming at the entity, helps bypass anti-cheat"));
      this.stopAtTargetHorizontal = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Stop at Target Horiz"), false)).setDescription(EncryptedString.of("Stops horizontally assisting if already aiming at the entity, helps bypass anti-cheat"));
      this.radius = new NumberSetting(EncryptedString.of("Radius"), 0.1D, 6.0D, 5.0D, 0.1D);
      this.seeOnly = new BooleanSetting(EncryptedString.of("See Only"), true);
      this.lookAtNearest = new BooleanSetting(EncryptedString.of("Look at Nearest"), false);
      this.fov = new NumberSetting(EncryptedString.of("FOV"), 5.0D, 360.0D, 100.0D, 1.0D);
      this.pitchSpeed = new MinMaxSetting(EncryptedString.of("Vertical Speed"), 0.0D, 10.0D, 0.1D, 2.0D, 4.0D);
      this.yawSpeed = new MinMaxSetting(EncryptedString.of("Horizontal Speed"), 0.0D, 10.0D, 0.1D, 2.0D, 4.0D);
      this.speedChange = (NumberSetting)(new NumberSetting(EncryptedString.of("Speed Delay"), 0.0D, 1000.0D, 250.0D, 1.0D)).setDescription(EncryptedString.of("Time in milliseconds to wait after resetting random speed"));
      this.randomization = new NumberSetting(EncryptedString.of("Chance"), 0.0D, 100.0D, 50.0D, 1.0D);
      this.yawAssist = new BooleanSetting(EncryptedString.of("Horizontal"), true);
      this.pitchAssist = new BooleanSetting(EncryptedString.of("Vertical"), true);
      this.waitFor = (NumberSetting)(new NumberSetting(EncryptedString.of("Wait on Move"), 0.0D, 1000.0D, 0.0D, 1.0D)).setDescription(EncryptedString.of("After you move your mouse aim assist will stop working for the selected amount of time"));
      this.lerp = (ModeSetting)(new ModeSetting(EncryptedString.of("Lerp"), AimAssist.LerpMode.Normal, AimAssist.LerpMode.class)).setDescription(EncryptedString.of("Linear interpolation to use to rotate"));
      this.posMode = (ModeSetting)(new ModeSetting(EncryptedString.of("Pos mode"), AimAssist.PosMode.Normal, AimAssist.PosMode.class)).setDescription(EncryptedString.of("Precision of the target position"));
      this.timer = new TimerUtils();
      this.resetSpeed = new TimerUtils();
      this.addSettings(new Setting[]{this.stickyAim, this.onlyWeapon, this.mace, this.onLeftClick, this.aimAt, this.stopAtTargetVertical, this.stopAtTargetHorizontal, this.radius, this.seeOnly, this.lookAtNearest, this.fov, this.pitchSpeed, this.yawSpeed, this.speedChange, this.randomization, this.yawAssist, this.pitchAssist, this.waitFor, this.lerp, this.posMode});
   }

   public void onEnable() {
      this.move = true;
      this.pitch = this.pitchSpeed.getRandomValueFloat();
      this.yaw = this.yawSpeed.getRandomValueFloat();
      this.eventManager.add(HudListener.class, this);
      this.eventManager.add(MouseMoveListener.class, this);
      this.timer.reset();
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(HudListener.class, this);
      this.eventManager.remove(MouseMoveListener.class, this);
      super.onDisable();
   }

   public void onRenderHud(HudListener.HudEvent event) {
      if (this.timer.delay(this.waitFor.getValueFloat()) && !this.move) {
         this.move = true;
         this.timer.reset();
      }

      if (this.mc.field_1724 != null && this.mc.field_1755 == null) {
         class_1792 heldItem = this.mc.field_1724.method_6047().method_7909();
         if (this.mace.getValue()) {
            if (!(heldItem instanceof class_9362)) {
               return;
            }
         } else if (this.onlyWeapon.getValue() && !(heldItem instanceof class_1829) && !(heldItem instanceof class_1743) && !(heldItem instanceof class_9362)) {
            return;
         }

         if (!this.onLeftClick.getValue() || GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 0) == 1) {
            class_1657 target = WorldUtils.findNearestPlayer(this.mc.field_1724, this.radius.getValueFloat(), this.seeOnly.getValue(), true);
            if (this.stickyAim.getValue()) {
               class_1309 var5 = this.mc.field_1724.method_6052();
               if (var5 instanceof class_1657) {
                  class_1657 player = (class_1657)var5;
                  if ((double)player.method_5739(this.mc.field_1724) < this.radius.getValue()) {
                     target = player;
                  }
               }
            }

            if (target != null) {
               if (this.resetSpeed.delay(this.speedChange.getValueFloat())) {
                  this.pitch = this.pitchSpeed.getRandomValueFloat();
                  this.yaw = this.yawSpeed.getRandomValueFloat();
                  this.resetSpeed.reset();
               }

               class_243 targetPos = this.posMode.isMode(AimAssist.PosMode.Normal) ? target.method_19538() : target.method_30950(class_9779.field_51956.method_60637(true));
               if (this.aimAt.isMode(AimAssist.AimMode.Chest)) {
                  targetPos = targetPos.method_1031(0.0D, -0.5D, 0.0D);
               } else if (this.aimAt.isMode(AimAssist.AimMode.Legs)) {
                  targetPos = targetPos.method_1031(0.0D, -1.2D, 0.0D);
               }

               if (this.lookAtNearest.getValue()) {
                  double offsetX = this.mc.field_1724.method_23317() - target.method_23317() > 0.0D ? 0.29D : -0.29D;
                  double offsetZ = this.mc.field_1724.method_23321() - target.method_23321() > 0.0D ? 0.29D : -0.29D;
                  targetPos = targetPos.method_1031(offsetX, 0.0D, offsetZ);
               }

               Rotation rotation = RotationUtils.getDirection(this.mc.field_1724, targetPos);
               double angleToRotation = RotationUtils.getAngleToRotation(rotation);
               if (!(angleToRotation > (double)this.fov.getValueInt() / 2.0D)) {
                  float yawStrength = this.yaw / 50.0F;
                  float pitchStrength = this.pitch / 50.0F;
                  float yaw = this.mc.field_1724.method_36454();
                  float pitch = this.mc.field_1724.method_36455();
                  if (this.lerp.isMode(AimAssist.LerpMode.Smoothstep)) {
                     yaw = (float)this.smoothStepLerp((double)yawStrength, (double)this.mc.field_1724.method_36454(), (double)((float)rotation.yaw()));
                     pitch = (float)this.smoothStepLerp((double)pitchStrength, (double)this.mc.field_1724.method_36455(), (double)((float)rotation.pitch()));
                  }

                  if (this.lerp.isMode(AimAssist.LerpMode.Normal)) {
                     yaw = this.lerp(yawStrength, this.mc.field_1724.method_36454(), (float)rotation.yaw());
                     pitch = this.lerp(pitchStrength, this.mc.field_1724.method_36455(), (float)rotation.pitch());
                  }

                  if (this.lerp.isMode(AimAssist.LerpMode.EaseOut)) {
                     yaw = (float)easeOutBackDegrees((double)this.mc.field_1724.method_36454(), rotation.yaw(), yawStrength * class_9779.field_51956.method_60636());
                     pitch = (float)easeOutBackDegrees((double)this.mc.field_1724.method_36455(), rotation.pitch(), pitchStrength * class_9779.field_51956.method_60636());
                  }

                  if (MathUtils.randomInt(1, 100) <= this.randomization.getValueInt() && this.move) {
                     class_3966 hitResult;
                     class_239 var13;
                     if (this.yawAssist.getValue()) {
                        if (this.stopAtTargetHorizontal.getValue()) {
                           var13 = WorldUtils.getHitResult(this.radius.getValue());
                           if (var13 instanceof class_3966) {
                              hitResult = (class_3966)var13;
                              if (hitResult.method_17782() == target) {
                                 return;
                              }
                           }
                        }

                        this.mc.field_1724.method_36456(yaw);
                     }

                     if (this.pitchAssist.getValue()) {
                        if (this.stopAtTargetVertical.getValue()) {
                           var13 = WorldUtils.getHitResult(this.radius.getValue());
                           if (var13 instanceof class_3966) {
                              hitResult = (class_3966)var13;
                              if (hitResult.method_17782() == target) {
                                 return;
                              }
                           }
                        }

                        this.mc.field_1724.method_36457(pitch);
                     }
                  }

               }
            }
         }
      }
   }

   public float lerp(float delta, float start, float end) {
      return start + class_3532.method_15393(end - start) * delta;
   }

   public static double easeOutBackDegrees(double start, double end, float speed) {
      double c1 = 1.70158D;
      double c3 = 2.70158D;
      double x = 1.0D - Math.pow(1.0D - (double)speed, 3.0D);
      return start + class_3532.method_15338(end - start) * (1.0D + c3 * Math.pow(x - 1.0D, 3.0D) + c1 * Math.pow(x - 1.0D, 2.0D));
   }

   public double smoothStepLerp(double delta, double start, double end) {
      delta = Math.max(0.0D, Math.min(1.0D, delta));
      double t = delta * delta * (3.0D - 2.0D * delta);
      double value = start + class_3532.method_15338(end - start) * t;
      return value;
   }

   public void onMouseMove(MouseMoveListener.MouseMoveEvent event) {
      this.move = false;
      this.timer.reset();
   }

   public static enum AimMode {
      Head,
      Chest,
      Legs;

      // $FF: synthetic method
      private static AimAssist.AimMode[] $values() {
         return new AimAssist.AimMode[]{Head, Chest, Legs};
      }
   }

   public static enum LerpMode {
      Normal,
      Smoothstep,
      EaseOut;

      // $FF: synthetic method
      private static AimAssist.LerpMode[] $values() {
         return new AimAssist.LerpMode[]{Normal, Smoothstep, EaseOut};
      }
   }

   public static enum PosMode {
      Normal,
      Lerped;

      // $FF: synthetic method
      private static AimAssist.PosMode[] $values() {
         return new AimAssist.PosMode[]{Normal, Lerped};
      }
   }
}
