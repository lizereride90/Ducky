package dlindustries.vigillant.system.module.modules.sword;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.MathUtils;

public final class AutoJumpReset extends Module implements TickListener {
   private final NumberSetting chance = new NumberSetting(EncryptedString.of("Chance"), 0.0D, 100.0D, 100.0D, 1.0D);
   private final BooleanSetting onHoldJump = new BooleanSetting(EncryptedString.of("On Hold Jump key only"), false);

   public AutoJumpReset() {
      super(EncryptedString.of("Jump Reset"), EncryptedString.of("Sword pvp technique to take less knockback - Do not enable for Crystal pvp"), -1, Category.sword);
      this.addSettings(new Setting[]{this.chance, this.onHoldJump});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      if (!this.onHoldJump.getValue() || this.mc.field_1690.field_1903.method_1434()) {
         if (MathUtils.randomInt(1, 100) <= this.chance.getValueInt()) {
            if (this.mc.field_1755 != null) {
               return;
            }

            if (this.mc.field_1724.method_6115()) {
               return;
            }

            if (this.mc.field_1724.field_6235 == 0) {
               return;
            }

            if (this.mc.field_1724.field_6235 == this.mc.field_1724.field_6254) {
               return;
            }

            if (!this.mc.field_1724.method_24828()) {
               return;
            }

            if (this.mc.field_1724.field_6235 == 9 && MathUtils.randomInt(1, 100) <= this.chance.getValueInt()) {
               this.mc.field_1724.method_6043();
            }
         }

      }
   }
}
