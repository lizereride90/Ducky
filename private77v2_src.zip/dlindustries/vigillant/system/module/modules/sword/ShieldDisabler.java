package dlindustries.vigillant.system.module.modules.sword;

import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.InventoryUtils;
import dlindustries.vigillant.system.utils.MouseSimulation;
import dlindustries.vigillant.system.utils.WorldUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

public final class ShieldDisabler extends Module implements TickListener, AttackListener {
   private final NumberSetting hitDelay = new NumberSetting(EncryptedString.of("Hit Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
   private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0.0D, 20.0D, 1.0D, 1.0D);
   private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
   private final BooleanSetting stun = new BooleanSetting(EncryptedString.of("Stun"), false);
   private final BooleanSetting stunSlam = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Stun Slam"), true)).setDescription(EncryptedString.of("Use mace for second hit instead of sword"));
   private final NumberSetting maceSlot = (NumberSetting)(new NumberSetting(EncryptedString.of("Mace Slot"), 1.0D, 9.0D, 1.0D, 1.0D)).setDescription(EncryptedString.of("Slot 1-9 for mace (for Stun Slam)"));
   private final BooleanSetting clickSimulate = new BooleanSetting(EncryptedString.of("Click Simulation"), true);
   private final BooleanSetting requireHoldAxe = new BooleanSetting(EncryptedString.of("Hold Axe"), false);
   private int originalSlot = -1;
   private int hitClock;
   private int switchClock;
   private boolean inStunSequence;
   private int stunStep;

   public ShieldDisabler() {
      super(EncryptedString.of("Shield Disabler"), EncryptedString.of("Automatically disables your opponents shield"), -1, Category.sword);
      this.addSettings(new Setting[]{this.switchDelay, this.hitDelay, this.switchBack, this.stun, this.stunSlam, this.maceSlot, this.clickSimulate, this.requireHoldAxe});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.eventManager.add(AttackListener.class, this);
      this.hitClock = this.hitDelay.getValueInt();
      this.switchClock = this.switchDelay.getValueInt();
      this.originalSlot = -1;
      this.inStunSequence = false;
      this.stunStep = 0;
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      this.eventManager.remove(AttackListener.class, this);
      this.restoreOriginalSlot();
      super.onDisable();
   }

   public void onTick() {
      if (this.mc.field_1755 == null) {
         if (!this.requireHoldAxe.getValue() || this.mc.field_1724.method_6047().method_7909() instanceof class_1743) {
            if (this.inStunSequence) {
               this.handleStunSequence();
            } else {
               class_239 var2 = this.mc.field_1765;
               if (!(var2 instanceof class_3966)) {
                  if (this.originalSlot != -1) {
                     this.restoreOriginalSlot();
                  }

               } else {
                  class_3966 entityHit = (class_3966)var2;
                  class_1297 entity = entityHit.method_17782();
                  if (entity != this.mc.field_1724 && entity instanceof class_1309) {
                     if (!this.mc.field_1724.method_6115()) {
                        if (entity instanceof class_1657) {
                           class_1657 player = (class_1657)entity;
                           if (WorldUtils.isShieldFacingAway(player)) {
                              return;
                           }

                           if (player.method_24518(class_1802.field_8255) && player.method_6039()) {
                              if (this.originalSlot == -1) {
                                 this.originalSlot = this.mc.field_1724.method_31548().field_7545;
                              }

                              if (this.switchClock > 0) {
                                 --this.switchClock;
                                 return;
                              }

                              if (InventoryUtils.selectAxe()) {
                                 if (this.hitClock > 0) {
                                    --this.hitClock;
                                 } else {
                                    if (this.clickSimulate.getValue()) {
                                       MouseSimulation.mouseClick(0);
                                    }

                                    WorldUtils.hitEntity(player, true);
                                    if (this.stun.getValue()) {
                                       this.inStunSequence = true;
                                       this.stunStep = 1;
                                    } else {
                                       this.hitClock = this.hitDelay.getValueInt();
                                       this.switchClock = this.switchDelay.getValueInt();
                                       this.restoreOriginalSlot();
                                    }
                                 }
                              }
                           } else if (this.originalSlot != -1) {
                              this.restoreOriginalSlot();
                           }
                        }

                     }
                  }
               }
            }
         }
      }
   }

   private void handleStunSequence() {
      if (this.mc.field_1724 == null) {
         this.resetSequence();
      } else {
         switch(this.stunStep) {
         case 1:
            if (this.stunSlam.getValue()) {
               this.mc.field_1724.method_31548().field_7545 = this.maceSlot.getValueInt() - 1;
            }

            this.stunStep = 2;
            break;
         case 2:
            class_239 var2 = this.mc.field_1765;
            if (var2 instanceof class_3966) {
               class_3966 entityHit = (class_3966)var2;
               class_1297 entity = entityHit.method_17782();
               if (entity != null) {
                  if (this.clickSimulate.getValue()) {
                     MouseSimulation.mouseClick(0);
                  }

                  WorldUtils.hitEntity(entity, true);
               }
            }

            this.stunStep = 3;
            break;
         case 3:
            this.restoreOriginalSlot();
            this.resetSequence();
         }

      }
   }

   private void resetSequence() {
      this.inStunSequence = false;
      this.stunStep = 0;
      this.hitClock = this.hitDelay.getValueInt();
      this.switchClock = this.switchDelay.getValueInt();
   }

   private void restoreOriginalSlot() {
      if (this.switchBack.getValue() && this.originalSlot != -1) {
         if (this.switchDelay.getValueInt() > 0) {
            if (this.switchClock > 0) {
               --this.switchClock;
            } else {
               this.mc.field_1724.method_31548().field_7545 = this.originalSlot;
               this.originalSlot = -1;
            }
         } else {
            this.mc.field_1724.method_31548().field_7545 = this.originalSlot;
            this.originalSlot = -1;
         }
      }

   }

   public void onAttack(AttackListener.AttackEvent event) {
      if (GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 0) != 1) {
         event.cancel();
      }

   }
}
