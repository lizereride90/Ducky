package dlindustries.vigillant.system.module.modules.optimizer;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.utils.EncryptedString;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import org.lwjgl.glfw.GLFW;

public final class NoJumpDelay extends Module implements TickListener {
   private boolean wasJumping = false;

   public NoJumpDelay() {
      super(EncryptedString.of("No Jump Delay"), EncryptedString.of("Lets you jump faster."), -1, Category.optimizer);
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      if (this.mc.field_1755 == null && this.mc.field_1724 != null) {
         class_3610 fluidState = this.mc.field_1724.method_37908().method_8316(this.mc.field_1724.method_24515());
         if (!fluidState.method_15767(class_3486.field_15517) && !fluidState.method_15767(class_3486.field_15518)) {
            if (!this.mc.field_1724.method_24828()) {
               this.wasJumping = false;
            } else {
               boolean jumping = GLFW.glfwGetKey(this.mc.method_22683().method_4490(), 32) == 1;
               if (jumping && !this.wasJumping) {
                  this.mc.field_1690.field_1903.method_23481(false);
                  this.mc.field_1724.method_6043();
               }

               this.wasJumping = jumping;
            }
         } else {
            this.wasJumping = false;
         }
      }
   }
}
