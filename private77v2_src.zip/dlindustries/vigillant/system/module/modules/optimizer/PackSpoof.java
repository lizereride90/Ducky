package dlindustries.vigillant.system.module.modules.optimizer;

import dlindustries.vigillant.system.event.events.PacketReceiveListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.utils.EncryptedString;
import net.minecraft.class_2596;
import net.minecraft.class_2720;
import net.minecraft.class_2856;
import net.minecraft.class_2856.class_2857;

public class PackSpoof extends Module implements PacketReceiveListener {
   public PackSpoof() {
      super(EncryptedString.of("QoL Optimizer"), EncryptedString.of("Ignores custom resource packs"), -1, Category.optimizer);
   }

   public void onEnable() {
      this.eventManager.add(PacketReceiveListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(PacketReceiveListener.class, this);
      super.onDisable();
   }

   public void onPacketReceive(PacketReceiveListener.PacketReceiveEvent event) {
      if (this.mc.method_1562() != null) {
         class_2596<?> packet = event.packet;
         if (packet instanceof class_2720) {
            event.cancel();
            this.mc.method_1562().method_52787(new class_2856(this.mc.field_1724.method_5667(), class_2857.field_13016));
            this.mc.method_1562().method_52787(new class_2856(this.mc.field_1724.method_5667(), class_2857.field_13017));
         }
      }

   }
}
