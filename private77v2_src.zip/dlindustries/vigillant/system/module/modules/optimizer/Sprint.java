package dlindustries.vigillant.system.module.modules.optimizer;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import net.minecraft.class_1802;

public final class Sprint extends Module implements TickListener {
   private final BooleanSetting noSprintOnAnchor = new BooleanSetting(EncryptedString.of("No Sprint on Anchor"), false);
   private final BooleanSetting noSprintOnObsidian = new BooleanSetting(EncryptedString.of("No Sprint on Obsidian"), false);

   public Sprint() {
      super(EncryptedString.of("Sprint Optimizer"), EncryptedString.of("optimization for d-taps/sprinting ect - bypasses all anticheats."), -1, Category.optimizer);
      this.addSettings(new Setting[]{this.noSprintOnAnchor, this.noSprintOnObsidian});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      assert this.mc.field_1724 != null;

      boolean shouldSprint = true;
      if (this.noSprintOnObsidian.getValue() && this.mc.field_1724.method_6047().method_31574(class_1802.field_8281)) {
         shouldSprint = false;
      }

      if (this.noSprintOnAnchor.getValue() && this.mc.field_1724.method_6047().method_31574(class_1802.field_23141)) {
         shouldSprint = false;
      }

      if (shouldSprint) {
         this.mc.field_1724.method_5728(this.mc.field_1724.field_3913.field_3910);
      } else {
         this.mc.field_1724.method_5728(false);
      }

   }
}
