package dlindustries.vigillant.system.module.modules.optimizer;

import dlindustries.vigillant.system.event.events.CameraUpdateListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.KeybindSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.KeyUtils;

public final class CameraOptimizer extends Module implements CameraUpdateListener {
   private final KeybindSetting toggleKey = new KeybindSetting(EncryptedString.of("Toggle Key"), -1, false);
   private final BooleanSetting noClip = (BooleanSetting)(new BooleanSetting(EncryptedString.of("No Clip"), true)).setDescription(EncryptedString.of("Allows camera to pass through blocks"));
   private final BooleanSetting noOverlay = (BooleanSetting)(new BooleanSetting(EncryptedString.of("No Overlay"), true)).setDescription(EncryptedString.of("Removes water/lava visual effects"));

   public CameraOptimizer() {
      super(EncryptedString.of("Camera Optimizer"), EncryptedString.of("Improves camera behavior and removes restrictions"), -1, Category.RENDER);
      this.addSettings(new Setting[]{this.toggleKey, this.noClip, this.noOverlay});
   }

   public void onEnable() {
      this.eventManager.add(CameraUpdateListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(CameraUpdateListener.class, this);
      super.onDisable();
   }

   public void onCameraUpdate(CameraUpdateListener.CameraUpdateEvent event) {
   }

   public boolean isToggleKeyPressed() {
      return this.toggleKey.getKey() != -1 && KeyUtils.isKeyPressed(this.toggleKey.getKey());
   }

   public boolean isNoClipEnabled() {
      return this.isEnabled() && this.noClip.getValue() && this.isToggleKeyPressed();
   }

   public boolean isNoOverlayEnabled() {
      return this.isEnabled() && this.noOverlay.getValue() && this.isToggleKeyPressed();
   }
}
