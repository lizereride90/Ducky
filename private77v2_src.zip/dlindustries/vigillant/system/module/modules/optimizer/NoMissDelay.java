package dlindustries.vigillant.system.module.modules.optimizer;

import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.BlockBreakingListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1829;
import net.minecraft.class_9362;
import net.minecraft.class_239.class_240;

public final class NoMissDelay extends Module implements AttackListener, BlockBreakingListener {
   private final ModeSetting<NoMissDelay.Mode> mode;
   private final BooleanSetting air;
   private final BooleanSetting blocks;

   public NoMissDelay() {
      super(EncryptedString.of("Triggerbot Optimizer"), EncryptedString.of("Only allows you to do more actions with triggerbot"), -1, Category.optimizer);
      this.mode = new ModeSetting(EncryptedString.of("Mode"), NoMissDelay.Mode.MACE, NoMissDelay.Mode.class);
      this.air = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Air"), true)).setDescription(EncryptedString.of("Whether to stop hits directed to the air"));
      this.blocks = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Blocks"), false)).setDescription(EncryptedString.of("Whether to stop hits directed to blocks"));
      this.addSettings(new Setting[]{this.mode, this.air, this.blocks});
   }

   public void onEnable() {
      this.eventManager.add(AttackListener.class, this);
      this.eventManager.add(BlockBreakingListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(AttackListener.class, this);
      this.eventManager.remove(BlockBreakingListener.class, this);
      super.onDisable();
   }

   public void onAttack(AttackListener.AttackEvent event) {
      class_1792 heldItem = this.mc.field_1724.method_6047().method_7909();
      if (!this.shouldSkipAttack(heldItem)) {
         switch(this.mc.field_1765.method_17783()) {
         case field_1333:
            if (this.air.getValue()) {
               event.cancel();
            }
            break;
         case field_1332:
            if (this.blocks.getValue()) {
               event.cancel();
            }
         }

      }
   }

   private boolean shouldSkipAttack(class_1792 item) {
      if (this.mode.isMode(NoMissDelay.Mode.MACE)) {
         return !(item instanceof class_9362);
      } else if (this.mode.isMode(NoMissDelay.Mode.ONLY_WEAPONS)) {
         return !(item instanceof class_1829) && !(item instanceof class_1743) && !(item instanceof class_9362);
      } else if (!this.mode.isMode(NoMissDelay.Mode.MACE_AND_WEAPONS)) {
         return false;
      } else {
         return !(item instanceof class_9362) && !(item instanceof class_1829) && !(item instanceof class_1743);
      }
   }

   public void onBlockBreaking(BlockBreakingListener.BlockBreakingEvent event) {
      class_1792 heldItem = this.mc.field_1724.method_6047().method_7909();
      if (!this.mode.isMode(NoMissDelay.Mode.MACE) || heldItem instanceof class_9362) {
         if (!this.mode.isMode(NoMissDelay.Mode.ONLY_WEAPONS) || heldItem instanceof class_1829 || heldItem instanceof class_1743 || heldItem instanceof class_9362) {
            if (!this.mode.isMode(NoMissDelay.Mode.MACE_AND_WEAPONS) || heldItem instanceof class_9362 || heldItem instanceof class_1829 || heldItem instanceof class_1743) {
               if (this.mc.field_1765.method_17783() == class_240.field_1332 && this.blocks.getValue()) {
                  event.cancel();
               }

            }
         }
      }
   }

   public static enum Mode {
      MACE("Mace"),
      ONLY_WEAPONS("Only Weapons"),
      ALL_ITEMS("All Items"),
      MACE_AND_WEAPONS("Mace and Weapons");

      private final String name;

      private Mode(String name) {
         this.name = name;
      }

      public String toString() {
         return this.name;
      }

      // $FF: synthetic method
      private static NoMissDelay.Mode[] $values() {
         return new NoMissDelay.Mode[]{MACE, ONLY_WEAPONS, ALL_ITEMS, MACE_AND_WEAPONS};
      }
   }
}
