package dlindustries.vigillant.system.module.modules.optimizer;

import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1770;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_3966;
import net.minecraft.class_9362;
import net.minecraft.class_239.class_240;

public final class HitOptimizer extends Module implements AttackListener, TickListener {
   private final BooleanSetting requireSword = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Require Sword"), true)).setDescription(EncryptedString.of("Only switch if sword is available"));
   private final BooleanSetting switchBack = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Switch Back"), true)).setDescription(EncryptedString.of("Switch back to original slot after attack"));
   private final NumberSetting switchDelay = (NumberSetting)(new NumberSetting(EncryptedString.of("Switch Delay"), 0.0D, 5.0D, 1.0D, 1.0D)).setDescription(EncryptedString.of("Delay after attacking before switching back"));
   private boolean shouldSwitchBack;
   private int originalSlot = -1;
   private int switchTimer;

   public HitOptimizer() {
      super(EncryptedString.of("Hit Optimizer"), EncryptedString.of("Automatically switches to sword for attacks / make sure they take KB"), -1, Category.optimizer);
      this.addSettings(new Setting[]{this.requireSword, this.switchBack, this.switchDelay});
   }

   public void onEnable() {
      this.eventManager.add(AttackListener.class, this);
      this.eventManager.add(TickListener.class, this);
      this.resetState();
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(AttackListener.class, this);
      this.eventManager.remove(TickListener.class, this);
      if (this.shouldSwitchBack && this.originalSlot != -1) {
         this.mc.field_1724.method_31548().field_7545 = this.originalSlot;
      }

      super.onDisable();
   }

   public void onAttack(AttackListener.AttackEvent event) {
      if (this.mc.field_1765 != null && this.mc.field_1765.method_17783() == class_240.field_1331) {
         class_1297 target = ((class_3966)this.mc.field_1765).method_17782();
         if (target != null) {
            class_1799 currentStack = this.mc.field_1724.method_6047();
            class_1792 currentItem = currentStack.method_7909();
            if (!this.isWeapon(currentItem)) {
               if (this.shouldSwitchBack) {
                  this.switchTimer = 0;
               } else {
                  if (this.requireSword.getValue()) {
                     int swordSlot = this.findSwordSlot();
                     if (swordSlot == -1) {
                        return;
                     }

                     if (this.switchBack.getValue() && this.originalSlot == -1) {
                        this.originalSlot = this.mc.field_1724.method_31548().field_7545;
                     }

                     this.mc.field_1724.method_31548().field_7545 = swordSlot;
                     if (this.switchBack.getValue()) {
                        this.shouldSwitchBack = true;
                        this.switchTimer = 0;
                     }
                  }

               }
            }
         }
      }
   }

   public void onTick() {
      if (this.shouldSwitchBack && this.originalSlot != -1) {
         if (this.switchTimer < this.switchDelay.getValueInt()) {
            ++this.switchTimer;
         } else {
            this.mc.field_1724.method_31548().field_7545 = this.originalSlot;
            this.resetState();
         }
      }
   }

   private void resetState() {
      this.shouldSwitchBack = false;
      this.originalSlot = -1;
      this.switchTimer = 0;
   }

   private boolean isWeapon(class_1792 item) {
      return item instanceof class_1829 || item instanceof class_1743 || item instanceof class_9362 || item instanceof class_1770 || item instanceof class_1738 && ((class_1738)item).method_7685() == class_1304.field_6174;
   }

   private int findSwordSlot() {
      for(int slot = 0; slot < 9; ++slot) {
         class_1799 stack = this.mc.field_1724.method_31548().method_5438(slot);
         if (stack.method_7909() instanceof class_1829) {
            return slot;
         }
      }

      return -1;
   }
}
