package dlindustries.vigillant.system.module.modules.optimizer;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;

public final class PlacementOptimizer extends Module implements TickListener {
   private final BooleanSetting excludeAnchors = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Exclude Anchors/Glowstone"), true)).setDescription(EncryptedString.of("Keeps vanilla delays for anchors and glowstone - keeps anchor macro look legit"));
   private final NumberSetting blockDelay = (NumberSetting)(new NumberSetting(EncryptedString.of("Block delay"), 0.0D, 5.0D, 3.0D, 0.1D)).setDescription(EncryptedString.of("Default vanilla block placement delay is 5 ticks"));
   private final NumberSetting crystalDelay = (NumberSetting)(new NumberSetting(EncryptedString.of("Crystal delay"), 0.0D, 2.0D, 0.0D, 1.0D)).setDescription(EncryptedString.of("Default Vanilla crystal placement delay is 2 ticks"));

   public PlacementOptimizer() {
      super(EncryptedString.of("Placement Optimizer"), EncryptedString.of("Adjusts block/crystal placement delays"), -1, Category.optimizer);
      this.addSettings(new Setting[]{this.excludeAnchors, this.blockDelay, this.crystalDelay});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      super.onDisable();
   }

   public void onTick() {
   }

   public boolean shouldExcludeAnchors() {
      return this.excludeAnchors.getValue();
   }

   public int getBlockDelay() {
      return this.blockDelay.getValueInt();
   }

   public int getCrystalDelay() {
      return this.crystalDelay.getValueInt();
   }
}
