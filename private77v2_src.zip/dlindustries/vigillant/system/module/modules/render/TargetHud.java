package dlindustries.vigillant.system.module.modules.render;

import dlindustries.vigillant.system.event.events.HudListener;
import dlindustries.vigillant.system.event.events.PacketSendListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.MathUtils;
import dlindustries.vigillant.system.utils.RenderUtils;
import dlindustries.vigillant.system.utils.TextRenderer;
import java.awt.Color;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_640;
import net.minecraft.class_7532;
import net.minecraft.class_7833;
import net.minecraft.class_2824.class_5908;

public final class TargetHud extends Module implements HudListener, PacketSendListener {
   private final NumberSetting xCoord = new NumberSetting(EncryptedString.of("X"), 0.0D, 1920.0D, 500.0D, 1.0D);
   private final NumberSetting yCoord = new NumberSetting(EncryptedString.of("Y"), 0.0D, 1080.0D, 500.0D, 1.0D);
   private final BooleanSetting hudTimeout = (BooleanSetting)(new BooleanSetting(EncryptedString.of("Timeout"), true)).setDescription(EncryptedString.of("Target hud will disappear after 10 seconds"));
   private static final Color PANEL_COLOR = new Color(10, 10, 20, 220);
   private static final Color MAIN_COLOR = new Color(102, 0, 255, 255);
   private static final Color GLOW_COLOR = new Color(64, 0, 255, 100);
   private static final Color ACCENT_COLOR = new Color(7, 0, 200, 255);
   private static final int PANEL_WIDTH = 340;
   private static final int PANEL_HEIGHT = 200;
   private static final int BORDER_RADIUS = 8;
   private long lastAttackTime = 0L;
   public static float animation;
   private static final long timeout = 10000L;

   public TargetHud() {
      super(EncryptedString.of("Target HUD"), EncryptedString.of("Gives you information about the enemy player"), -1, Category.RENDER);
      this.addSettings(new Setting[]{this.xCoord, this.yCoord, this.hudTimeout});
   }

   public void onEnable() {
      this.eventManager.add(HudListener.class, this);
      this.eventManager.add(PacketSendListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(HudListener.class, this);
      this.eventManager.remove(PacketSendListener.class, this);
      super.onDisable();
   }

   public void onRenderHud(HudListener.HudEvent event) {
      label79: {
         class_332 context = event.context;
         int x = this.xCoord.getValueInt();
         int y = this.yCoord.getValueInt();
         RenderUtils.unscaledProjection();
         if ((!this.hudTimeout.getValue() || System.currentTimeMillis() - this.lastAttackTime <= 10000L) && this.mc.field_1724.method_6052() != null) {
            class_1309 var6 = this.mc.field_1724.method_6052();
            if (var6 instanceof class_1657) {
               class_1657 player = (class_1657)var6;
               if (player.method_5805()) {
                  float var10000;
                  byte var10001;
                  label58: {
                     var10000 = animation;
                     class_1309 var7 = this.mc.field_1724.method_6052();
                     if (var7 instanceof class_1657) {
                        class_1657 player1 = (class_1657)var7;
                        if (player1.method_5805()) {
                           var10001 = 0;
                           break label58;
                        }
                     }

                     var10001 = 1;
                  }

                  animation = RenderUtils.fast(var10000, (float)var10001, 15.0F);
                  class_640 entry = this.mc.method_1562().method_2871(player.method_5667());
                  float tx = (float)x;
                  float ty = (float)y;
                  class_4587 matrixStack = context.method_51448();
                  float thetaRotation = 90.0F * animation;
                  matrixStack.method_22903();
                  matrixStack.method_46416(tx, ty, 0.0F);
                  matrixStack.method_22907(class_7833.field_40716.rotationDegrees(thetaRotation));
                  matrixStack.method_46416(-tx, -ty, 0.0F);
                  RenderUtils.renderRoundedQuad(matrixStack, PANEL_COLOR, (double)x, (double)y, (double)(x + 340), (double)(y + 200), 8.0D, 8.0D, 8.0D, 8.0D, 10.0D);

                  int infoY;
                  for(infoY = 0; infoY < 3; ++infoY) {
                     RenderUtils.renderRoundedOutline(context, GLOW_COLOR, (double)(x - infoY), (double)(y - infoY), (double)(x + 340 + infoY), (double)(y + 200 + infoY), 8.0D, 8.0D, 8.0D, 8.0D, 1.0D, 10.0D);
                  }

                  RenderUtils.renderRoundedOutline(context, MAIN_COLOR, (double)x, (double)y, (double)(x + 340), (double)(y + 200), 8.0D, 8.0D, 8.0D, 8.0D, 1.0D, 10.0D);
                  RenderUtils.renderRoundedQuad(matrixStack, MAIN_COLOR, (double)x, (double)(y + 27), (double)(x + 340), (double)(y + 29), 0.0D, 0.0D, 0.0D, 0.0D, 10.0D);
                  TextRenderer.drawString(player.method_5477().getString() + " §8| §b" + MathUtils.roundToDecimal((double)player.method_5739(this.mc.field_1724), 0.5D) + " blocks", context, x + 28, y + 8, Color.WHITE.getRGB());
                  if (entry != null) {
                     class_7532.method_44443(context, entry.method_52810().comp_1626(), x + 5, y + 5, 20);
                  }

                  infoY = y + 35;
                  int lineHeight = 25;
                  TextRenderer.drawString("§7Type: " + (entry == null ? "§cBot" : "§aPlayer"), context, x + 5, infoY, Color.WHITE.getRGB());
                  infoY += lineHeight;
                  float health = player.method_6032() + player.method_6067();
                  String var20 = String.format("%.1f❤", health);
                  TextRenderer.drawString("§7Health: §a" + var20, context, x + 5, infoY, Color.WHITE.getRGB());
                  infoY += lineHeight;
                  TextRenderer.drawString("§7Invisible: " + (player.method_5767() ? "§cYes" : "§aNo"), context, x + 5, infoY, Color.WHITE.getRGB());
                  infoY += lineHeight;
                  int healthHeight;
                  if (entry != null) {
                     healthHeight = entry.method_2959();
                     Color pingColor = healthHeight < 100 ? Color.GREEN : (healthHeight < 200 ? Color.YELLOW : Color.RED);
                     TextRenderer.drawString("§7Ping: " + healthHeight + "ms", context, x + 5, infoY, pingColor.getRGB());
                     int var21 = infoY + lineHeight;
                  }

                  healthHeight = Math.min(Math.round(health * 5.0F), 171);
                  int barX = x + 340 - 8;
                  context.method_25294(barX, y + 200, barX + 4, y + 200 - 171, (new Color(30, 30, 40, 200)).getRGB());
                  context.method_25294(barX, y + 200, barX + 4, y + 200 - healthHeight, this.getHealthColor(health).getRGB());
                  RenderUtils.renderRoundedOutline(context, GLOW_COLOR, (double)(barX - 1), (double)(y + 200 - healthHeight - 1), (double)(barX + 5), (double)(y + 201), 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 10.0D);
                  if (player.field_6235 != 0) {
                     TextRenderer.drawString("§7Damage Tick: " + player.field_6235, context, x + 125, y + 35, Color.WHITE.getRGB());
                     context.method_25294(x + 125, y + 55, x + 125 + player.field_6235 * 15, y + 58, this.getDamageTickColor(player.field_6235).getRGB());
                     RenderUtils.renderRoundedOutline(context, GLOW_COLOR, (double)(x + 124), (double)(y + 54), (double)(x + 125 + player.field_6235 * 15 + 1), (double)(y + 59), 0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 10.0D);
                  }

                  matrixStack.method_22909();
                  break label79;
               }
            }
         }

         animation = RenderUtils.fast(animation, 1.0F, 15.0F);
      }

      RenderUtils.scaledProjection();
   }

   private Color getHealthColor(float health) {
      if (health > 15.0F) {
         return new Color(0, 255, 0);
      } else if (health > 10.0F) {
         return new Color(255, 255, 0);
      } else {
         return health > 5.0F ? new Color(255, 165, 0) : new Color(255, 0, 0);
      }
   }

   private Color getDamageTickColor(int hurtTime) {
      float progress = (float)hurtTime / 10.0F;
      return new Color((int)(255.0F * (1.0F - progress)), (int)(255.0F * progress), 0);
   }

   public void onPacketSend(PacketSendListener.PacketSendEvent event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof class_2824) {
         class_2824 packet = (class_2824)var3;
         packet.method_34209(new class_5908() {
            public void method_34219(class_1268 hand) {
            }

            public void method_34220(class_1268 hand, class_243 pos) {
            }

            public void method_34218() {
               if (TargetHud.this.mc.field_1692 instanceof class_1657) {
                  TargetHud.this.lastAttackTime = System.currentTimeMillis();
               }

            }
         });
      }

   }
}
