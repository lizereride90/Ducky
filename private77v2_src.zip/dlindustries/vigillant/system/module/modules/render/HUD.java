package dlindustries.vigillant.system.module.modules.render;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.event.events.HudListener;
import dlindustries.vigillant.system.gui.ClickGui;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.RenderUtils;
import dlindustries.vigillant.system.utils.TextRenderer;
import dlindustries.vigillant.system.utils.Utils;
import java.awt.Color;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public final class HUD extends Module implements HudListener {

    private final BooleanSetting info    = new BooleanSetting(EncryptedString.of("Info"), true);
    private final BooleanSetting modules = (BooleanSetting)(new BooleanSetting("Modules", false))
        .setDescription(EncryptedString.of("Renders module array list"));

    public HUD() {
        super(EncryptedString.of("HUD"), EncryptedString.of("Overlay the system as you play"), -1, Category.RENDER);
        this.addSettings(new Setting[]{this.info, this.modules});
    }

    public void onEnable()  { this.eventManager.add(HudListener.class,    this); super.onEnable(); }
    public void onDisable() { this.eventManager.remove(HudListener.class, this); super.onDisable(); }

    public void onRenderHud(HudListener.HudEvent event) {
        if (this.mc.field_1755 == dlindustries.vigillant.system.system.INSTANCE.clickGui) return;
        if (this.mc.field_1755 instanceof ClickGui) return;

        class_332 context = event.context;
        boolean customFont = ClickGUI.customFont.getValue();

        // ── Info bar (top-left) ────────────────────────────────────────
        if (this.info.getValue() && this.mc.field_1724 != null) {
            RenderUtils.unscaledProjection();
            class_2960 hudIconId = class_2960.method_60655("system", "images/cat.png");
            int iconSize = 52, iconX = 8, iconY = 8;
            String playerName  = this.mc.field_1724.method_5477().getString();
            String serverName  = this.mc.method_1558() == null ? "None" : this.mc.method_1558().field_3761;
            String hudText     = "private77v2  |  " + playerName + "  |  " + serverName;
            int textX = iconX + iconSize + 8;
            Objects.requireNonNull(this.mc.field_1772);
            int textY    = iconY + (iconSize - 9) / 2;
            int textWidth = TextRenderer.getWidth(hudText);
            int padX = 8, padY = 8;

            RenderUtils.renderRoundedQuad(context.method_51448(),
                new Color(14, 14, 22, 190),
                iconX - padX, iconY - padY,
                textX + textWidth + padX, iconY + iconSize + padY,
                5.0, 12.0);
            context.method_25296(
                iconX - padX, iconY - padY + 3,
                iconX - padX + 2, iconY + iconSize + padY - 3,
                Utils.getMainColor(255, 0).getRGB(),
                Utils.getMainColor(255, 3).getRGB());
            context.method_25290(hudIconId, iconX, iconY, 0f, 0f, iconSize, iconSize, iconSize, iconSize);
            TextRenderer.drawString(hudText, context, textX, textY, Utils.getMainColor(255, 4).getRGB());
            RenderUtils.scaledProjection();
        }

        // ── Arraylist (right-anchored) ─────────────────────────────────
        if (this.modules.getValue()) {
            int offset = 5;
            List<Module> enabledModules = dlindustries.vigillant.system.system.INSTANCE
                .getModuleManager().getEnabledModules().stream()
                .sorted((m1, m2) -> Integer.compare(
                    TextRenderer.getWidth(m2.getName()),
                    TextRenderer.getWidth(m1.getName())))
                .toList();

            for (Module module : enabledModules) {
                RenderUtils.unscaledProjection();
                int tw  = TextRenderer.getWidth(module.getName());
                int sw  = this.mc.method_22683().method_4480();
                int idx = enabledModules.indexOf(module);
                int bx  = sw - tw - 16;
                int by  = offset;
                int bh  = 9 * 2;

                RenderUtils.renderRoundedQuad(context.method_51448(),
                    new Color(10, 10, 18, 175),
                    bx - 4, by - 2, sw, by + bh, 0.0, 0.0);
                context.method_25296(sw - 2, by, sw, by + bh,
                    Utils.getMainColor(255, idx).getRGB(),
                    Utils.getMainColor(255, idx + 1).getRGB());
                int cx = customFont ? 5 : 8;
                TextRenderer.drawString(module.getName(), context,
                    bx, by + (customFont ? 1 : 0),
                    Utils.getMainColor(255, idx).getRGB());
                Objects.requireNonNull(this.mc.field_1772);
                offset += bh + 2;
                RenderUtils.scaledProjection();
            }
        }
    }
}
