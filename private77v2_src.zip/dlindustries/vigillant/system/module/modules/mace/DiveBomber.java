package dlindustries.vigillant.system.module.modules.mace;

import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class DiveBomber extends Module implements TickListener, AttackListener {
   private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0.0D, 20.0D, 1.0D, 1.0D);
   private final NumberSetting chestplateSlot = (NumberSetting)(new NumberSetting(EncryptedString.of("Chestplate Slot"), 1.0D, 9.0D, 2.0D, 1.0D)).setDescription(EncryptedString.of("Slot 1-9 for chestplate"));
   private final NumberSetting maceSlot = (NumberSetting)(new NumberSetting(EncryptedString.of("Mace Slot"), 1.0D, 9.0D, 1.0D, 1.0D)).setDescription(EncryptedString.of("Slot 1-9 for mace"));
   private DiveBomber.EquipState equipState;
   private int equipTimer;
   private boolean isElytraEquipped;
   private long groundTime;

   public DiveBomber() {
      super(EncryptedString.of("DiveBomber"), EncryptedString.of("Auto chestplate swap to smash enemies like a stuka bomber"), -1, Category.mace);
      this.equipState = DiveBomber.EquipState.IDLE;
      this.equipTimer = 0;
      this.isElytraEquipped = false;
      this.groundTime = 0L;
      this.addSettings(new Setting[]{this.switchDelay, this.chestplateSlot, this.maceSlot});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.eventManager.add(AttackListener.class, this);
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      this.eventManager.remove(AttackListener.class, this);
      this.resetState();
      super.onDisable();
   }

   public void onTick() {
      if (this.mc.field_1755 == null) {
         if (this.mc.field_1724 != null) {
            class_1799 chestItem = this.mc.field_1724.method_6118(class_1304.field_6174);
            this.isElytraEquipped = chestItem.method_7909() == class_1802.field_8833;
            if (this.equipState != DiveBomber.EquipState.IDLE && ++this.equipTimer >= this.switchDelay.getValueInt()) {
               this.equipTimer = 0;
               this.processEquipState();
            }

            if (this.mc.field_1724.method_24828() && !this.mc.field_1724.method_6128() && this.isElytraEquipped) {
               if (this.groundTime == 0L) {
                  this.groundTime = System.currentTimeMillis();
               } else if (System.currentTimeMillis() - this.groundTime > 1000L) {
                  this.startEquipProcess();
                  this.groundTime = 0L;
               }
            } else {
               this.groundTime = 0L;
            }

         }
      }
   }

   public void onAttack(AttackListener.AttackEvent event) {
      if (this.mc.field_1755 == null) {
         if (this.mc.field_1724 != null && this.isElytraEquipped) {
            this.startEquipProcess();
         }
      }
   }

   private void startEquipProcess() {
      if (this.equipState == DiveBomber.EquipState.IDLE) {
         this.equipState = DiveBomber.EquipState.SWITCHING_TO_CHESTPLATE;
         this.processEquipState();
      }

   }

   private void processEquipState() {
      if (this.mc.field_1755 != null) {
         this.resetState();
      } else {
         class_1657 player = this.mc.field_1724;
         if (player == null) {
            this.resetState();
         } else {
            switch(this.equipState.ordinal()) {
            case 1:
               player.method_31548().field_7545 = this.chestplateSlot.getValueInt() - 1;
               this.equipState = DiveBomber.EquipState.EQUIPPING;
               break;
            case 2:
               this.mc.field_1761.method_2919(player, class_1268.field_5808);
               this.equipState = DiveBomber.EquipState.SWITCHING_BACK;
               break;
            case 3:
               player.method_31548().field_7545 = this.maceSlot.getValueInt() - 1;
               this.resetState();
            }

         }
      }
   }

   private void resetState() {
      this.equipState = DiveBomber.EquipState.IDLE;
      this.equipTimer = 0;
   }

   private static enum EquipState {
      IDLE,
      SWITCHING_TO_CHESTPLATE,
      EQUIPPING,
      SWITCHING_BACK;

      // $FF: synthetic method
      private static DiveBomber.EquipState[] $values() {
         return new DiveBomber.EquipState[]{IDLE, SWITCHING_TO_CHESTPLATE, EQUIPPING, SWITCHING_BACK};
      }
   }
}
