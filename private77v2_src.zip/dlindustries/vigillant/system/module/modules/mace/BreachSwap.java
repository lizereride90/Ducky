package dlindustries.vigillant.system.module.modules.mace;

import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_9362;

public class BreachSwap extends Module implements AttackListener {
   private final BooleanSetting onlyWhenSword = new BooleanSetting(EncryptedString.of("Only With Sword"), true);
   private final BooleanSetting requireAirborne = new BooleanSetting(EncryptedString.of("Require Airborne"), true);
   private int previousSlot = -1;

   public BreachSwap() {
      super(EncryptedString.of("Breach Swap"), EncryptedString.of("allows breach swapping with sword make sure you are using a Breach mace for this."), -1, Category.mace);
      this.addSettings(new Setting[]{this.onlyWhenSword, this.requireAirborne});
   }

   public void onEnable() {
      this.previousSlot = -1;
   }

   public void onDisable() {
      this.restoreOriginalSlot();
   }

   public void onAttack(AttackListener.AttackEvent event) {
      if (!this.onlyWhenSword.getValue() || this.mc.field_1724.method_6047().method_7909() instanceof class_1829) {
         if (!this.requireAirborne.getValue() || !this.mc.field_1724.method_24828()) {
            int maceSlot = this.findHotbarMace();
            if (maceSlot != -1) {
               this.previousSlot = this.mc.field_1724.method_31548().field_7545;
               this.mc.field_1724.method_31548().field_7545 = maceSlot;
               this.restoreOriginalSlot();
            }
         }
      }
   }

   private int findHotbarMace() {
      for(int slot = 0; slot < 9; ++slot) {
         class_1799 stack = this.mc.field_1724.method_31548().method_5438(slot);
         if (stack.method_7909() instanceof class_9362) {
            return slot;
         }
      }

      return -1;
   }

   private void restoreOriginalSlot() {
      if (this.mc.field_1724 != null && this.previousSlot >= 0 && this.previousSlot < 9) {
         this.mc.field_1724.method_31548().field_7545 = this.previousSlot;
      }

   }
}
