package dlindustries.vigillant.system.module.modules.mace;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import net.minecraft.class_1268;
import net.minecraft.class_310;

public class FireworkMacro extends Module implements TickListener {
   private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0.0D, 20.0D, 1.0D, 1.0D);
   private final NumberSetting fireworkSlot = (NumberSetting)(new NumberSetting(EncryptedString.of("Firework Slot"), 1.0D, 9.0D, 4.0D, 1.0D)).setDescription(EncryptedString.of("Slot 1-9 for fireworks"));
   private final NumberSetting restoreSlot = (NumberSetting)(new NumberSetting(EncryptedString.of("Restore Slot"), 1.0D, 9.0D, 1.0D, 1.0D)).setDescription(EncryptedString.of("Slot 1-9 to restore"));
   private boolean active;
   private boolean hasSwitched;
   private boolean hasUsed;
   private boolean hasSwitchedBack;
   private int switchClock;
   private int useClock;
   private int switchBackClock;
   private boolean jumpKeyPressed;
   private boolean wasFlying;

   public FireworkMacro() {
      super(EncryptedString.of("Firework Macro"), EncryptedString.of("Press jump while flying to use fireworks"), -1, Category.mace);
      this.addSettings(new Setting[]{this.switchDelay, this.fireworkSlot, this.restoreSlot});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.reset();
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      this.reset();
      super.onDisable();
   }

   public void onTick() {
      if (this.mc.field_1755 == null) {
         this.handleJumpDetection();
         this.handleFlightMonitoring();
         this.handleFireworkSequence();
      }
   }

   private void handleJumpDetection() {
      boolean jumping = class_310.method_1551().field_1690.field_1903.method_1434();
      if (jumping && !this.jumpKeyPressed) {
         if (this.mc.field_1724 != null && this.mc.field_1724.method_6128() && !this.active) {
            this.active = true;
         }

         this.jumpKeyPressed = true;
      } else if (!jumping) {
         this.jumpKeyPressed = false;
      }

   }

   private void handleFlightMonitoring() {
      if (this.mc.field_1724 != null) {
         boolean isFlying = this.mc.field_1724.method_6128();
         if (this.active && !isFlying) {
            this.reset();
         }

         this.wasFlying = isFlying;
      }
   }

   private void handleFireworkSequence() {
      if (this.active && this.mc.field_1724 != null) {
         if (!this.hasSwitched) {
            if (this.switchClock < this.switchDelay.getValueInt()) {
               ++this.switchClock;
               return;
            }

            this.mc.field_1724.method_31548().field_7545 = this.fireworkSlot.getValueInt() - 1;
            this.hasSwitched = true;
            this.switchClock = 0;
         } else if (!this.hasUsed) {
            if (this.useClock < 1) {
               ++this.useClock;
               return;
            }

            this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
            this.hasUsed = true;
            this.useClock = 0;
         } else if (!this.hasSwitchedBack) {
            if (this.switchBackClock < this.switchDelay.getValueInt()) {
               ++this.switchBackClock;
               return;
            }

            this.mc.field_1724.method_31548().field_7545 = this.restoreSlot.getValueInt() - 1;
            this.hasSwitchedBack = true;
            this.reset();
         }

      }
   }

   private void reset() {
      this.active = false;
      this.hasSwitched = false;
      this.hasUsed = false;
      this.hasSwitchedBack = false;
      this.switchClock = 0;
      this.useClock = 0;
      this.switchBackClock = 0;
   }
}
