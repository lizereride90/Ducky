package dlindustries.vigillant.system.module.modules.mace;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.KeybindSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.InventoryUtils;
import dlindustries.vigillant.system.utils.KeyUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;

public final class KeyWindCharge extends Module implements TickListener {
   private final KeybindSetting activateKey = new KeybindSetting(EncryptedString.of("Activate Key"), -1, false);
   private final NumberSetting delay = new NumberSetting(EncryptedString.of("Delay"), 1.0D, 20.0D, 1.0D, 1.0D);
   private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
   private final NumberSetting switchslot = (NumberSetting)(new NumberSetting(EncryptedString.of("Switch Slot"), 1.0D, 9.0D, 1.0D, 1.0D)).setDescription(EncryptedString.of("the slot that it goes back to after using wind charge"));
   private final NumberSetting switchDelay = (NumberSetting)(new NumberSetting(EncryptedString.of("Switch Delay"), 1.0D, 20.0D, 1.0D, 1.0D)).setDescription(EncryptedString.of("Delay after using wind charge before switching back"));
   private boolean active;
   private boolean hasActivated;
   private int clock;
   private int previousSlot;
   private int switchClock;

   public KeyWindCharge() {
      super(EncryptedString.of("Key Wind Charge"), EncryptedString.of("Optimizes your wind charge usage speed"), -1, Category.mace);
      this.addSettings(new Setting[]{this.activateKey, this.delay, this.switchBack, this.switchslot, this.switchDelay});
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.reset();
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      if (this.mc.field_1755 == null) {
         if (KeyUtils.isKeyPressed(this.activateKey.getKey())) {
            this.active = true;
         }

         if (this.active) {
            if (this.previousSlot == -1) {
               this.previousSlot = this.mc.field_1724.method_31548().field_7545;
            }

            InventoryUtils.selectItemFromHotbar(class_1802.field_49098);
            if (this.clock < this.delay.getValueInt()) {
               ++this.clock;
               return;
            }

            if (!this.hasActivated) {
               class_1269 result = this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
               if (result.method_23665() && result.method_23666()) {
                  this.mc.field_1724.method_6104(class_1268.field_5808);
               }

               this.hasActivated = true;
            }

            if (this.switchBack.getValue()) {
               this.switchBack();
            } else {
               this.reset();
            }
         }

      }
   }

   private void switchBack() {
      if (this.switchClock < this.switchDelay.getValueInt()) {
         ++this.switchClock;
      } else {
         InventoryUtils.setInvSlot(this.switchslot.getValueInt() - 1);
         this.reset();
      }
   }

   private void reset() {
      this.previousSlot = -1;
      this.clock = 0;
      this.switchClock = 0;
      this.active = false;
      this.hasActivated = false;
   }
}
