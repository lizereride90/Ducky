package dlindustries.vigillant.system.module.modules.pot;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.mixin.HandledScreenMixin;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.MinMaxSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.InventoryUtils;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_437;
import net.minecraft.class_490;

public final class AutoPotRefill extends Module implements TickListener {
   private final ModeSetting<AutoPotRefill.Mode> mode;
   private final NumberSetting delay;
   private final MinMaxSetting slots;
   private int clock;

   public AutoPotRefill() {
      super(EncryptedString.of("Auto Pot Refill"), EncryptedString.of("Refills your hotbar with potions"), -1, Category.pot);
      this.mode = new ModeSetting(EncryptedString.of("Mode"), AutoPotRefill.Mode.Auto, AutoPotRefill.Mode.class);
      this.delay = new NumberSetting(EncryptedString.of("Delay"), 0.0D, 10.0D, 0.0D, 1.0D);
      this.slots = (MinMaxSetting)(new MinMaxSetting(EncryptedString.of("Pot Slots"), 1.0D, 9.0D, 1.0D, 4.0D, 9.0D)).setDescription(EncryptedString.of("Range of hotbar slots to be refilled with pots (1-9)"));
      this.addSettings(new Setting[]{this.mode, this.delay, this.slots});
      this.clock = 0;
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.clock = 0;
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      class_437 var2 = this.mc.field_1755;
      if (var2 instanceof class_490) {
         class_490 inventoryScreen = (class_490)var2;
         int minSlot = this.slots.getMinInt() - 1;
         int maxSlot = this.slots.getMaxInt() - 1;
         class_1661 inventory;
         int emptySlot;
         int i;
         if (this.mode.isMode(AutoPotRefill.Mode.Hover)) {
            class_1735 focusedSlot = ((HandledScreenMixin)inventoryScreen).getFocusedSlot();
            if (focusedSlot == null) {
               return;
            }

            inventory = this.mc.field_1724.method_31548();
            emptySlot = -1;

            for(i = minSlot; i <= maxSlot; ++i) {
               if (inventory.method_5438(i).method_7960()) {
                  emptySlot = i;
                  break;
               }
            }

            if (emptySlot == -1) {
               return;
            }

            if (InventoryUtils.isThatSplash((class_1291)class_1294.field_5915.comp_349(), 1, 1, focusedSlot.method_7677())) {
               if (this.clock < this.delay.getValueInt()) {
                  ++this.clock;
                  return;
               }

               this.mc.field_1761.method_2906(((class_1723)inventoryScreen.method_17577()).field_7763, focusedSlot.method_34266(), emptySlot, class_1713.field_7791, this.mc.field_1724);
               this.clock = 0;
            }
         }

         if (this.mode.isMode(AutoPotRefill.Mode.Auto)) {
            int potSlot = InventoryUtils.findPot((class_1291)class_1294.field_5915.comp_349(), 1, 1);
            if (potSlot == -1) {
               return;
            }

            inventory = this.mc.field_1724.method_31548();
            emptySlot = -1;

            for(i = minSlot; i <= maxSlot; ++i) {
               if (inventory.method_5438(i).method_7960()) {
                  emptySlot = i;
                  break;
               }
            }

            if (emptySlot == -1) {
               return;
            }

            if (this.clock < this.delay.getValueInt()) {
               ++this.clock;
               return;
            }

            this.mc.field_1761.method_2906(((class_1723)inventoryScreen.method_17577()).field_7763, potSlot, emptySlot, class_1713.field_7791, this.mc.field_1724);
            this.clock = 0;
         }

      }
   }

   public static enum Mode {
      Auto,
      Hover;

      // $FF: synthetic method
      private static AutoPotRefill.Mode[] $values() {
         return new AutoPotRefill.Mode[]{Auto, Hover};
      }
   }
}
