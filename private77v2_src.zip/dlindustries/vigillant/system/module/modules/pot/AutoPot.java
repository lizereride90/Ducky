package dlindustries.vigillant.system.module.modules.pot;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.KeybindSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.InventoryUtils;
import dlindustries.vigillant.system.utils.KeyUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1291;
import net.minecraft.class_1294;

public final class AutoPot extends Module implements TickListener {
   private final KeybindSetting activateKey = (KeybindSetting)(new KeybindSetting(EncryptedString.of("Activate Key"), -1, false)).setDescription(EncryptedString.of("Key that activates auto-potting when held"));
   private final NumberSetting minHealth = new NumberSetting(EncryptedString.of("Min Health"), 1.0D, 20.0D, 10.0D, 1.0D);
   private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0.0D, 10.0D, 0.0D, 1.0D);
   private final NumberSetting throwDelay = new NumberSetting(EncryptedString.of("Throw Delay"), 0.0D, 10.0D, 0.0D, 1.0D);
   private final BooleanSetting goToPrevSlot = new BooleanSetting(EncryptedString.of("Switch Back"), true);
   private final BooleanSetting lookDown = new BooleanSetting(EncryptedString.of("Look Down"), true);
   private int switchClock;
   private int throwClock;
   private int prevSlot;
   private float prevPitch;
   private boolean potting;

   public AutoPot() {
      super(EncryptedString.of("Auto Pot"), EncryptedString.of("Automatically throws health potions when low on health while key is held"), -1, Category.pot);
      this.addSettings(new Setting[]{this.activateKey, this.minHealth, this.switchDelay, this.throwDelay, this.goToPrevSlot, this.lookDown});
      this.resetState();
   }

   private void resetState() {
      this.switchClock = 0;
      this.throwClock = 0;
      this.prevSlot = -1;
      this.prevPitch = -1.0F;
      this.potting = false;
   }

   public void onEnable() {
      this.eventManager.add(TickListener.class, this);
      this.resetState();
      super.onEnable();
   }

   public void onDisable() {
      this.eventManager.remove(TickListener.class, this);
      super.onDisable();
   }

   public void onTick() {
      if (this.activateKey.getKey() != -1 && !KeyUtils.isKeyPressed(this.activateKey.getKey())) {
         this.potting = false;
      } else {
         this.potting = true;
         if (this.mc.field_1755 == null) {
            if (!(this.mc.field_1724.method_6032() <= this.minHealth.getValueFloat()) && !this.potting) {
               if (this.prevSlot != -1 || this.prevPitch >= 0.0F) {
                  InventoryUtils.setInvSlot(this.prevSlot);
                  this.prevSlot = -1;
                  this.mc.field_1724.method_36457(this.prevPitch);
                  this.prevPitch = -1.0F;
               }
            } else {
               if (this.potting && this.mc.field_1724.method_6032() >= this.mc.field_1724.method_6063()) {
                  this.potting = false;
                  return;
               }

               if (!InventoryUtils.isThatSplash((class_1291)class_1294.field_5915.comp_349(), 1, 1, this.mc.field_1724.method_6047())) {
                  if (this.switchClock < this.switchDelay.getValueInt()) {
                     ++this.switchClock;
                     return;
                  }

                  if (this.goToPrevSlot.getValue() && this.prevSlot == -1) {
                     this.prevSlot = this.mc.field_1724.method_31548().field_7545;
                  }

                  if (this.lookDown.getValue() && this.prevPitch < 0.0F) {
                     this.prevPitch = this.mc.field_1724.method_36455();
                  }

                  int potSlot = InventoryUtils.findSplash((class_1291)class_1294.field_5915.comp_349(), 1, 1);
                  if (potSlot != -1) {
                     InventoryUtils.setInvSlot(potSlot);
                     this.switchClock = 0;
                  }
               }

               if (InventoryUtils.isThatSplash((class_1291)class_1294.field_5915.comp_349(), 1, 1, this.mc.field_1724.method_6047())) {
                  if (this.throwClock < this.throwDelay.getValueInt()) {
                     ++this.throwClock;
                     return;
                  }

                  if (this.lookDown.getValue()) {
                     this.mc.field_1724.method_36457(90.0F);
                  }

                  class_1269 result = this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
                  if (result.method_23666()) {
                     this.mc.field_1724.method_6104(class_1268.field_5808);
                  }

                  this.throwClock = 0;
               }
            }

         }
      }
   }
}
