package dlindustries.vigillant.system.module.setting;

import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public final class KeybindSetting extends Setting<KeybindSetting> {
   private int keyCode;
   private boolean listening;
   private final boolean moduleKey;
   private final int originalKey;

   public KeybindSetting(CharSequence name, int key, boolean moduleKey) {
      super(name);
      this.keyCode = key;
      this.originalKey = key;
      this.moduleKey = moduleKey;
   }

   public boolean isModuleKey() {
      return this.moduleKey;
   }

   public boolean isListening() {
      return this.listening;
   }

   public int getOriginalKey() {
      return this.originalKey;
   }

   public void setListening(boolean listening) {
      this.listening = listening;
   }

   public int getKey() {
      return this.keyCode;
   }

   public void setKey(int key) {
      if (!this.isMediaKey(key)) {
         this.keyCode = key;
      }

   }

   public void toggleListening() {
      this.listening = !this.listening;
   }

   public boolean isPressed() {
      if (!this.isMediaKey(this.keyCode) && this.keyCode != -1) {
         return GLFW.glfwGetKey(class_310.method_1551().method_22683().method_4490(), this.keyCode) == 1;
      } else {
         return false;
      }
   }

   private boolean isMediaKey(int key) {
      return key >= 179 && key <= 183;
   }

   public boolean shouldIgnoreKey(int key) {
      return this.isMediaKey(key) || key == -1;
   }
}
