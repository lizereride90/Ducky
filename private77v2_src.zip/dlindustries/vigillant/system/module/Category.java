package dlindustries.vigillant.system.module;

import dlindustries.vigillant.system.utils.EncryptedString;

public enum Category {
   sword(EncryptedString.of("Sword")),
   CRYSTAL(EncryptedString.of("Crystal")),
   pot(EncryptedString.of("Potions")),
   mace(EncryptedString.of("Mace")),
   optimizer(EncryptedString.of("Optimizer")),
   RENDER(EncryptedString.of("Render")),
   CLIENT(EncryptedString.of("Client"));

   public final CharSequence name;

   private Category(CharSequence name) {
      this.name = name;
   }

   // $FF: synthetic method
   private static Category[] $values() {
      return new Category[]{sword, CRYSTAL, pot, mace, optimizer, RENDER, CLIENT};
   }
}
