package dlindustries.vigillant.system.module;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.event.events.ButtonListener;
import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import dlindustries.vigillant.system.module.modules.client.ResetConfig;
import dlindustries.vigillant.system.module.modules.client.SelfDestruct;
import dlindustries.vigillant.system.module.modules.crystal.*;
import dlindustries.vigillant.system.module.modules.mace.*;
import dlindustries.vigillant.system.module.modules.optimizer.*;
import dlindustries.vigillant.system.module.modules.pot.*;
import dlindustries.vigillant.system.module.modules.render.*;
import dlindustries.vigillant.system.module.modules.sword.*;
import dlindustries.vigillant.system.module.setting.KeybindSetting;
import dlindustries.vigillant.system.utils.EncryptedString;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

public final class ModuleManager implements ButtonListener {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        this.addModules();
        this.addKeybinds();
    }

    public void addModules() {
        // SWORD
        this.add(new AimAssist());
        this.add(new TriggerBot());
        this.add(new AutoWTap());
        this.add(new ShieldDisabler());
        this.add(new AutoJumpReset());
        // POT
        this.add(new AutoPot());
        this.add(new AutoPotRefill());
        // CRYSTAL
        this.add(new DoubleAnchor());
        this.add(new HoverTotem());
        this.add(new AnchorMacro());
        this.add(new AutoCrystal());
        this.add(new AutoDoubleHand());
        this.add(new dtapsetup());
        this.add(new AutoInventoryTotem());
        this.add(new TotemOffhand());
        this.add(new KeyPearl());
        this.add(new DhandMod());
        // MACE
        this.add(new BreachSwap());
        this.add(new DiveBomber());
        this.add(new FireworkMacro());
        this.add(new KeyWindCharge());
        // OPTIMIZER
        this.add(new Prevent());
        this.add(new AutoXP());
        this.add(new NoJumpDelay());
        this.add(new CrystalOptimizer());
        this.add(new NoMissDelay());
        this.add(new NoBreakDelay());
        this.add(new PackSpoof());
        this.add(new Sprint());
        this.add(new CameraOptimizer());
        this.add(new PlacementOptimizer());
        this.add(new HitOptimizer());
        // RENDER
        this.add(new HUD());
        this.add(new NoBounce());
        this.add(new TargetHud());
        // CLIENT
        this.add(new ClickGUI());
        this.add(new SelfDestruct());
        this.add(new ResetConfig());   // ← NEW
    }

    public List<Module> getEnabledModules() {
        return this.modules.stream().filter(Module::isEnabled).toList();
    }

    public List<Module> getModules() {
        return this.modules;
    }

    public void addKeybinds() {
        system.INSTANCE.getEventManager().add(ButtonListener.class, this);
        for (Module module : this.modules) {
            module.addSetting(
                (new KeybindSetting(EncryptedString.of("Keybind"), module.getKey(), true))
                    .setDescription(EncryptedString.of("Key to enable the module"))
            );
        }
    }

    public List<Module> getModulesInCategory(Category category) {
        return this.modules.stream()
            .filter(m -> m.getCategory() == category)
            .toList();
    }

    public <T extends Module> T getModule(Class<T> moduleClass) {
        return (T) this.modules.stream()
            .filter(moduleClass::isInstance)
            .findFirst().orElse(null);
    }

    public void add(Module module) {
        this.modules.add(module);
    }

    public void onButtonPress(ButtonListener.ButtonEvent event) {
        if ((event.button < 179 || event.button > 183)
                && event.button != -1
                && !SelfDestruct.destruct) {
            this.modules.forEach(module -> {
                if (module.getKey() == event.button && event.action == 1) {
                    module.toggle();
                }
            });
        }
    }
}
