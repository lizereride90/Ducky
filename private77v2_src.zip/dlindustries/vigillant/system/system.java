package dlindustries.vigillant.system;

import dlindustries.vigillant.system.event.EventManager;
import dlindustries.vigillant.system.gui.ClickGui;
import dlindustries.vigillant.system.managers.FriendManager;
import dlindustries.vigillant.system.managers.ProfileManager;
import dlindustries.vigillant.system.module.ModuleManager;
import dlindustries.vigillant.system.utils.rotation.RotatorManager;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import net.minecraft.class_310;
import net.minecraft.class_437;

public final class system {
   public RotatorManager rotatorManager;
   public ProfileManager profileManager;
   public ModuleManager moduleManager;
   public EventManager eventManager;
   public FriendManager friendManager;
   public static class_310 mc;
   public String version = " b1.5";
   public static boolean BETA;
   public static system INSTANCE;
   public boolean guiInitialized;
   public ClickGui clickGui;
   public class_437 previousScreen = null;
   public long lastModified;
   public File systemJar;

   public system() throws InterruptedException, IOException {
      INSTANCE = this;
      this.eventManager = new EventManager();
      this.moduleManager = new ModuleManager();
      this.clickGui = new ClickGui();
      this.rotatorManager = new RotatorManager();
      this.profileManager = new ProfileManager();
      this.friendManager = new FriendManager();
      this.getProfileManager().loadProfile();
      this.setLastModified();
      this.guiInitialized = false;
      mc = class_310.method_1551();
   }

   public ProfileManager getProfileManager() {
      return this.profileManager;
   }

   public ModuleManager getModuleManager() {
      return this.moduleManager;
   }

   public FriendManager getFriendManager() {
      return this.friendManager;
   }

   public EventManager getEventManager() {
      return this.eventManager;
   }

   public ClickGui getClickGui() {
      return this.clickGui;
   }

   public void resetModifiedDate() {
      this.systemJar.setLastModified(this.lastModified);
   }

   public String getVersion() {
      return this.version;
   }

   public void setLastModified() {
      try {
         this.systemJar = new File(system.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         this.lastModified = this.systemJar.lastModified();
      } catch (URISyntaxException var2) {
      }

   }
}
