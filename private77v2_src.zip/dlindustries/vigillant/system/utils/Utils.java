package dlindustries.vigillant.system.utils;

import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import dlindustries.vigillant.system.module.modules.client.SelfDestruct;
import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;

public final class Utils {
   private static final Color[] SOLO_LEVELING_COLORS = new Color[]{new Color(120, 20, 230), new Color(160, 60, 255), new Color(130, 50, 255), new Color(100, 140, 255), new Color(72, 126, 255), new Color(64, 170, 255), new Color(120, 80, 250), new Color(160, 100, 255), new Color(190, 120, 255), new Color(120, 20, 230)};

   public static Color getMainColor(int alpha, int unusedIncrement) {
      if (ClickGUI.breathing.getValue()) {
         long currentTime = System.currentTimeMillis();
         int cycleDuration = 8000;
         float progress = (float)(currentTime % (long)cycleDuration) / (float)cycleDuration;
         int colorCount = SOLO_LEVELING_COLORS.length;
         float scaledProgress = progress * (float)colorCount;
         int index = (int)scaledProgress;
         float interpolation = scaledProgress - (float)index;
         Color start = SOLO_LEVELING_COLORS[index % colorCount];
         Color end = SOLO_LEVELING_COLORS[(index + 1) % colorCount];
         return new Color(interpolateColor(start.getRed(), end.getRed(), interpolation), interpolateColor(start.getGreen(), end.getGreen(), interpolation), interpolateColor(start.getBlue(), end.getBlue(), interpolation), alpha);
      } else {
         return new Color((int)ClickGUI.red.getValue(), (int)ClickGUI.green.getValue(), (int)ClickGUI.blue.getValue(), alpha);
      }
   }

   private static int interpolateColor(int start, int end, float progress) {
      return (int)((float)start + (float)(end - start) * progress);
   }

   public static File getCurrentJarPath() throws URISyntaxException {
      return new File(SelfDestruct.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
   }

   public static void replaceModFile(String downloadURL, File savePath) throws IOException {
      URL url = new URL(downloadURL);
      HttpURLConnection httpConnection = (HttpURLConnection)url.openConnection();
      httpConnection.setRequestMethod("GET");
      InputStream in = httpConnection.getInputStream();

      try {
         FileOutputStream fos = new FileOutputStream(savePath);

         try {
            byte[] buffer = new byte[1024];

            int bytesRead;
            while((bytesRead = in.read(buffer)) != -1) {
               fos.write(buffer, 0, bytesRead);
            }
         } catch (Throwable var10) {
            try {
               fos.close();
            } catch (Throwable var9) {
               var10.addSuppressed(var9);
            }

            throw var10;
         }

         fos.close();
      } catch (Throwable var11) {
         if (in != null) {
            try {
               in.close();
            } catch (Throwable var8) {
               var11.addSuppressed(var8);
            }
         }

         throw var11;
      }

      if (in != null) {
         in.close();
      }

      httpConnection.disconnect();
   }
}
