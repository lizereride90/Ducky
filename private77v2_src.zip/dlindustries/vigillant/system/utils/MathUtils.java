package dlindustries.vigillant.system.utils;

import java.util.Random;

public final class MathUtils {
   public static Random random = new Random(System.currentTimeMillis());

   public static double roundToDecimal(double n, double point) {
      return point * (double)Math.round(n / point);
   }

   public static int randomInt(int start, int bound) {
      return random.nextInt(start, bound);
   }

   public static double smoothStepLerp(double delta, double start, double end) {
      delta = Math.max(0.0D, Math.min(1.0D, delta));
      double t = delta * delta * (3.0D - 2.0D * delta);
      double value = start + (end - start) * t;
      return value;
   }

   public static double goodLerp(float delta, double start, double end) {
      int step = (int)Math.ceil(Math.abs(end - start) * (double)delta);
      return start < end ? Math.min(start + (double)step, end) : Math.max(start - (double)step, end);
   }
}
