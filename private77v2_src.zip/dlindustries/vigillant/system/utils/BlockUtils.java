package dlindustries.vigillant.system.utils;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.utils.rotation.Rotation;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_4969;

public final class BlockUtils {
   public static boolean isBlock(class_2338 pos, class_2248 block) {
      return system.mc.field_1687.method_8320(pos).method_26204() == block;
   }

   public static void rotateToBlock(class_2338 pos) {
      assert system.mc.field_1724 != null;

      Rotation rotation = RotationUtils.getDirection(system.mc.field_1724, pos.method_46558());
      system.mc.field_1724.method_36457((float)rotation.pitch());
      system.mc.field_1724.method_36456((float)rotation.yaw());
   }

   public static boolean isAnchorCharged(class_2338 pos) {
      if (isBlock(pos, class_2246.field_23152)) {
         return (Integer)system.mc.field_1687.method_8320(pos).method_11654(class_4969.field_23153) != 0;
      } else {
         return false;
      }
   }

   public static boolean isAnchorNotCharged(class_2338 pos) {
      if (isBlock(pos, class_2246.field_23152)) {
         return (Integer)system.mc.field_1687.method_8320(pos).method_11654(class_4969.field_23153) == 0;
      } else {
         return false;
      }
   }

   public static boolean canPlaceBlockClient(class_2338 block) {
      class_2338 up = block.method_10084();
      if (!system.mc.field_1687.method_22347(up)) {
         return false;
      } else {
         double x = (double)up.method_10263();
         double y = (double)up.method_10264();
         double z = (double)up.method_10260();
         List<class_1297> list = system.mc.field_1687.method_8335((class_1297)null, new class_238(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D));
         list.removeIf((entity) -> {
            return entity instanceof class_1542;
         });
         return list.isEmpty();
      }
   }

   public static Stream<class_2338> getAllInBoxStream(class_2338 from, class_2338 to) {
      class_2338 min = new class_2338(Math.min(from.method_10263(), to.method_10263()), Math.min(from.method_10264(), to.method_10264()), Math.min(from.method_10260(), to.method_10260()));
      class_2338 max = new class_2338(Math.max(from.method_10263(), to.method_10263()), Math.max(from.method_10264(), to.method_10264()), Math.max(from.method_10260(), to.method_10260()));
      Stream<class_2338> stream = Stream.iterate(min, (pos) -> {
         int x = pos.method_10263();
         int y = pos.method_10264();
         int z = pos.method_10260();
         ++x;
         if (x > max.method_10263()) {
            x = min.method_10263();
            ++y;
         }

         if (y > max.method_10264()) {
            y = min.method_10264();
            ++z;
         }

         if (z > max.method_10260()) {
            throw new IllegalStateException("Stream limit didn't work.");
         } else {
            return new class_2338(x, y, z);
         }
      });
      int limit = (max.method_10263() - min.method_10263() + 1) * (max.method_10264() - min.method_10264() + 1) * (max.method_10260() - min.method_10260() + 1);
      return stream.limit((long)limit);
   }

   public static boolean canPlaceGlowstone(class_2338 pos) {
      if (!system.mc.field_1687.method_8320(pos).method_45474()) {
         return false;
      } else {
         class_2350[] var1 = class_2350.values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            class_2350 direction = var1[var3];
            class_2338 neighbor = pos.method_10093(direction);
            if (system.mc.field_1687.method_8320(neighbor).method_51367()) {
               return true;
            }
         }

         return false;
      }
   }
}
