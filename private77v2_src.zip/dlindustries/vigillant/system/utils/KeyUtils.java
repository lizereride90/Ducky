package dlindustries.vigillant.system.utils;

import dlindustries.vigillant.system.system;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.glfw.GLFW;

public final class KeyUtils {
   public static CharSequence getKey(int key) {
      switch(key) {
      case -1:
         return EncryptedString.of("Unknown");
      case 0:
         return EncryptedString.of("LMB");
      case 1:
         return EncryptedString.of("RMB");
      case 2:
         return EncryptedString.of("MMB");
      case 3:
         return EncryptedString.of("Mouse 4");
      case 4:
         return EncryptedString.of("Mouse 5");
      case 5:
         return EncryptedString.of("Mouse 6");
      case 6:
         return EncryptedString.of("Mouse 7");
      case 7:
         return EncryptedString.of("Mouse 8");
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 26:
      case 27:
      case 28:
      case 29:
      case 30:
      case 31:
      case 33:
      case 34:
      case 35:
      case 36:
      case 37:
      case 38:
      case 40:
      case 41:
      case 42:
      case 43:
      case 45:
      case 46:
      case 47:
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
      case 58:
      case 60:
      case 62:
      case 63:
      case 64:
      case 65:
      case 66:
      case 67:
      case 68:
      case 69:
      case 70:
      case 71:
      case 72:
      case 73:
      case 74:
      case 75:
      case 76:
      case 77:
      case 78:
      case 79:
      case 80:
      case 81:
      case 82:
      case 83:
      case 84:
      case 85:
      case 86:
      case 87:
      case 88:
      case 89:
      case 90:
      case 94:
      case 95:
      case 97:
      case 98:
      case 99:
      case 100:
      case 101:
      case 102:
      case 103:
      case 104:
      case 105:
      case 106:
      case 107:
      case 108:
      case 109:
      case 110:
      case 111:
      case 112:
      case 113:
      case 114:
      case 115:
      case 116:
      case 117:
      case 118:
      case 119:
      case 120:
      case 121:
      case 122:
      case 123:
      case 124:
      case 125:
      case 126:
      case 127:
      case 128:
      case 129:
      case 130:
      case 131:
      case 132:
      case 133:
      case 134:
      case 135:
      case 136:
      case 137:
      case 138:
      case 139:
      case 140:
      case 141:
      case 142:
      case 143:
      case 144:
      case 145:
      case 146:
      case 147:
      case 148:
      case 149:
      case 150:
      case 151:
      case 152:
      case 153:
      case 154:
      case 155:
      case 156:
      case 157:
      case 158:
      case 159:
      case 160:
      case 163:
      case 164:
      case 165:
      case 166:
      case 167:
      case 168:
      case 169:
      case 170:
      case 171:
      case 172:
      case 173:
      case 174:
      case 175:
      case 176:
      case 177:
      case 178:
      case 179:
      case 180:
      case 181:
      case 182:
      case 183:
      case 184:
      case 185:
      case 186:
      case 187:
      case 188:
      case 189:
      case 190:
      case 191:
      case 192:
      case 193:
      case 194:
      case 195:
      case 196:
      case 197:
      case 198:
      case 199:
      case 200:
      case 201:
      case 202:
      case 203:
      case 204:
      case 205:
      case 206:
      case 207:
      case 208:
      case 209:
      case 210:
      case 211:
      case 212:
      case 213:
      case 214:
      case 215:
      case 216:
      case 217:
      case 218:
      case 219:
      case 220:
      case 221:
      case 222:
      case 223:
      case 224:
      case 225:
      case 226:
      case 227:
      case 228:
      case 229:
      case 230:
      case 231:
      case 232:
      case 233:
      case 234:
      case 235:
      case 236:
      case 237:
      case 238:
      case 239:
      case 240:
      case 241:
      case 242:
      case 243:
      case 244:
      case 245:
      case 246:
      case 247:
      case 248:
      case 249:
      case 250:
      case 251:
      case 252:
      case 253:
      case 254:
      case 255:
      case 270:
      case 271:
      case 272:
      case 273:
      case 274:
      case 275:
      case 276:
      case 277:
      case 278:
      case 279:
      case 285:
      case 286:
      case 287:
      case 288:
      case 289:
      case 315:
      case 316:
      case 317:
      case 318:
      case 319:
      case 320:
      case 321:
      case 322:
      case 323:
      case 324:
      case 325:
      case 326:
      case 327:
      case 328:
      case 329:
      case 330:
      case 331:
      case 332:
      case 333:
      case 334:
      case 336:
      case 337:
      case 338:
      case 339:
      default:
         String keyName = GLFW.glfwGetKeyName(key, 0);
         if (keyName == null) {
            return EncryptedString.of("None");
         }

         return StringUtils.capitalize(keyName);
      case 32:
         return EncryptedString.of("Space");
      case 39:
         return EncryptedString.of("Apostrophe");
      case 44:
         return EncryptedString.of("Comma");
      case 59:
         return EncryptedString.of("Semicolon");
      case 61:
         return EncryptedString.of("Equals");
      case 91:
         return EncryptedString.of("Left Bracket");
      case 92:
         return EncryptedString.of("Backslash");
      case 93:
         return EncryptedString.of("Right Bracket");
      case 96:
         return EncryptedString.of("Grave Accent");
      case 161:
         return EncryptedString.of("World 1");
      case 162:
         return EncryptedString.of("World 2");
      case 256:
         return EncryptedString.of("Esc");
      case 257:
         return EncryptedString.of("Enter");
      case 258:
         return EncryptedString.of("Tab");
      case 259:
         return EncryptedString.of("Backspace");
      case 260:
         return EncryptedString.of("Insert");
      case 261:
         return EncryptedString.of("Delete");
      case 262:
         return EncryptedString.of("Arrow Right");
      case 263:
         return EncryptedString.of("Arrow Left");
      case 264:
         return EncryptedString.of("Arrow Down");
      case 265:
         return EncryptedString.of("Arrow Up");
      case 266:
         return EncryptedString.of("Page Up");
      case 267:
         return EncryptedString.of("Page Down");
      case 268:
         return EncryptedString.of("Home");
      case 269:
         return EncryptedString.of("End");
      case 280:
         return EncryptedString.of("Caps Lock");
      case 281:
         return EncryptedString.of("Scroll Lock");
      case 282:
         return EncryptedString.of("Num Lock");
      case 283:
         return EncryptedString.of("Print Screen");
      case 284:
         return EncryptedString.of("Pause");
      case 290:
         return EncryptedString.of("F1");
      case 291:
         return EncryptedString.of("F2");
      case 292:
         return EncryptedString.of("F3");
      case 293:
         return EncryptedString.of("F4");
      case 294:
         return EncryptedString.of("F5");
      case 295:
         return EncryptedString.of("F6");
      case 296:
         return EncryptedString.of("F7");
      case 297:
         return EncryptedString.of("F8");
      case 298:
         return EncryptedString.of("F9");
      case 299:
         return EncryptedString.of("F10");
      case 300:
         return EncryptedString.of("F11");
      case 301:
         return EncryptedString.of("F12");
      case 302:
         return EncryptedString.of("F13");
      case 303:
         return EncryptedString.of("F14");
      case 304:
         return EncryptedString.of("F15");
      case 305:
         return EncryptedString.of("F16");
      case 306:
         return EncryptedString.of("F17");
      case 307:
         return EncryptedString.of("F18");
      case 308:
         return EncryptedString.of("F19");
      case 309:
         return EncryptedString.of("F20");
      case 310:
         return EncryptedString.of("F21");
      case 311:
         return EncryptedString.of("F22");
      case 312:
         return EncryptedString.of("F23");
      case 313:
         return EncryptedString.of("F24");
      case 314:
         return EncryptedString.of("F25");
      case 335:
         return EncryptedString.of("Numpad Enter");
      case 340:
         return EncryptedString.of("Left Shift");
      case 341:
         return EncryptedString.of("Left Control");
      case 342:
         return EncryptedString.of("Left Alt");
      case 343:
         return EncryptedString.of("Left Super");
      case 344:
         return EncryptedString.of("Right Shift");
      case 345:
         return EncryptedString.of("Right Control");
      case 346:
         return EncryptedString.of("Right Alt");
      case 347:
         return EncryptedString.of("Right Super");
      case 348:
         return EncryptedString.of("Menu");
      }
   }

   public static boolean isKeyPressed(int keyCode) {
      if (keyCode <= 8) {
         return GLFW.glfwGetMouseButton(system.mc.method_22683().method_4490(), keyCode) == 1;
      } else {
         return GLFW.glfwGetKey(system.mc.method_22683().method_4490(), keyCode) == 1;
      }
   }
}
