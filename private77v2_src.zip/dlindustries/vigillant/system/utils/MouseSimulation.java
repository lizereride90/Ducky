package dlindustries.vigillant.system.utils;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.mixin.MinecraftClientAccessor;
import dlindustries.vigillant.system.mixin.MouseHandlerAccessor;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MouseSimulation {
   public static HashMap<Integer, Boolean> mouseButtons = new HashMap();
   public static ExecutorService clickExecutor = Executors.newFixedThreadPool(100);

   public static MouseHandlerAccessor getMouseHandler() {
      return (MouseHandlerAccessor)((MinecraftClientAccessor)system.mc).getMouse();
   }

   public static boolean isMouseButtonPressed(int keyCode) {
      Boolean key = (Boolean)mouseButtons.get(keyCode);
      return key != null ? key : false;
   }

   public static void mousePress(int keyCode) {
      mouseButtons.put(keyCode, true);
      getMouseHandler().press(system.mc.method_22683().method_4490(), keyCode, 1, 0);
   }

   public static void mouseRelease(int keyCode) {
      getMouseHandler().press(system.mc.method_22683().method_4490(), keyCode, 0, 0);
   }

   public static void mouseClick(int keyCode, int millis) {
      clickExecutor.submit(() -> {
         try {
            mousePress(keyCode);
            Thread.sleep((long)millis);
            mouseRelease(keyCode);
         } catch (InterruptedException var3) {
         }

      });
   }

   public static void mouseClick(int keyCode) {
      mouseClick(keyCode, 35);
   }
}
