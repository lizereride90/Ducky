package dlindustries.vigillant.system.utils.rotation;

public record Rotation(double yaw, double pitch) {
   public Rotation(double yaw, double pitch) {
      this.yaw = yaw;
      this.pitch = pitch;
   }

   public double yaw() {
      return this.yaw;
   }

   public double pitch() {
      return this.pitch;
   }
}
