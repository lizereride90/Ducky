package dlindustries.vigillant.system.utils.rotation;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.event.EventManager;
import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.BlockBreakingListener;
import dlindustries.vigillant.system.event.events.ItemUseListener;
import dlindustries.vigillant.system.event.events.MovementPacketListener;
import dlindustries.vigillant.system.event.events.PacketReceiveListener;
import dlindustries.vigillant.system.event.events.PacketSendListener;
import dlindustries.vigillant.system.utils.RotationUtils;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2828;

public final class RotatorManager implements PacketSendListener, BlockBreakingListener, ItemUseListener, AttackListener, MovementPacketListener, PacketReceiveListener {
   private boolean enabled;
   private boolean rotateBack;
   private boolean resetRotation;
   private final EventManager eventManager;
   private Rotation currentRotation;
   private float clientYaw;
   private float clientPitch;
   private float serverYaw;
   private float serverPitch;
   private boolean wasDisabled;

   public RotatorManager() {
      this.eventManager = system.INSTANCE.eventManager;
      this.eventManager.remove(PacketSendListener.class, this);
      this.eventManager.remove(AttackListener.class, this);
      this.eventManager.remove(ItemUseListener.class, this);
      this.eventManager.remove(MovementPacketListener.class, this);
      this.eventManager.remove(PacketReceiveListener.class, this);
      this.eventManager.remove(BlockBreakingListener.class, this);
      this.enabled = true;
      this.rotateBack = false;
      this.resetRotation = false;
      this.serverYaw = 0.0F;
      this.serverPitch = 0.0F;
      this.clientYaw = 0.0F;
      this.clientPitch = 0.0F;
   }

   public void shutDown() {
      this.eventManager.remove(PacketSendListener.class, this);
      this.eventManager.remove(AttackListener.class, this);
      this.eventManager.remove(ItemUseListener.class, this);
      this.eventManager.remove(MovementPacketListener.class, this);
      this.eventManager.remove(PacketReceiveListener.class, this);
      this.eventManager.remove(BlockBreakingListener.class, this);
   }

   public Rotation getServerRotation() {
      return new Rotation((double)this.serverYaw, (double)this.serverPitch);
   }

   public void enable() {
      this.enabled = true;
      this.rotateBack = false;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void disable() {
      if (this.isEnabled()) {
         this.enabled = false;
         if (!this.rotateBack) {
            this.rotateBack = true;
         }
      }

   }

   public void setRotation(Rotation rotation) {
      this.currentRotation = rotation;
   }

   public void setRotation(double yaw, double pitch) {
      this.setRotation(new Rotation(yaw, pitch));
   }

   private void resetClientRotation() {
      system.mc.field_1724.method_36456(this.clientYaw);
      system.mc.field_1724.method_36457(this.clientPitch);
      this.resetRotation = false;
   }

   public void setClientRotation(Rotation rotation) {
      this.clientYaw = system.mc.field_1724.method_36454();
      this.clientPitch = system.mc.field_1724.method_36455();
      system.mc.field_1724.method_36456((float)rotation.yaw());
      system.mc.field_1724.method_36457((float)rotation.pitch());
      this.resetRotation = true;
   }

   public void setServerRotation(Rotation rotation) {
      this.serverYaw = (float)rotation.yaw();
      this.serverPitch = (float)rotation.pitch();
   }

   public void onAttack(AttackListener.AttackEvent event) {
      if (!this.isEnabled() && this.wasDisabled) {
         this.enabled = true;
         this.wasDisabled = false;
      }

   }

   public void onItemUse(ItemUseListener.ItemUseEvent event) {
      if (!event.isCancelled() && this.isEnabled()) {
         this.enabled = false;
         this.wasDisabled = true;
      }

   }

   public void onPacketSend(PacketSendListener.PacketSendEvent event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof class_2828) {
         class_2828 packet = (class_2828)var3;
         this.serverYaw = packet.method_12271(this.serverYaw);
         this.serverPitch = packet.method_12270(this.serverPitch);
      }

   }

   public void onBlockBreaking(BlockBreakingListener.BlockBreakingEvent event) {
      if (!event.isCancelled() && this.isEnabled()) {
         this.enabled = false;
         this.wasDisabled = true;
      }

   }

   public void onSendMovementPackets() {
      if (this.isEnabled() && this.currentRotation != null) {
         this.setClientRotation(this.currentRotation);
         this.setServerRotation(this.currentRotation);
      } else {
         if (this.rotateBack) {
            Rotation serverRot = new Rotation((double)this.serverYaw, (double)this.serverPitch);
            Rotation clientRot = new Rotation((double)system.mc.field_1724.method_36454(), (double)system.mc.field_1724.method_36455());
            if (RotationUtils.getTotalDiff(serverRot, clientRot) > 1.0D) {
               Rotation smoothRotation = RotationUtils.getSmoothRotation(serverRot, clientRot, 0.2D);
               this.setClientRotation(smoothRotation);
               this.setServerRotation(smoothRotation);
            } else {
               this.rotateBack = false;
            }
         }

      }
   }

   public void onPacketReceive(PacketReceiveListener.PacketReceiveEvent event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof class_2708) {
         class_2708 packet = (class_2708)var3;
         this.serverYaw = packet.method_11736();
         this.serverPitch = packet.method_11739();
      }

   }
}
