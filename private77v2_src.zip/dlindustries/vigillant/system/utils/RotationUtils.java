package dlindustries.vigillant.system.utils;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.utils.rotation.Rotation;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public final class RotationUtils {
   public static class_243 getEyesPos(class_1657 player) {
      return RenderUtils.getCameraPos();
   }

   public static class_2338 getCameraBlockPos() {
      return system.mc.method_31975().field_4344.method_19328();
   }

   public static class_2338 getEyesBlockPos() {
      return new class_2338((int)getEyesPos(system.mc.field_1724).field_1352, (int)getEyesPos(system.mc.field_1724).field_1351, (int)getEyesPos(system.mc.field_1724).field_1350);
   }

   public static class_243 getPlayerLookVec(float yaw, float pitch) {
      float f = pitch * 0.017453292F;
      float g = -yaw * 0.017453292F;
      float h = class_3532.method_15362(g);
      float i = class_3532.method_15374(g);
      float j = class_3532.method_15362(f);
      float k = class_3532.method_15374(f);
      return new class_243((double)(i * j), (double)(-k), (double)(h * j));
   }

   public static class_243 getPlayerLookVec(class_1657 player) {
      return getPlayerLookVec(player.method_36454(), player.method_36455());
   }

   public static Rotation getDiff(Rotation rotation1, Rotation rotation2) {
      double yaw = Math.abs(Math.max(rotation1.yaw(), rotation2.yaw()) - Math.min(rotation1.yaw(), rotation2.yaw()));
      double pitch = Math.abs(Math.max(rotation1.pitch(), rotation2.pitch()) - Math.min(rotation1.pitch(), rotation2.pitch()));
      return new Rotation(yaw, pitch);
   }

   public static Rotation getSmoothRotation(Rotation from, Rotation to, double speed) {
      return new Rotation((double)class_3532.method_17821((float)speed, (float)from.yaw(), (float)to.yaw()), (double)class_3532.method_17821((float)speed, (float)from.pitch(), (float)to.pitch()));
   }

   public static double getTotalDiff(Rotation rotation1, Rotation rotation2) {
      Rotation diff = getDiff(rotation1, rotation2);
      return diff.yaw() + diff.pitch();
   }

   public static class_243 getClientLookVec() {
      return getPlayerLookVec(system.mc.field_1724);
   }

   public static Rotation getDirection(class_1297 entity, class_243 vec) {
      double dx = vec.field_1352 - entity.method_23317();
      double dy = vec.field_1351 - entity.method_23318();
      double dz = vec.field_1350 - entity.method_23321();
      double dist = (double)class_3532.method_15355((float)(dx * dx + dz * dz));
      return new Rotation(class_3532.method_15338(Math.toDegrees(Math.atan2(dz, dx)) - 90.0D), -class_3532.method_15338(Math.toDegrees(Math.atan2(dy, dist))));
   }

   public static double getAngleToRotation(Rotation rotation) {
      double currentYaw = (double)class_3532.method_15393(system.mc.field_1724.method_36454());
      double currentPitch = (double)class_3532.method_15393(system.mc.field_1724.method_36455());
      double diffYaw = class_3532.method_15338(currentYaw - rotation.yaw());
      double diffPitch = class_3532.method_15338(currentPitch - rotation.pitch());
      return Math.sqrt(diffYaw * diffYaw + diffPitch * diffPitch);
   }
}
