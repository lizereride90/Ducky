package dlindustries.vigillant.system.utils;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.mixin.ClientPlayerInteractionManagerAccessor;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;
import net.minecraft.class_1263;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1828;
import net.minecraft.class_1829;
import net.minecraft.class_1844;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

public final class InventoryUtils {
   public static void setInvSlot(int slot) {
      system.mc.field_1724.method_31548().field_7545 = slot;
      ((ClientPlayerInteractionManagerAccessor)system.mc.field_1761).syncSlot();
   }

   public static boolean selectItemFromHotbar(Predicate<class_1792> item) {
      class_1661 inv = system.mc.field_1724.method_31548();

      for(int i = 0; i < 9; ++i) {
         class_1799 stack = inv.method_5438(i);
         if (item.test(stack.method_7909())) {
            inv.field_7545 = i;
            return true;
         }
      }

      return false;
   }

   public static boolean selectItemFromHotbar(class_1792 item) {
      return selectItemFromHotbar((i) -> {
         return i == item;
      });
   }

   public static boolean hasItemInHotbar(Predicate<class_1792> item) {
      class_1661 inv = system.mc.field_1724.method_31548();

      for(int i = 0; i < 9; ++i) {
         if (item.test(inv.method_5438(i).method_7909())) {
            return true;
         }
      }

      return false;
   }

   public static int countItem(Predicate<class_1792> item) {
      class_1661 inv = system.mc.field_1724.method_31548();
      int count = 0;

      for(int i = 0; i < 36; ++i) {
         class_1799 stack = inv.method_5438(i);
         if (item.test(stack.method_7909())) {
            count += stack.method_7947();
         }
      }

      return count;
   }

   public static int countItemExceptHotbar(Predicate<class_1792> item) {
      class_1661 inv = system.mc.field_1724.method_31548();
      int count = 0;

      for(int i = 9; i < 36; ++i) {
         class_1799 stack = inv.method_5438(i);
         if (item.test(stack.method_7909())) {
            count += stack.method_7947();
         }
      }

      return count;
   }

   public static int getSwordSlot() {
      class_1263 inv = system.mc.field_1724.method_31548();

      for(int i = 0; i < 9; ++i) {
         if (inv.method_5438(i).method_7909() instanceof class_1829) {
            return i;
         }
      }

      return -1;
   }

   public static boolean selectSword() {
      int slot = getSwordSlot();
      if (slot != -1) {
         setInvSlot(slot);
         return true;
      } else {
         return false;
      }
   }

   public static int findSplash(class_1291 type, int duration, int amplifier) {
      class_1661 inv = system.mc.field_1724.method_31548();
      class_1293 want = new class_1293(class_7923.field_41174.method_47983(type), duration, amplifier);

      for(int i = 0; i < 9; ++i) {
         class_1799 stack = inv.method_5438(i);
         if (stack.method_7909() instanceof class_1828) {
            String effects = ((class_1844)stack.method_57824(class_9334.field_49651)).method_57397().toString();
            if (effects.contains(want.toString())) {
               return i;
            }
         }
      }

      return -1;
   }

   public static boolean isThatSplash(class_1291 type, int duration, int amplifier, class_1799 stack) {
      if (!(stack.method_7909() instanceof class_1828)) {
         return false;
      } else {
         class_1293 want = new class_1293(class_7923.field_41174.method_47983(type), duration, amplifier);
         return ((class_1844)stack.method_57824(class_9334.field_49651)).method_57397().toString().contains(want.toString());
      }
   }

   public static int findTotemSlot() {
      class_1661 inv = system.mc.field_1724.method_31548();

      for(int i = 9; i < 36; ++i) {
         if (((class_1799)inv.field_7547.get(i)).method_7909() == class_1802.field_8288) {
            return i;
         }
      }

      return -1;
   }

   public static boolean selectAxe() {
      int slot = getAxeSlot();
      if (slot != -1) {
         setInvSlot(slot);
         return true;
      } else {
         return false;
      }
   }

   public static int findRandomTotemSlot() {
      class_1661 inv = system.mc.field_1724.method_31548();
      List<Integer> totems = new ArrayList();

      for(int i = 9; i < 36; ++i) {
         if (((class_1799)inv.field_7547.get(i)).method_7909() == class_1802.field_8288) {
            totems.add(i);
         }
      }

      if (!totems.isEmpty()) {
         return (Integer)totems.get((new Random()).nextInt(totems.size()));
      } else {
         return -1;
      }
   }

   public static int findRandomPot(String potion) {
      class_1661 inv = system.mc.field_1724.method_31548();
      int start = (new Random()).nextInt(27) + 9;

      for(int i = 0; i < 27; ++i) {
         int idx = (start + i) % 36;
         class_1799 stack = (class_1799)inv.field_7547.get(idx);
         if (stack.method_7909() instanceof class_1828) {
            if (((class_1844)stack.method_57824(class_9334.field_49651)).method_57397().toString().contains(potion)) {
               return idx;
            }

            return -1;
         }
      }

      return -1;
   }

   public static int findPot(class_1291 effect, int duration, int amplifier) {
      class_1661 inv = system.mc.field_1724.method_31548();
      class_1293 want = new class_1293(class_7923.field_41174.method_47983(effect), duration, amplifier);

      for(int i = 9; i < 36; ++i) {
         class_1799 stack = (class_1799)inv.field_7547.get(i);
         if (stack.method_7909() instanceof class_1828 && ((class_1844)stack.method_57824(class_9334.field_49651)).method_57397().toString().contains(want.toString())) {
            return i;
         }
      }

      return -1;
   }

   public static List<Integer> getEmptyHotbarSlots() {
      class_1661 inv = system.mc.field_1724.method_31548();
      List<Integer> slots = new ArrayList();

      for(int i = 0; i < 9; ++i) {
         if (((class_1799)inv.field_7547.get(i)).method_7960()) {
            slots.add(i);
         } else {
            slots.remove(i);
         }
      }

      return slots;
   }

   public static int getAxeSlot() {
      class_1263 inv = system.mc.field_1724.method_31548();

      for(int i = 0; i < 9; ++i) {
         if (inv.method_5438(i).method_7909() instanceof class_1743) {
            return i;
         }
      }

      return -1;
   }

   public static int countItem(class_1792 item) {
      return countItem((i) -> {
         return i == item;
      });
   }

   public static boolean hasItem(class_1792 item) {
      if (system.mc.field_1724 == null) {
         return false;
      } else if (system.mc.field_1724.method_6079().method_7909() == item) {
         return true;
      } else {
         for(int i = 0; i < 36; ++i) {
            if (system.mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
               return true;
            }
         }

         return false;
      }
   }

   public static int findItemSlot(class_1792 item) {
      for(int i = 0; i < 9; ++i) {
         if (system.mc.field_1724.method_31548().method_5438(i).method_31574(item)) {
            return i;
         }
      }

      return -1;
   }

   public static void swap(int slot) {
      system.mc.field_1761.method_2906(system.mc.field_1724.field_7512.field_7763, slot + 36, 0, class_1713.field_7791, system.mc.field_1724);
   }
}
