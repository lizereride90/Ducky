package dlindustries.vigillant.system.gui;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.gui.components.ModuleButton;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import dlindustries.vigillant.system.utils.ColorUtils;
import dlindustries.vigillant.system.utils.MathUtils;
import dlindustries.vigillant.system.utils.RenderUtils;
import dlindustries.vigillant.system.utils.TextRenderer;
import dlindustries.vigillant.system.utils.Utils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_332;

public final class Window {

    public List<ModuleButton> moduleButtons = new ArrayList<>();
    public int x, y;
    private final int width;
    private final int height;
    public Color currentColor;
    private final Category category;
    public boolean dragging;
    public boolean extended;
    private int dragX, dragY;
    private int prevX, prevY;
    public ClickGui parent;

    public Window(int x, int y, int width, int height, Category category, ClickGui parent) {
        this.x = x; this.y = y;
        this.width = width; this.height = height;
        this.dragging = false; this.extended = true;
        this.category = category; this.parent = parent;
        this.prevX = x; this.prevY = y;
        int offset = height;
        for (Module module : new ArrayList<>(system.INSTANCE.getModuleManager().getModulesInCategory(category))) {
            this.moduleButtons.add(new ModuleButton(this, module, offset));
            offset += height;
        }
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        int toAlpha = ClickGUI.alphaWindow.getValueInt();
        if (this.currentColor == null) {
            this.currentColor = new Color(10, 10, 18, 0);
        } else {
            this.currentColor = new Color(10, 10, 18, this.currentColor.getAlpha());
        }
        if (this.currentColor.getAlpha() != toAlpha)
            this.currentColor = ColorUtils.smoothAlphaTransition(0.06f, toAlpha, this.currentColor);

        double radius = ClickGUI.roundQuads.getValueInt();

        // Window body
        RenderUtils.renderRoundedQuad(context.method_51448(), this.currentColor,
            prevX, prevY, prevX + width, prevY + height,
            radius, radius, 0.0, 0.0, 50.0);

        // Header accent underline
        int idx0 = this.moduleButtons.isEmpty() ? 0 : this.moduleButtons.indexOf(this.moduleButtons.get(0));
        context.method_25296(
            prevX, prevY + height - 2,
            prevX + width, prevY + height,
            Utils.getMainColor(210, idx0).getRGB(),
            Utils.getMainColor(210, idx0 + 1).getRGB());

        // Category label – accent colored, centered
        CharSequence catName = this.category.name;
        int tw = TextRenderer.getWidth(catName);
        int startX = prevX + width / 2 - tw / 2;
        TextRenderer.drawString(catName, context, startX, prevY + 7,
            Utils.getMainColor(255, 0).getRGB());

        updateButtons(delta);
        for (ModuleButton mb : this.moduleButtons)
            mb.render(context, mouseX, mouseY, delta);
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        for (ModuleButton mb : this.moduleButtons) mb.keyPressed(keyCode, scanCode, modifiers);
    }

    public void onGuiClose() {
        this.currentColor = null;
        this.dragging = false;
        for (ModuleButton mb : this.moduleButtons) mb.onGuiClose();
    }

    public boolean isDraggingAlready() {
        for (Window w : this.parent.windows) if (w.dragging) return true;
        return false;
    }

    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isHovered(mouseX, mouseY)) {
            if (button == 0 && !this.parent.isDraggingAlready()) {
                this.dragging = true;
                this.dragX = (int)(mouseX - this.x);
                this.dragY = (int)(mouseY - this.y);
            }
        }
        if (this.extended)
            for (ModuleButton mb : this.moduleButtons) mb.mouseClicked(mouseX, mouseY, button);
    }

    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.extended)
            for (ModuleButton mb : this.moduleButtons) mb.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    public void updateButtons(float delta) {
        int offset = this.height;
        for (ModuleButton mb : this.moduleButtons) {
            mb.animation.animate(0.5 * delta,
                mb.extended
                    ? (double)(this.height * (mb.settings.size() + 1))
                    : (double) this.height);
            mb.offset = offset;
            offset += (int) mb.animation.getValue();
        }
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && this.dragging) this.dragging = false;
        for (ModuleButton mb : this.moduleButtons) mb.mouseReleased(mouseX, mouseY, button);
    }

    public void mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        this.prevX = this.x;
        this.prevY = this.y;
        int step = 20;
        this.prevY = (int)(this.prevY + vertical * step);
        this.y    = (int)(this.y    + vertical * step);
    }

    public int getX() { return prevX; }
    public int getY() { return prevY; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public int getWidth()  { return width; }
    public int getHeight() { return height; }

    public boolean isHovered(double mx, double my) {
        return mx > x && mx < x + width && my > y && my < y + height;
    }
    public boolean isPrevHovered(double mx, double my) {
        return mx > prevX && mx < prevX + width && my > prevY && my < prevY + height;
    }

    public void updatePosition(double mouseX, double mouseY, float delta) {
        this.prevX = this.x;
        this.prevY = this.y;
        if (this.dragging) {
            this.x = (int) MathUtils.goodLerp(0.28f * delta,
                this.isHovered(mouseX, mouseY) ? (double) this.x : (double) this.prevX,
                mouseX - this.dragX);
            this.y = (int) MathUtils.goodLerp(0.28f * delta,
                this.isHovered(mouseX, mouseY) ? (double) this.y : (double) this.prevY,
                mouseY - this.dragY);
        }
    }
}
