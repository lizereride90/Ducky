package dlindustries.vigillant.system.gui;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import dlindustries.vigillant.system.utils.ColorUtils;
import dlindustries.vigillant.system.utils.RenderUtils;
import dlindustries.vigillant.system.utils.TextRenderer;
import dlindustries.vigillant.system.utils.Utils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class ClickGui extends class_437 {

    public List<Window> windows = new ArrayList<>();
    public Color currentColor;

    // ── GUI scale (Ctrl + Scroll) ──────────────────────────────────────
    // Stored as a multiplier: 1.0 = 100 %. Range 0.5 – 2.0
    private float guiScaleFactor = 1.0f;
    private static final float SCALE_MIN  = 0.5f;
    private static final float SCALE_MAX  = 2.0f;
    private static final float SCALE_STEP = 0.05f;

    public ClickGui() {
        super(class_2561.method_43473());
        initWindows();
    }

    private void initWindows() {
        this.windows.clear();
        int offsetX = 30;
        for (Category category : Category.values()) {
            this.windows.add(new Window(offsetX, 40, 210, 28, category, this));
            offsetX += 228;
        }
    }

    // ── Public scale accessor (used by Window / rendering) ────────────
    public float getGuiScale() { return guiScaleFactor; }

    public boolean isDraggingAlready() {
        for (Window w : this.windows) if (w.dragging) return true;
        return false;
    }

    // ── Watermark (bottom-right) ───────────────────────────────────────
    private void renderWatermark(class_332 context) {
        if (system.mc.field_1724 == null || system.mc.method_22683() == null) return;
        RenderUtils.scaledProjection();
        String playerName = system.mc.field_1724.method_5477().getString();
        String line1 = "private77v2  |  " + playerName;
        String line2 = "by DL-industries";
        int sw  = system.mc.method_22683().method_4486();
        int sh  = system.mc.method_22683().method_4502();
        float sc = 0.55f;
        int w1  = Math.round(TextRenderer.getWidth(line1) * sc);
        int w2  = Math.round(TextRenderer.getWidth(line2) * sc);
        int maxW = Math.max(w1, w2);
        int lineH = Math.round(9 * sc);
        int pad   = 5;
        int bx    = sw - maxW - pad * 2 - 4;
        int by    = sh - lineH * 2 - pad * 2 - 6;
        int bw    = maxW + pad * 2 + 4;
        int bh    = lineH * 2 + pad * 2 + 4;

        context.method_51448().method_22903();
        RenderUtils.renderRoundedQuad(context.method_51448(),
            new Color(12, 12, 18, 200),
            bx, by, bx + bw, by + bh, 4.0, 8.0);
        context.method_25296(bx, by + 2, bx + 2, by + bh - 2,
            Utils.getMainColor(255, 0).getRGB(),
            Utils.getMainColor(255, 2).getRGB());
        context.method_51448().method_46416(bx + pad + 2, by + pad, 0f);
        context.method_51448().method_22905(sc, sc, 1f);
        TextRenderer.drawString(line1, context, 0, 0, Utils.getMainColor(255, 0).getRGB());
        TextRenderer.drawString(line2, context, 0, lineH + 2, new Color(180, 180, 200, 220).getRGB());
        context.method_51448().method_22909();
        RenderUtils.unscaledProjection();
    }

    // ── Scale hint (top-center, fades quickly) ─────────────────────────
    private int scaleHintTimer = 0;
    private void renderScaleHint(class_332 context) {
        if (scaleHintTimer <= 0) return;
        scaleHintTimer--;
        RenderUtils.scaledProjection();
        String hint = String.format("GUI Scale: %.0f%%", guiScaleFactor * 100f);
        int sw = system.mc.method_22683().method_4486();
        int tw = TextRenderer.getWidth(hint);
        int x  = sw / 2 - tw / 2;
        int y  = 12;
        int alpha = Math.min(255, scaleHintTimer * 8);
        RenderUtils.renderRoundedQuad(context.method_51448(),
            new Color(14, 14, 22, (int)(alpha * 0.75f)),
            x - 8, y - 4, x + tw + 8, y + 14, 3.0, 8.0);
        TextRenderer.drawString(hint, context, x, y, Utils.getMainColor(alpha, 0).getRGB());
        RenderUtils.unscaledProjection();
    }

    // ── Main render ───────────────────────────────────────────────────
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (system.mc.field_1755 != this) return;

        // Sync scale from setting (so it saves/loads via ProfileManager)
        guiScaleFactor = (float)(ClickGUI.guiScale.getValue() / 100.0);

        if (system.INSTANCE.previousScreen != null)
            system.INSTANCE.previousScreen.method_25394(context, 0, 0, delta);

        // Dark overlay
        if (this.currentColor == null) {
            this.currentColor = new Color(8, 8, 14, 0);
        } else {
            this.currentColor = new Color(8, 8, 14, this.currentColor.getAlpha());
        }
        int targetAlpha = ClickGUI.background.getValue() ? 185 : 0;
        if (this.currentColor.getAlpha() != targetAlpha)
            this.currentColor = ColorUtils.smoothAlphaTransition(0.07f, targetAlpha, this.currentColor);

        if (system.mc.field_1755 instanceof ClickGui)
            context.method_25294(0, 0,
                system.mc.method_22683().method_4480(),
                system.mc.method_22683().method_4507(),
                this.currentColor.getRGB());

        // Background image
        if (ClickGUI.backgroundImage.getValue()) {
            RenderUtils.unscaledProjection();
            class_2960 BG = class_2960.method_60655("system", "images/background-army.png");
            int imgW = 699, imgH = 357;
            int sw = system.mc.method_22683().method_4480();
            int sh = system.mc.method_22683().method_4507();
            context.method_25290(BG, (sw - imgW) / 2, sh - imgH, 0f, 0f, imgW, imgH, imgW, imgH);
            RenderUtils.scaledProjection();
        }

        RenderUtils.unscaledProjection();
        mouseX *= (int) class_310.method_1551().method_22683().method_4495();
        mouseY *= (int) class_310.method_1551().method_22683().method_4495();
        super.method_25394(context, mouseX, mouseY, delta);

        // ── Apply GUI scale matrix ───────────────────────────────────
        int sw = system.mc.method_22683().method_4480();
        int sh = system.mc.method_22683().method_4507();
        float sc = guiScaleFactor;
        // Scale from center
        float pivotX = sw / 2f;
        float pivotY = sh / 2f;
        context.method_51448().method_22903();
        context.method_51448().method_46416(pivotX, pivotY, 0f);
        context.method_51448().method_22905(sc, sc, 1f);
        context.method_51448().method_46416(-pivotX, -pivotY, 0f);

        for (Window window : this.windows) {
            window.render(context, mouseX, mouseY, delta);
            window.updatePosition((double) mouseX, (double) mouseY, delta);
        }

        context.method_51448().method_22909();
        // ── End scale ────────────────────────────────────────────────

        this.renderWatermark(context);
        this.renderScaleHint(context);
        RenderUtils.scaledProjection();
    }

    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        for (Window w : this.windows) w.keyPressed(keyCode, scanCode, modifiers);
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public boolean method_25402(double mouseX, double mouseY, int button) {
        mouseX *= (double)((int) class_310.method_1551().method_22683().method_4495());
        mouseY *= (double)((int) class_310.method_1551().method_22683().method_4495());
        // Inverse-scale mouse coords for hit testing
        mouseX = inverseScaleX(mouseX);
        mouseY = inverseScaleY(mouseY);
        for (Window w : this.windows) w.mouseClicked(mouseX, mouseY, button);
        return super.method_25402(mouseX, mouseY, button);
    }

    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        mouseX *= (double)((int) class_310.method_1551().method_22683().method_4495());
        mouseY *= (double)((int) class_310.method_1551().method_22683().method_4495());
        mouseX = inverseScaleX(mouseX);
        mouseY = inverseScaleY(mouseY);
        for (Window w : this.windows) w.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    // Ctrl + Scroll = resize GUI
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        long window = class_310.method_1551().method_22683().method_4493();
        // GLFW_KEY_LEFT_CONTROL = 341, GLFW_KEY_RIGHT_CONTROL = 345
        // We check via GLFW directly through the mc keyboard handler
        boolean ctrlHeld = isCtrlHeld();
        if (ctrlHeld) {
            float newScale = guiScaleFactor + (float)(verticalAmount * SCALE_STEP);
            newScale = Math.max(SCALE_MIN, Math.min(SCALE_MAX, newScale));
            guiScaleFactor = newScale;
            ClickGUI.guiScale.setValue(Math.round(newScale * 100.0));
            scaleHintTimer = 50; // show hint for ~2.5 seconds
            return true;
        }
        mouseY *= class_310.method_1551().method_22683().method_4495();
        mouseX = inverseScaleX(mouseX);
        mouseY = inverseScaleY(mouseY);
        for (Window w : this.windows) w.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    private boolean isCtrlHeld() {
        // GLFW_PRESS = 1. We check left ctrl (341) and right ctrl (345)
        try {
            long win = class_310.method_1551().method_22683().method_4493();
            return org.lwjgl.glfw.GLFW.glfwGetKey(win, 341) == 1
                || org.lwjgl.glfw.GLFW.glfwGetKey(win, 345) == 1;
        } catch (Throwable t) {
            return false;
        }
    }

    // Convert raw mouse coords back through the inverse scale transform
    private double inverseScaleX(double x) {
        int sw = system.mc.method_22683().method_4480();
        float pivot = sw / 2f;
        return (x - pivot) / guiScaleFactor + pivot;
    }
    private double inverseScaleY(double y) {
        int sh = system.mc.method_22683().method_4507();
        float pivot = sh / 2f;
        return (y - pivot) / guiScaleFactor + pivot;
    }

    public boolean method_25406(double mouseX, double mouseY, int button) {
        mouseX *= (double)((int) class_310.method_1551().method_22683().method_4495());
        mouseY *= (double)((int) class_310.method_1551().method_22683().method_4495());
        mouseX = inverseScaleX(mouseX);
        mouseY = inverseScaleY(mouseY);
        for (Window w : this.windows) w.mouseReleased(mouseX, mouseY, button);
        return super.method_25406(mouseX, mouseY, button);
    }

    public boolean method_25421() { return false; }

    public void method_25419() {
        ((ClickGUI) system.INSTANCE.getModuleManager().getModule(ClickGUI.class)).setEnabledStatus(false);
        this.onGuiClose();
    }

    public void onGuiClose() {
        system.mc.method_29970(system.INSTANCE.previousScreen);
        this.currentColor = null;
        for (Window w : this.windows) w.onGuiClose();
    }
}
