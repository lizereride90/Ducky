package dlindustries.vigillant.system.gui.components.settings;

import dlindustries.vigillant.system.gui.components.ModuleButton;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.utils.ColorUtils;
import dlindustries.vigillant.system.utils.TextRenderer;
import dlindustries.vigillant.system.utils.Utils;
import java.awt.Color;
import net.minecraft.class_332;

public final class CheckBox extends RenderableSetting {
   private final BooleanSetting setting;
   private Color currentAlpha;

   public CheckBox(ModuleButton parent, Setting<?> setting, int offset) {
      super(parent, setting, offset);
      this.setting = (BooleanSetting)setting;
   }

   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      super.render(context, mouseX, mouseY, delta);
      int nameOffset = this.parentX() + 31;
      CharSequence chars = this.setting.getName();
      TextRenderer.drawString(chars, context, nameOffset, this.parentY() + this.parentOffset() + this.offset + 9, (new Color(245, 245, 245, 255)).getRGB());
      context.method_25294(this.parentX() + 7, this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2 - 8, this.parentX() + 23, this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2 + 8, (new Color(100, 100, 100, 255)).getRGB());
      context.method_25294(this.parentX() + 8, this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2 - 7, this.parentX() + 22, this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2 + 7, this.setting.getValue() ? Utils.getMainColor(255, this.parent.settings.indexOf(this)).getRGB() : (new Color(50, 50, 50, 255)).getRGB());
      if (this.setting.getValue()) {
         context.method_25294(this.parentX() + 11, this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2 - 4, this.parentX() + 19, this.parentY() + this.parentOffset() + this.offset + this.parentHeight() / 2 + 4, (new Color(245, 245, 245, 255)).getRGB());
      }

      if (!this.parent.parent.dragging) {
         int toHoverAlpha = this.isHovered((double)mouseX, (double)mouseY) ? 15 : 0;
         if (this.currentAlpha == null) {
            this.currentAlpha = new Color(255, 255, 255, toHoverAlpha);
         } else {
            this.currentAlpha = new Color(255, 255, 255, this.currentAlpha.getAlpha());
         }

         if (this.currentAlpha.getAlpha() != toHoverAlpha) {
            this.currentAlpha = ColorUtils.smoothAlphaTransition(0.05F, toHoverAlpha, this.currentAlpha);
         }

         context.method_25294(this.parentX(), this.parentY() + this.parentOffset() + this.offset, this.parentX() + this.parentWidth(), this.parentY() + this.parentOffset() + this.offset + this.parentHeight(), this.currentAlpha.getRGB());
      }

   }

   public void keyPressed(int keyCode, int scanCode, int modifiers) {
      if (this.mouseOver && this.parent.extended && keyCode == 259) {
         this.setting.setValue(this.setting.getOriginalValue());
      }

      super.keyPressed(keyCode, scanCode, modifiers);
   }

   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (this.isHovered(mouseX, mouseY) && button == 0) {
         this.setting.toggle();
      }

      super.mouseClicked(mouseX, mouseY, button);
   }
}
