package dlindustries.vigillant.system.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.gui.Window;
import dlindustries.vigillant.system.gui.components.settings.*;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import dlindustries.vigillant.system.module.setting.*;
import dlindustries.vigillant.system.utils.*;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ModuleButton {

    public List<RenderableSetting> settings = new ArrayList<>();
    public Window  parent;
    public Module  module;
    public int     offset;
    public boolean extended;
    public int     settingOffset;
    public Color   currentColor;
    public Color   defaultColor;
    public Color   currentAlpha;
    public AnimationUtils animation;

    public ModuleButton(Window parent, Module module, int offset) {
        this.defaultColor  = Color.WHITE;
        this.animation     = new AnimationUtils(0.0);
        this.parent        = parent;
        this.module        = module;
        this.offset        = offset;
        this.extended      = false;
        this.settingOffset = parent.getHeight();

        for (Setting<?> s : module.getSettings()) {
            if      (s instanceof BooleanSetting)  this.settings.add(new CheckBox   (this, (BooleanSetting)  s, this.settingOffset));
            else if (s instanceof NumberSetting)   this.settings.add(new Slider      (this, (NumberSetting)   s, this.settingOffset));
            else if (s instanceof ModeSetting)     this.settings.add(new ModeBox     (this, (ModeSetting<?>)  s, this.settingOffset));
            else if (s instanceof KeybindSetting)  this.settings.add(new KeybindBox  (this, (KeybindSetting)  s, this.settingOffset));
            else if (s instanceof StringSetting)   this.settings.add(new StringBox   (this, (StringSetting)   s, this.settingOffset));
            else if (s instanceof MinMaxSetting)   this.settings.add(new MinMaxSlider(this, (MinMaxSetting)   s, this.settingOffset));
            this.settingOffset += parent.getHeight();
        }
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (this.parent.getY() + this.offset > class_310.method_1551().method_22683().method_4507()) return;

        for (RenderableSetting rs : this.settings) rs.onUpdate();

        // Row background
        if (this.currentColor == null) {
            this.currentColor = new Color(14, 14, 22, 0);
        } else {
            this.currentColor = new Color(14, 14, 22, this.currentColor.getAlpha());
        }
        this.currentColor = ColorUtils.smoothAlphaTransition(0.06f, 160, this.currentColor);

        int idx   = system.INSTANCE.getModuleManager().getModulesInCategory(this.module.getCategory()).indexOf(this.module);
        boolean isLast = this.parent.moduleButtons.get(this.parent.moduleButtons.size() - 1) == this;
        double bottomR = isLast ? (this.animation.getValue() > 30.0 ? 0.0 : (double) ClickGUI.roundQuads.getValueInt()) : 0.0;

        if (isLast) {
            RenderUtils.renderRoundedQuad(context.method_51448(), this.currentColor,
                parent.getX(), parent.getY() + offset,
                parent.getX() + parent.getWidth(), parent.getY() + parent.getHeight() + offset,
                0.0, 0.0, bottomR, bottomR, 50.0);
            RenderUtils.renderRoundedQuad(context.method_51448(),
                Utils.getMainColor(255, idx),
                parent.getX(), parent.getY() + offset,
                parent.getX() + 2, parent.getY() + parent.getHeight() - 1 + offset,
                0.0, 0.0, extended ? 0.0 : 2.0, 0.0, 50.0);
        } else {
            context.method_25294(
                parent.getX(), parent.getY() + offset,
                parent.getX() + parent.getWidth(), parent.getY() + parent.getHeight() + offset,
                this.currentColor.getRGB());
            context.method_25296(
                parent.getX(), parent.getY() + offset,
                parent.getX() + 2, parent.getY() + parent.getHeight() + offset,
                Utils.getMainColor(255, idx).getRGB(),
                Utils.getMainColor(255, idx + 1).getRGB());
        }

        // Module name – left-aligned
        Color nameTarget = module.isEnabled()
            ? Utils.getMainColor(255, idx)
            : new Color(200, 200, 215, 255);
        if (!this.defaultColor.equals(nameTarget))
            this.defaultColor = ColorUtils.smoothColorTransition(0.12f, nameTarget, this.defaultColor);
        TextRenderer.drawString(module.getName(), context,
            parent.getX() + 8, parent.getY() + offset + 8,
            this.defaultColor.getRGB());

        renderHover(context, mouseX, mouseY, delta);
        renderSettings(context, mouseX, mouseY, delta);
        for (RenderableSetting rs : this.settings)
            if (this.extended) rs.renderDescription(context, mouseX, mouseY, delta);

        // Tooltip
        if (this.isHovered((double) mouseX, (double) mouseY) && !this.parent.dragging) {
            CharSequence desc = module.getDescription();
            int tw = TextRenderer.getWidth(desc);
            int cx = system.mc.method_22683().method_4489() / 2;
            int tx = cx - tw / 2;
            int ty = system.mc.method_22683().method_4506() / 2 + 295;
            RenderUtils.renderRoundedQuad(context.method_51448(),
                new Color(16, 16, 26, 210),
                tx - 6, ty - 3, tx + tw + 6, ty + 14, 3.0, 8.0);
            TextRenderer.drawString(desc, context, tx, ty, new Color(210, 210, 230, 255).getRGB());
        }
    }

    private void renderHover(class_332 context, int mouseX, int mouseY, float delta) {
        if (this.parent.dragging) return;
        int target = isHovered((double) mouseX, (double) mouseY) ? 18 : 0;
        if (this.currentAlpha == null)
            this.currentAlpha = new Color(255, 255, 255, target);
        else
            this.currentAlpha = new Color(255, 255, 255, this.currentAlpha.getAlpha());
        if (this.currentAlpha.getAlpha() != target)
            this.currentAlpha = ColorUtils.smoothAlphaTransition(0.07f, target, this.currentAlpha);
        context.method_25294(
            parent.getX(), parent.getY() + offset,
            parent.getX() + parent.getWidth(), parent.getY() + parent.getHeight() + offset,
            this.currentAlpha.getRGB());
    }

    private void renderSettings(class_332 context, int mouseX, int mouseY, float delta) {
        RenderSystem.enableScissor(
            parent.getX(),
            (int)((double) system.mc.method_22683().method_4507() - ((double)(parent.getY() + offset) + animation.getValue())),
            parent.getWidth(),
            (int) animation.getValue());

        for (RenderableSetting rs : this.settings)
            if (animation.getValue() > parent.getHeight()) rs.render(context, mouseX, mouseY, delta);

        for (RenderableSetting rs : this.settings) {
            if (animation.getValue() > parent.getHeight()) {
                if (rs instanceof Slider) {
                    Slider s = (Slider) rs;
                    RenderUtils.renderCircle(context.method_51448(), new Color(0,0,0,180),
                        (double) s.parentX() + Math.max(s.lerpedOffsetX, 2.5),
                        (double)(s.parentY() + s.offset + s.parentOffset()) + 27.5, 6.0, 15);
                    RenderUtils.renderCircle(context.method_51448(), s.currentColor1.brighter(),
                        (double) s.parentX() + Math.max(s.lerpedOffsetX, 2.5),
                        (double)(s.parentY() + s.offset + s.parentOffset()) + 27.5, 5.0, 15);
                } else if (rs instanceof MinMaxSlider) {
                    MinMaxSlider s = (MinMaxSlider) rs;
                    RenderUtils.renderCircle(context.method_51448(), new Color(0,0,0,180),
                        (double) s.parentX() + Math.max(s.lerpedOffsetMinX, 2.5),
                        (double)(s.parentY() + s.offset + s.parentOffset()) + 27.5, 6.0, 15);
                    RenderUtils.renderCircle(context.method_51448(), s.currentColor1.brighter(),
                        (double) s.parentX() + Math.max(s.lerpedOffsetMinX, 2.5),
                        (double)(s.parentY() + s.offset + s.parentOffset()) + 27.5, 5.0, 15);
                    RenderUtils.renderCircle(context.method_51448(), new Color(0,0,0,180),
                        (double) s.parentX() + Math.max(s.lerpedOffsetMaxX, 2.5),
                        (double)(s.parentY() + s.offset + s.parentOffset()) + 27.5, 6.0, 15);
                    RenderUtils.renderCircle(context.method_51448(), s.currentColor1.brighter(),
                        (double) s.parentX() + Math.max(s.lerpedOffsetMaxX, 2.5),
                        (double)(s.parentY() + s.offset + s.parentOffset()) + 27.5, 5.0, 15);
                }
            }
        }
        RenderSystem.disableScissor();
    }

    public void onExtend() {
        for (ModuleButton mb : this.parent.moduleButtons) mb.extended = false;
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        for (RenderableSetting rs : this.settings) rs.keyPressed(keyCode, scanCode, modifiers);
    }

    public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.extended)
            for (RenderableSetting rs : this.settings) rs.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (isHovered(mouseX, mouseY)) {
            if (button == 0) module.toggle();
            if (button == 1) {
                if (module.getSettings().isEmpty()) return;
                if (!extended) onExtend();
                extended = !extended;
            }
        }
        if (extended)
            for (RenderableSetting rs : this.settings) rs.mouseClicked(mouseX, mouseY, button);
    }

    public void onGuiClose() {
        this.currentAlpha = null;
        this.currentColor = null;
        for (RenderableSetting rs : this.settings) rs.onGuiClose();
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
        for (RenderableSetting rs : this.settings) rs.mouseReleased(mouseX, mouseY, button);
    }

    public boolean isHovered(double mx, double my) {
        return mx > parent.getX() && mx < parent.getX() + parent.getWidth()
            && my > parent.getY() + offset && my < parent.getY() + offset + parent.getHeight();
    }
}
