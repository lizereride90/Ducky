package dlindustries.vigillant.system;

import java.io.IOException;
import net.fabricmc.api.ModInitializer;

public final class Main implements ModInitializer {
   public void onInitialize() {
      try {
         new system();
      } catch (IOException | InterruptedException var2) {
      }

   }
}
