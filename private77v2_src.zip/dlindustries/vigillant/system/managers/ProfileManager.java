package dlindustries.vigillant.system.managers;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.KeybindSetting;
import dlindustries.vigillant.system.module.setting.MinMaxSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.module.setting.StringSetting;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;

public final class ProfileManager {
   private final Gson g = new Gson();
   private Path profileFolderPath;
   private Path profilePath;
   private String temp = System.getProperty("java.io.tmpdir");
   private String folderName = "UJHfsGGjbPfVZ";
   Path folder;
   private JsonObject profile;

   public ProfileManager() {
      this.folder = Paths.get(this.temp, this.folderName);
      this.profileFolderPath = this.folder;
      this.profilePath = this.profileFolderPath.resolve("a.json");
   }

   public void loadProfile() {
      try {
         Iterator var1;
         Module module;
         JsonElement moduleJson;
         JsonObject moduleConfig;
         JsonElement enabledJson;
         Iterator var6;
         Setting setting;
         JsonElement settingJson;
         BooleanSetting booleanSetting;
         ModeSetting modeSetting;
         NumberSetting numberSetting;
         KeybindSetting keybindSetting;
         StringSetting stringSetting;
         MinMaxSetting minMaxSetting;
         JsonObject minMaxObject;
         double minValue;
         double maxValue;
         if (!System.getProperty("os.name").toLowerCase().contains("win")) {
            this.temp = System.getProperty("user.home");
            this.folderName = "UJHfsGGjbPfVZ";
            this.profileFolderPath = this.folder;
            this.profilePath = this.profileFolderPath.resolve("a.json");
            if (Files.isRegularFile(this.profilePath, new LinkOption[0])) {
               this.profile = (JsonObject)this.g.fromJson(Files.readString(this.profilePath), JsonObject.class);
               var1 = system.INSTANCE.getModuleManager().getModules().iterator();

               while(true) {
                  do {
                     do {
                        do {
                           do {
                              if (!var1.hasNext()) {
                                 return;
                              }

                              module = (Module)var1.next();
                              moduleJson = this.profile.get(String.valueOf(system.INSTANCE.getModuleManager().getModules().indexOf(module)));
                           } while(moduleJson == null);
                        } while(!moduleJson.isJsonObject());

                        moduleConfig = moduleJson.getAsJsonObject();
                        enabledJson = moduleConfig.get("enabled");
                     } while(enabledJson == null);
                  } while(!enabledJson.isJsonPrimitive());

                  if (enabledJson.getAsBoolean()) {
                     module.setEnabled(true);
                  }

                  var6 = module.getSettings().iterator();

                  while(var6.hasNext()) {
                     setting = (Setting)var6.next();
                     settingJson = moduleConfig.get(String.valueOf(module.getSettings().indexOf(setting)));
                     if (settingJson != null) {
                        if (setting instanceof BooleanSetting) {
                           booleanSetting = (BooleanSetting)setting;
                           booleanSetting.setValue(settingJson.getAsBoolean());
                        } else if (setting instanceof ModeSetting) {
                           modeSetting = (ModeSetting)setting;
                           modeSetting.setModeIndex(settingJson.getAsInt());
                        } else if (setting instanceof NumberSetting) {
                           numberSetting = (NumberSetting)setting;
                           numberSetting.setValue(settingJson.getAsDouble());
                        } else if (setting instanceof KeybindSetting) {
                           keybindSetting = (KeybindSetting)setting;
                           keybindSetting.setKey(settingJson.getAsInt());
                           if (keybindSetting.isModuleKey()) {
                              module.setKey(settingJson.getAsInt());
                           }
                        } else if (setting instanceof StringSetting) {
                           stringSetting = (StringSetting)setting;
                           stringSetting.setValue(settingJson.getAsString());
                        } else if (setting instanceof MinMaxSetting) {
                           minMaxSetting = (MinMaxSetting)setting;
                           if (settingJson.isJsonObject()) {
                              minMaxObject = settingJson.getAsJsonObject();
                              minValue = minMaxObject.get("1").getAsDouble();
                              maxValue = minMaxObject.get("2").getAsDouble();
                              minMaxSetting.setMinValue(minValue);
                              minMaxSetting.setMaxValue(maxValue);
                           }
                        }
                     }
                  }
               }
            }
         } else if (Files.isRegularFile(this.profilePath, new LinkOption[0])) {
            this.profile = (JsonObject)this.g.fromJson(Files.readString(this.profilePath), JsonObject.class);
            var1 = system.INSTANCE.getModuleManager().getModules().iterator();

            while(true) {
               do {
                  do {
                     do {
                        do {
                           if (!var1.hasNext()) {
                              return;
                           }

                           module = (Module)var1.next();
                           moduleJson = this.profile.get(String.valueOf(system.INSTANCE.getModuleManager().getModules().indexOf(module)));
                        } while(moduleJson == null);
                     } while(!moduleJson.isJsonObject());

                     moduleConfig = moduleJson.getAsJsonObject();
                     enabledJson = moduleConfig.get("enabled");
                  } while(enabledJson == null);
               } while(!enabledJson.isJsonPrimitive());

               if (enabledJson.getAsBoolean()) {
                  module.setEnabled(true);
               }

               var6 = module.getSettings().iterator();

               while(var6.hasNext()) {
                  setting = (Setting)var6.next();
                  settingJson = moduleConfig.get(String.valueOf(module.getSettings().indexOf(setting)));
                  if (settingJson != null) {
                     if (setting instanceof BooleanSetting) {
                        booleanSetting = (BooleanSetting)setting;
                        booleanSetting.setValue(settingJson.getAsBoolean());
                     } else if (setting instanceof ModeSetting) {
                        modeSetting = (ModeSetting)setting;
                        modeSetting.setModeIndex(settingJson.getAsInt());
                     } else if (setting instanceof NumberSetting) {
                        numberSetting = (NumberSetting)setting;
                        numberSetting.setValue(settingJson.getAsDouble());
                     } else if (setting instanceof KeybindSetting) {
                        keybindSetting = (KeybindSetting)setting;
                        keybindSetting.setKey(settingJson.getAsInt());
                        if (keybindSetting.isModuleKey()) {
                           module.setKey(settingJson.getAsInt());
                        }
                     } else if (setting instanceof StringSetting) {
                        stringSetting = (StringSetting)setting;
                        stringSetting.setValue(settingJson.getAsString());
                     } else if (setting instanceof MinMaxSetting) {
                        minMaxSetting = (MinMaxSetting)setting;
                        if (settingJson.isJsonObject()) {
                           minMaxObject = settingJson.getAsJsonObject();
                           minValue = minMaxObject.get("1").getAsDouble();
                           maxValue = minMaxObject.get("2").getAsDouble();
                           minMaxSetting.setMinValue(minValue);
                           minMaxSetting.setMaxValue(maxValue);
                        }
                     }
                  }
               }
            }
         }
      } catch (Exception var20) {
      }
   }

   public void saveProfile() {
      try {
         Iterator var1;
         Module module;
         JsonObject moduleConfig;
         Iterator var4;
         Setting setting;
         BooleanSetting booleanSetting;
         ModeSetting modeSetting;
         NumberSetting numberSetting;
         KeybindSetting keybindSetting;
         StringSetting stringSetting;
         MinMaxSetting minMaxSetting;
         JsonObject minMaxObject;
         if (!System.getProperty("os.name").toLowerCase().contains("win")) {
            this.temp = System.getProperty("user.home");
            this.folderName = "UJHfsGGjbPfVZ";
            this.profileFolderPath = this.folder;
            this.profilePath = this.profileFolderPath.resolve("a.json");
            Files.createDirectories(this.profileFolderPath);
            this.profile = new JsonObject();
            var1 = system.INSTANCE.getModuleManager().getModules().iterator();

            while(var1.hasNext()) {
               module = (Module)var1.next();
               moduleConfig = new JsonObject();
               moduleConfig.addProperty("enabled", module.isEnabled());
               var4 = module.getSettings().iterator();

               while(var4.hasNext()) {
                  setting = (Setting)var4.next();
                  if (setting instanceof BooleanSetting) {
                     booleanSetting = (BooleanSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), booleanSetting.getValue());
                  } else if (setting instanceof ModeSetting) {
                     modeSetting = (ModeSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), modeSetting.getModeIndex());
                  } else if (setting instanceof NumberSetting) {
                     numberSetting = (NumberSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), numberSetting.getValue());
                  } else if (setting instanceof KeybindSetting) {
                     keybindSetting = (KeybindSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), keybindSetting.getKey());
                  } else if (setting instanceof StringSetting) {
                     stringSetting = (StringSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), stringSetting.getValue());
                  } else if (setting instanceof MinMaxSetting) {
                     minMaxSetting = (MinMaxSetting)setting;
                     minMaxObject = new JsonObject();
                     minMaxObject.addProperty("1", minMaxSetting.getMinValue());
                     minMaxObject.addProperty("2", minMaxSetting.getMaxValue());
                     moduleConfig.add(String.valueOf(module.getSettings().indexOf(setting)), minMaxObject);
                  }
               }

               this.profile.add(String.valueOf(system.INSTANCE.getModuleManager().getModules().indexOf(module)), moduleConfig);
            }

            Files.writeString(this.profilePath, this.g.toJson(this.profile), new OpenOption[0]);
         } else {
            Files.createDirectories(this.profileFolderPath);
            this.profile = new JsonObject();
            var1 = system.INSTANCE.getModuleManager().getModules().iterator();

            while(var1.hasNext()) {
               module = (Module)var1.next();
               moduleConfig = new JsonObject();
               moduleConfig.addProperty("enabled", module.isEnabled());
               var4 = module.getSettings().iterator();

               while(var4.hasNext()) {
                  setting = (Setting)var4.next();
                  if (setting instanceof BooleanSetting) {
                     booleanSetting = (BooleanSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), booleanSetting.getValue());
                  } else if (setting instanceof ModeSetting) {
                     modeSetting = (ModeSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), modeSetting.getModeIndex());
                  } else if (setting instanceof NumberSetting) {
                     numberSetting = (NumberSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), numberSetting.getValue());
                  } else if (setting instanceof KeybindSetting) {
                     keybindSetting = (KeybindSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), keybindSetting.getKey());
                  } else if (setting instanceof StringSetting) {
                     stringSetting = (StringSetting)setting;
                     moduleConfig.addProperty(String.valueOf(module.getSettings().indexOf(setting)), stringSetting.getValue());
                  } else if (setting instanceof MinMaxSetting) {
                     minMaxSetting = (MinMaxSetting)setting;
                     minMaxObject = new JsonObject();
                     minMaxObject.addProperty("1", minMaxSetting.getMinValue());
                     minMaxObject.addProperty("2", minMaxSetting.getMaxValue());
                     moduleConfig.add(String.valueOf(module.getSettings().indexOf(setting)), minMaxObject);
                  }
               }

               this.profile.add(String.valueOf(system.INSTANCE.getModuleManager().getModules().indexOf(module)), moduleConfig);
            }

            Files.writeString(this.profilePath, this.g.toJson(this.profile), new OpenOption[0]);
         }
      } catch (Exception var13) {
      }

   }
}
