package dlindustries.vigillant.system.font;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import javax.imageio.ImageIO;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_293.class_5596;
import org.lwjgl.BufferUtils;

public final class GlyphPage {
   private int imgSize;
   private int maxFontHeight = -1;
   private final Font font;
   private final boolean antiAliasing;
   private final boolean fractionalMetrics;
   private final HashMap<Character, GlyphPage.Glyph> glyphCharacterMap = new HashMap();
   private BufferedImage bufferedImage;
   private class_1044 loadedTexture;

   public GlyphPage(Font font, boolean antiAliasing, boolean fractionalMetrics) {
      this.font = font;
      this.antiAliasing = antiAliasing;
      this.fractionalMetrics = fractionalMetrics;
   }

   public void generateGlyphPage(char[] chars) {
      double maxWidth = -1.0D;
      double maxHeight = -1.0D;
      AffineTransform affineTransform = new AffineTransform();
      FontRenderContext fontRenderContext = new FontRenderContext(affineTransform, this.antiAliasing, this.fractionalMetrics);
      char[] var8 = chars;
      int var9 = chars.length;

      int currentCharHeight;
      for(currentCharHeight = 0; currentCharHeight < var9; ++currentCharHeight) {
         char ch = var8[currentCharHeight];
         Rectangle2D bounds = this.font.getStringBounds(Character.toString(ch), fontRenderContext);
         if (maxWidth < bounds.getWidth()) {
            maxWidth = bounds.getWidth();
         }

         if (maxHeight < bounds.getHeight()) {
            maxHeight = bounds.getHeight();
         }
      }

      maxWidth += 2.0D;
      maxHeight += 2.0D;
      this.imgSize = (int)Math.ceil(Math.max(Math.ceil(Math.sqrt(maxWidth * maxWidth * (double)chars.length) / maxWidth), Math.ceil(Math.sqrt(maxHeight * maxHeight * (double)chars.length) / maxHeight)) * Math.max(maxWidth, maxHeight)) + 1;
      this.bufferedImage = new BufferedImage(this.imgSize, this.imgSize, 2);
      Graphics2D g = this.bufferedImage.createGraphics();
      g.setFont(this.font);
      g.setColor(new Color(255, 255, 255, 0));
      g.fillRect(0, 0, this.imgSize, this.imgSize);
      g.setColor(Color.white);
      g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, this.fractionalMetrics ? RenderingHints.VALUE_FRACTIONALMETRICS_ON : RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
      g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, this.antiAliasing ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
      g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, this.antiAliasing ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
      FontMetrics fontMetrics = g.getFontMetrics();
      currentCharHeight = 0;
      int posX = 0;
      int posY = 1;
      char[] var13 = chars;
      int var14 = chars.length;

      for(int var15 = 0; var15 < var14; ++var15) {
         char ch = var13[var15];
         GlyphPage.Glyph glyph = new GlyphPage.Glyph();
         Rectangle2D bounds = fontMetrics.getStringBounds(Character.toString(ch), g);
         glyph.width = bounds.getBounds().width + 8;
         glyph.height = bounds.getBounds().height;
         if (posX + glyph.width >= this.imgSize) {
            posX = 0;
            posY += currentCharHeight;
            currentCharHeight = 0;
         }

         glyph.x = posX;
         glyph.y = posY;
         if (glyph.height > this.maxFontHeight) {
            this.maxFontHeight = glyph.height;
         }

         if (glyph.height > currentCharHeight) {
            currentCharHeight = glyph.height;
         }

         g.drawString(Character.toString(ch), posX + 2, posY + fontMetrics.getAscent());
         posX += glyph.width;
         this.glyphCharacterMap.put(ch, glyph);
      }

   }

   public void setupTexture() {
      try {
         ByteArrayOutputStream baos = new ByteArrayOutputStream();
         ImageIO.write(this.bufferedImage, "png", baos);
         byte[] bytes = baos.toByteArray();
         ByteBuffer data = BufferUtils.createByteBuffer(bytes.length).put(bytes);
         data.flip();
         this.loadedTexture = new class_1043(class_1011.method_4324(data));
      } catch (Exception var4) {
         var4.printStackTrace();
      }

   }

   public void bindTexture() {
      RenderSystem.setShaderTexture(0, this.loadedTexture.method_4624());
   }

   public void unbindTexture() {
      RenderSystem.setShaderTexture(0, 0);
   }

   public float drawChar(class_4587 stack, char ch, float x, float y, float red, float blue, float green, float alpha) {
      GlyphPage.Glyph glyph = (GlyphPage.Glyph)this.glyphCharacterMap.get(ch);
      if (glyph == null) {
         return 0.0F;
      } else {
         float pageX = (float)glyph.x / (float)this.imgSize;
         float pageY = (float)glyph.y / (float)this.imgSize;
         float pageWidth = (float)glyph.width / (float)this.imgSize;
         float pageHeight = (float)glyph.height / (float)this.imgSize;
         float width = (float)glyph.width;
         float height = (float)glyph.height;
         RenderSystem.setShader(class_757::method_34543);
         this.bindTexture();
         class_287 bufferBuilder = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
         bufferBuilder.method_22918(stack.method_23760().method_23761(), x, y + height, 0.0F).method_22915(red, green, blue, alpha).method_22913(pageX, pageY + pageHeight);
         bufferBuilder.method_22918(stack.method_23760().method_23761(), x + width, y + height, 0.0F).method_22915(red, green, blue, alpha).method_22913(pageX + pageWidth, pageY + pageHeight);
         bufferBuilder.method_22918(stack.method_23760().method_23761(), x + width, y, 0.0F).method_22915(red, green, blue, alpha).method_22913(pageX + pageWidth, pageY);
         bufferBuilder.method_22918(stack.method_23760().method_23761(), x, y, 0.0F).method_22915(red, green, blue, alpha).method_22913(pageX, pageY);
         class_286.method_43433(bufferBuilder.method_60800());
         this.unbindTexture();
         return width - 8.0F;
      }
   }

   public float getWidth(char ch) {
      return (float)((GlyphPage.Glyph)this.glyphCharacterMap.get(ch)).width;
   }

   public boolean isAntiAliasingEnabled() {
      return this.antiAliasing;
   }

   public boolean isFractionalMetricsEnabled() {
      return this.fractionalMetrics;
   }

   public int getMaxFontHeight() {
      return this.maxFontHeight;
   }

   static class Glyph {
      private int x;
      private int y;
      private int width;
      private int height;

      Glyph(int x, int y, int width, int height) {
         this.x = x;
         this.y = y;
         this.width = width;
         this.height = height;
      }

      Glyph() {
      }

      public int getX() {
         return this.x;
      }

      public int getY() {
         return this.y;
      }

      public int getWidth() {
         return this.width;
      }

      public int getHeight() {
         return this.height;
      }
   }
}
